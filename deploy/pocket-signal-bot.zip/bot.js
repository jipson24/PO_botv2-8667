var __defProp = Object.defineProperty;
var __returnValue = (v) => v;
function __exportSetter(name, newValue) {
  this[name] = __returnValue.bind(null, newValue);
}
var __export = (target, all) => {
  for (var name in all)
    __defProp(target, name, {
      get: all[name],
      enumerable: true,
      configurable: true,
      set: __exportSetter.bind(all, name)
    });
};
var __esm = (fn, res, err) => () => {
  if (fn)
    try {
      res = fn(fn = 0);
    } catch (e) {
      err = [e];
    }
  if (err)
    throw err[0];
  return res;
};
var __promiseAll = (args) => Promise.all(args);

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/entity.js
function is(value, type) {
  if (!value || typeof value !== "object") {
    return false;
  }
  if (value instanceof type) {
    return true;
  }
  if (!Object.prototype.hasOwnProperty.call(type, entityKind)) {
    throw new Error(`Class "${type.name ?? "<unknown>"}" doesn't look like a Drizzle entity. If this is incorrect and the class is provided by Drizzle, please report this as a bug.`);
  }
  let cls = Object.getPrototypeOf(value).constructor;
  if (cls) {
    while (cls) {
      if (entityKind in cls && cls[entityKind] === type[entityKind]) {
        return true;
      }
      cls = Object.getPrototypeOf(cls);
    }
  }
  return false;
}
var entityKind, hasOwnEntityKind;
var init_entity = __esm(() => {
  entityKind = Symbol.for("drizzle:entityKind");
  hasOwnEntityKind = Symbol.for("drizzle:hasOwnEntityKind");
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/column.js
var Column;
var init_column = __esm(() => {
  init_entity();
  Column = class Column {
    constructor(table, config) {
      this.table = table;
      this.config = config;
      this.name = config.name;
      this.keyAsName = config.keyAsName;
      this.notNull = config.notNull;
      this.default = config.default;
      this.defaultFn = config.defaultFn;
      this.onUpdateFn = config.onUpdateFn;
      this.hasDefault = config.hasDefault;
      this.primary = config.primaryKey;
      this.isUnique = config.isUnique;
      this.uniqueName = config.uniqueName;
      this.uniqueType = config.uniqueType;
      this.dataType = config.dataType;
      this.columnType = config.columnType;
      this.generated = config.generated;
      this.generatedIdentity = config.generatedIdentity;
    }
    static [entityKind] = "Column";
    name;
    keyAsName;
    primary;
    notNull;
    default;
    defaultFn;
    onUpdateFn;
    hasDefault;
    isUnique;
    uniqueName;
    uniqueType;
    dataType;
    columnType;
    enumValues = undefined;
    generated = undefined;
    generatedIdentity = undefined;
    config;
    mapFromDriverValue(value) {
      return value;
    }
    mapToDriverValue(value) {
      return value;
    }
    shouldDisableInsert() {
      return this.config.generated !== undefined && this.config.generated.type !== "byDefault";
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/column-builder.js
var ColumnBuilder;
var init_column_builder = __esm(() => {
  init_entity();
  ColumnBuilder = class ColumnBuilder {
    static [entityKind] = "ColumnBuilder";
    config;
    constructor(name, dataType, columnType) {
      this.config = {
        name,
        keyAsName: name === "",
        notNull: false,
        default: undefined,
        hasDefault: false,
        primaryKey: false,
        isUnique: false,
        uniqueName: undefined,
        uniqueType: undefined,
        dataType,
        columnType,
        generated: undefined
      };
    }
    $type() {
      return this;
    }
    notNull() {
      this.config.notNull = true;
      return this;
    }
    default(value) {
      this.config.default = value;
      this.config.hasDefault = true;
      return this;
    }
    $defaultFn(fn) {
      this.config.defaultFn = fn;
      this.config.hasDefault = true;
      return this;
    }
    $default = this.$defaultFn;
    $onUpdateFn(fn) {
      this.config.onUpdateFn = fn;
      this.config.hasDefault = true;
      return this;
    }
    $onUpdate = this.$onUpdateFn;
    primaryKey() {
      this.config.primaryKey = true;
      this.config.notNull = true;
      return this;
    }
    setName(name) {
      if (this.config.name !== "")
        return;
      this.config.name = name;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/table.utils.js
var TableName;
var init_table_utils = __esm(() => {
  TableName = Symbol.for("drizzle:Name");
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/tracing-utils.js
function iife(fn, ...args) {
  return fn(...args);
}
var init_tracing_utils = () => {};

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/pg-core/columns/enum.js
function isPgEnum(obj) {
  return !!obj && typeof obj === "function" && isPgEnumSym in obj && obj[isPgEnumSym] === true;
}
var isPgEnumSym;
var init_enum = __esm(() => {
  isPgEnumSym = Symbol.for("drizzle:isPgEnum");
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/subquery.js
var Subquery, WithSubquery;
var init_subquery = __esm(() => {
  init_entity();
  Subquery = class Subquery {
    static [entityKind] = "Subquery";
    constructor(sql, fields, alias, isWith = false, usedTables = []) {
      this._ = {
        brand: "Subquery",
        sql,
        selectedFields: fields,
        alias,
        isWith,
        usedTables
      };
    }
  };
  WithSubquery = class WithSubquery extends Subquery {
    static [entityKind] = "WithSubquery";
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/version.js
var version = "0.45.2";
var init_version = () => {};

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/tracing.js
var otel, rawTracer, tracer;
var init_tracing = __esm(() => {
  init_tracing_utils();
  init_version();
  tracer = {
    startActiveSpan(name, fn) {
      if (!otel) {
        return fn();
      }
      if (!rawTracer) {
        rawTracer = otel.trace.getTracer("drizzle-orm", version);
      }
      return iife((otel2, rawTracer2) => rawTracer2.startActiveSpan(name, (span) => {
        try {
          return fn(span);
        } catch (e) {
          span.setStatus({
            code: otel2.SpanStatusCode.ERROR,
            message: e instanceof Error ? e.message : "Unknown error"
          });
          throw e;
        } finally {
          span.end();
        }
      }), otel, rawTracer);
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/view-common.js
var ViewBaseConfig;
var init_view_common = __esm(() => {
  ViewBaseConfig = Symbol.for("drizzle:ViewBaseConfig");
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/table.js
function getTableName(table) {
  return table[TableName];
}
function getTableUniqueName(table) {
  return `${table[Schema] ?? "public"}.${table[TableName]}`;
}
var Schema, Columns, ExtraConfigColumns, OriginalName, BaseName, IsAlias, ExtraConfigBuilder, IsDrizzleTable, Table;
var init_table = __esm(() => {
  init_entity();
  init_table_utils();
  Schema = Symbol.for("drizzle:Schema");
  Columns = Symbol.for("drizzle:Columns");
  ExtraConfigColumns = Symbol.for("drizzle:ExtraConfigColumns");
  OriginalName = Symbol.for("drizzle:OriginalName");
  BaseName = Symbol.for("drizzle:BaseName");
  IsAlias = Symbol.for("drizzle:IsAlias");
  ExtraConfigBuilder = Symbol.for("drizzle:ExtraConfigBuilder");
  IsDrizzleTable = Symbol.for("drizzle:IsDrizzleTable");
  Table = class Table {
    static [entityKind] = "Table";
    static Symbol = {
      Name: TableName,
      Schema,
      OriginalName,
      Columns,
      ExtraConfigColumns,
      BaseName,
      IsAlias,
      ExtraConfigBuilder
    };
    [TableName];
    [OriginalName];
    [Schema];
    [Columns];
    [ExtraConfigColumns];
    [BaseName];
    [IsAlias] = false;
    [IsDrizzleTable] = true;
    [ExtraConfigBuilder] = undefined;
    constructor(name, schema, baseName) {
      this[TableName] = this[OriginalName] = name;
      this[Schema] = schema;
      this[BaseName] = baseName;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/sql.js
function isSQLWrapper(value) {
  return value !== null && value !== undefined && typeof value.getSQL === "function";
}
function mergeQueries(queries) {
  const result = { sql: "", params: [] };
  for (const query of queries) {
    result.sql += query.sql;
    result.params.push(...query.params);
    if (query.typings?.length) {
      if (!result.typings) {
        result.typings = [];
      }
      result.typings.push(...query.typings);
    }
  }
  return result;
}
function isDriverValueEncoder(value) {
  return typeof value === "object" && value !== null && "mapToDriverValue" in value && typeof value.mapToDriverValue === "function";
}
function sql(strings, ...params) {
  const queryChunks = [];
  if (params.length > 0 || strings.length > 0 && strings[0] !== "") {
    queryChunks.push(new StringChunk(strings[0]));
  }
  for (const [paramIndex, param2] of params.entries()) {
    queryChunks.push(param2, new StringChunk(strings[paramIndex + 1]));
  }
  return new SQL(queryChunks);
}
function fillPlaceholders(params, values) {
  return params.map((p) => {
    if (is(p, Placeholder)) {
      if (!(p.name in values)) {
        throw new Error(`No value for placeholder "${p.name}" was provided`);
      }
      return values[p.name];
    }
    if (is(p, Param) && is(p.value, Placeholder)) {
      if (!(p.value.name in values)) {
        throw new Error(`No value for placeholder "${p.value.name}" was provided`);
      }
      return p.encoder.mapToDriverValue(values[p.value.name]);
    }
    return p;
  });
}
var StringChunk, SQL, Name, noopDecoder, noopEncoder, noopMapper, Param, Placeholder, IsDrizzleView, View;
var init_sql = __esm(() => {
  init_entity();
  init_enum();
  init_subquery();
  init_tracing();
  init_view_common();
  init_column();
  init_table();
  StringChunk = class StringChunk {
    static [entityKind] = "StringChunk";
    value;
    constructor(value) {
      this.value = Array.isArray(value) ? value : [value];
    }
    getSQL() {
      return new SQL([this]);
    }
  };
  SQL = class SQL {
    constructor(queryChunks) {
      this.queryChunks = queryChunks;
      for (const chunk of queryChunks) {
        if (is(chunk, Table)) {
          const schemaName = chunk[Table.Symbol.Schema];
          this.usedTables.push(schemaName === undefined ? chunk[Table.Symbol.Name] : schemaName + "." + chunk[Table.Symbol.Name]);
        }
      }
    }
    static [entityKind] = "SQL";
    decoder = noopDecoder;
    shouldInlineParams = false;
    usedTables = [];
    append(query) {
      this.queryChunks.push(...query.queryChunks);
      return this;
    }
    toQuery(config) {
      return tracer.startActiveSpan("drizzle.buildSQL", (span) => {
        const query = this.buildQueryFromSourceParams(this.queryChunks, config);
        span?.setAttributes({
          "drizzle.query.text": query.sql,
          "drizzle.query.params": JSON.stringify(query.params)
        });
        return query;
      });
    }
    buildQueryFromSourceParams(chunks, _config) {
      const config = Object.assign({}, _config, {
        inlineParams: _config.inlineParams || this.shouldInlineParams,
        paramStartIndex: _config.paramStartIndex || { value: 0 }
      });
      const {
        casing,
        escapeName,
        escapeParam,
        prepareTyping,
        inlineParams,
        paramStartIndex
      } = config;
      return mergeQueries(chunks.map((chunk) => {
        if (is(chunk, StringChunk)) {
          return { sql: chunk.value.join(""), params: [] };
        }
        if (is(chunk, Name)) {
          return { sql: escapeName(chunk.value), params: [] };
        }
        if (chunk === undefined) {
          return { sql: "", params: [] };
        }
        if (Array.isArray(chunk)) {
          const result = [new StringChunk("(")];
          for (const [i, p] of chunk.entries()) {
            result.push(p);
            if (i < chunk.length - 1) {
              result.push(new StringChunk(", "));
            }
          }
          result.push(new StringChunk(")"));
          return this.buildQueryFromSourceParams(result, config);
        }
        if (is(chunk, SQL)) {
          return this.buildQueryFromSourceParams(chunk.queryChunks, {
            ...config,
            inlineParams: inlineParams || chunk.shouldInlineParams
          });
        }
        if (is(chunk, Table)) {
          const schemaName = chunk[Table.Symbol.Schema];
          const tableName = chunk[Table.Symbol.Name];
          return {
            sql: schemaName === undefined || chunk[IsAlias] ? escapeName(tableName) : escapeName(schemaName) + "." + escapeName(tableName),
            params: []
          };
        }
        if (is(chunk, Column)) {
          const columnName = casing.getColumnCasing(chunk);
          if (_config.invokeSource === "indexes") {
            return { sql: escapeName(columnName), params: [] };
          }
          const schemaName = chunk.table[Table.Symbol.Schema];
          return {
            sql: chunk.table[IsAlias] || schemaName === undefined ? escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName) : escapeName(schemaName) + "." + escapeName(chunk.table[Table.Symbol.Name]) + "." + escapeName(columnName),
            params: []
          };
        }
        if (is(chunk, View)) {
          const schemaName = chunk[ViewBaseConfig].schema;
          const viewName = chunk[ViewBaseConfig].name;
          return {
            sql: schemaName === undefined || chunk[ViewBaseConfig].isAlias ? escapeName(viewName) : escapeName(schemaName) + "." + escapeName(viewName),
            params: []
          };
        }
        if (is(chunk, Param)) {
          if (is(chunk.value, Placeholder)) {
            return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
          }
          const mappedValue = chunk.value === null ? null : chunk.encoder.mapToDriverValue(chunk.value);
          if (is(mappedValue, SQL)) {
            return this.buildQueryFromSourceParams([mappedValue], config);
          }
          if (inlineParams) {
            return { sql: this.mapInlineParam(mappedValue, config), params: [] };
          }
          let typings = ["none"];
          if (prepareTyping) {
            typings = [prepareTyping(chunk.encoder)];
          }
          return { sql: escapeParam(paramStartIndex.value++, mappedValue), params: [mappedValue], typings };
        }
        if (is(chunk, Placeholder)) {
          return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
        }
        if (is(chunk, SQL.Aliased) && chunk.fieldAlias !== undefined) {
          return { sql: escapeName(chunk.fieldAlias), params: [] };
        }
        if (is(chunk, Subquery)) {
          if (chunk._.isWith) {
            return { sql: escapeName(chunk._.alias), params: [] };
          }
          return this.buildQueryFromSourceParams([
            new StringChunk("("),
            chunk._.sql,
            new StringChunk(") "),
            new Name(chunk._.alias)
          ], config);
        }
        if (isPgEnum(chunk)) {
          if (chunk.schema) {
            return { sql: escapeName(chunk.schema) + "." + escapeName(chunk.enumName), params: [] };
          }
          return { sql: escapeName(chunk.enumName), params: [] };
        }
        if (isSQLWrapper(chunk)) {
          if (chunk.shouldOmitSQLParens?.()) {
            return this.buildQueryFromSourceParams([chunk.getSQL()], config);
          }
          return this.buildQueryFromSourceParams([
            new StringChunk("("),
            chunk.getSQL(),
            new StringChunk(")")
          ], config);
        }
        if (inlineParams) {
          return { sql: this.mapInlineParam(chunk, config), params: [] };
        }
        return { sql: escapeParam(paramStartIndex.value++, chunk), params: [chunk], typings: ["none"] };
      }));
    }
    mapInlineParam(chunk, { escapeString }) {
      if (chunk === null) {
        return "null";
      }
      if (typeof chunk === "number" || typeof chunk === "boolean") {
        return chunk.toString();
      }
      if (typeof chunk === "string") {
        return escapeString(chunk);
      }
      if (typeof chunk === "object") {
        const mappedValueAsString = chunk.toString();
        if (mappedValueAsString === "[object Object]") {
          return escapeString(JSON.stringify(chunk));
        }
        return escapeString(mappedValueAsString);
      }
      throw new Error("Unexpected param value: " + chunk);
    }
    getSQL() {
      return this;
    }
    as(alias) {
      if (alias === undefined) {
        return this;
      }
      return new SQL.Aliased(this, alias);
    }
    mapWith(decoder) {
      this.decoder = typeof decoder === "function" ? { mapFromDriverValue: decoder } : decoder;
      return this;
    }
    inlineParams() {
      this.shouldInlineParams = true;
      return this;
    }
    if(condition) {
      return condition ? this : undefined;
    }
  };
  Name = class Name {
    constructor(value) {
      this.value = value;
    }
    static [entityKind] = "Name";
    brand;
    getSQL() {
      return new SQL([this]);
    }
  };
  noopDecoder = {
    mapFromDriverValue: (value) => value
  };
  noopEncoder = {
    mapToDriverValue: (value) => value
  };
  noopMapper = {
    ...noopDecoder,
    ...noopEncoder
  };
  Param = class Param {
    constructor(value, encoder = noopEncoder) {
      this.value = value;
      this.encoder = encoder;
    }
    static [entityKind] = "Param";
    brand;
    getSQL() {
      return new SQL([this]);
    }
  };
  ((sql2) => {
    function empty() {
      return new SQL([]);
    }
    sql2.empty = empty;
    function fromList(list) {
      return new SQL(list);
    }
    sql2.fromList = fromList;
    function raw(str) {
      return new SQL([new StringChunk(str)]);
    }
    sql2.raw = raw;
    function join(chunks, separator) {
      const result = [];
      for (const [i, chunk] of chunks.entries()) {
        if (i > 0 && separator !== undefined) {
          result.push(separator);
        }
        result.push(chunk);
      }
      return new SQL(result);
    }
    sql2.join = join;
    function identifier(value) {
      return new Name(value);
    }
    sql2.identifier = identifier;
    function placeholder2(name2) {
      return new Placeholder(name2);
    }
    sql2.placeholder = placeholder2;
    function param2(value, encoder) {
      return new Param(value, encoder);
    }
    sql2.param = param2;
  })(sql || (sql = {}));
  ((SQL2) => {

    class Aliased {
      constructor(sql2, fieldAlias) {
        this.sql = sql2;
        this.fieldAlias = fieldAlias;
      }
      static [entityKind] = "SQL.Aliased";
      isSelectionField = false;
      getSQL() {
        return this.sql;
      }
      clone() {
        return new Aliased(this.sql, this.fieldAlias);
      }
    }
    SQL2.Aliased = Aliased;
  })(SQL || (SQL = {}));
  Placeholder = class Placeholder {
    constructor(name2) {
      this.name = name2;
    }
    static [entityKind] = "Placeholder";
    getSQL() {
      return new SQL([this]);
    }
  };
  IsDrizzleView = Symbol.for("drizzle:IsDrizzleView");
  View = class View {
    static [entityKind] = "View";
    [ViewBaseConfig];
    [IsDrizzleView] = true;
    constructor({ name: name2, schema, selectedFields, query }) {
      this[ViewBaseConfig] = {
        name: name2,
        originalName: name2,
        schema,
        selectedFields,
        query,
        isExisting: !query,
        isAlias: false
      };
    }
    getSQL() {
      return new SQL([this]);
    }
  };
  Column.prototype.getSQL = function() {
    return new SQL([this]);
  };
  Table.prototype.getSQL = function() {
    return new SQL([this]);
  };
  Subquery.prototype.getSQL = function() {
    return new SQL([this]);
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/alias.js
function aliasedTable(table, tableAlias) {
  return new Proxy(table, new TableAliasProxyHandler(tableAlias, false));
}
function aliasedTableColumn(column, tableAlias) {
  return new Proxy(column, new ColumnAliasProxyHandler(new Proxy(column.table, new TableAliasProxyHandler(tableAlias, false))));
}
function mapColumnsInAliasedSQLToAlias(query, alias) {
  return new SQL.Aliased(mapColumnsInSQLToAlias(query.sql, alias), query.fieldAlias);
}
function mapColumnsInSQLToAlias(query, alias) {
  return sql.join(query.queryChunks.map((c) => {
    if (is(c, Column)) {
      return aliasedTableColumn(c, alias);
    }
    if (is(c, SQL)) {
      return mapColumnsInSQLToAlias(c, alias);
    }
    if (is(c, SQL.Aliased)) {
      return mapColumnsInAliasedSQLToAlias(c, alias);
    }
    return c;
  }));
}
var ColumnAliasProxyHandler, TableAliasProxyHandler;
var init_alias = __esm(() => {
  init_column();
  init_entity();
  init_sql();
  init_table();
  init_view_common();
  ColumnAliasProxyHandler = class ColumnAliasProxyHandler {
    constructor(table) {
      this.table = table;
    }
    static [entityKind] = "ColumnAliasProxyHandler";
    get(columnObj, prop) {
      if (prop === "table") {
        return this.table;
      }
      return columnObj[prop];
    }
  };
  TableAliasProxyHandler = class TableAliasProxyHandler {
    constructor(alias, replaceOriginalName) {
      this.alias = alias;
      this.replaceOriginalName = replaceOriginalName;
    }
    static [entityKind] = "TableAliasProxyHandler";
    get(target, prop) {
      if (prop === Table.Symbol.IsAlias) {
        return true;
      }
      if (prop === Table.Symbol.Name) {
        return this.alias;
      }
      if (this.replaceOriginalName && prop === Table.Symbol.OriginalName) {
        return this.alias;
      }
      if (prop === ViewBaseConfig) {
        return {
          ...target[ViewBaseConfig],
          name: this.alias,
          isAlias: true
        };
      }
      if (prop === Table.Symbol.Columns) {
        const columns = target[Table.Symbol.Columns];
        if (!columns) {
          return columns;
        }
        const proxiedColumns = {};
        Object.keys(columns).map((key) => {
          proxiedColumns[key] = new Proxy(columns[key], new ColumnAliasProxyHandler(new Proxy(target, this)));
        });
        return proxiedColumns;
      }
      const value = target[prop];
      if (is(value, Column)) {
        return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(target, this)));
      }
      return value;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/errors.js
var DrizzleError, DrizzleQueryError, TransactionRollbackError;
var init_errors = __esm(() => {
  init_entity();
  DrizzleError = class DrizzleError extends Error {
    static [entityKind] = "DrizzleError";
    constructor({ message, cause }) {
      super(message);
      this.name = "DrizzleError";
      this.cause = cause;
    }
  };
  DrizzleQueryError = class DrizzleQueryError extends Error {
    constructor(query, params, cause) {
      super(`Failed query: ${query}
params: ${params}`);
      this.query = query;
      this.params = params;
      this.cause = cause;
      Error.captureStackTrace(this, DrizzleQueryError);
      if (cause)
        this.cause = cause;
    }
  };
  TransactionRollbackError = class TransactionRollbackError extends DrizzleError {
    static [entityKind] = "TransactionRollbackError";
    constructor() {
      super({ message: "Rollback" });
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/logger.js
var ConsoleLogWriter, DefaultLogger, NoopLogger;
var init_logger = __esm(() => {
  init_entity();
  ConsoleLogWriter = class ConsoleLogWriter {
    static [entityKind] = "ConsoleLogWriter";
    write(message) {
      console.log(message);
    }
  };
  DefaultLogger = class DefaultLogger {
    static [entityKind] = "DefaultLogger";
    writer;
    constructor(config) {
      this.writer = config?.writer ?? new ConsoleLogWriter;
    }
    logQuery(query, params) {
      const stringifiedParams = params.map((p) => {
        try {
          return JSON.stringify(p);
        } catch {
          return String(p);
        }
      });
      const paramsStr = stringifiedParams.length ? ` -- params: [${stringifiedParams.join(", ")}]` : "";
      this.writer.write(`Query: ${query}${paramsStr}`);
    }
  };
  NoopLogger = class NoopLogger {
    static [entityKind] = "NoopLogger";
    logQuery() {}
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/query-promise.js
var QueryPromise;
var init_query_promise = __esm(() => {
  init_entity();
  QueryPromise = class QueryPromise {
    static [entityKind] = "QueryPromise";
    [Symbol.toStringTag] = "QueryPromise";
    catch(onRejected) {
      return this.then(undefined, onRejected);
    }
    finally(onFinally) {
      return this.then((value) => {
        onFinally?.();
        return value;
      }, (reason) => {
        onFinally?.();
        throw reason;
      });
    }
    then(onFulfilled, onRejected) {
      return this.execute().then(onFulfilled, onRejected);
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/utils.js
function mapResultRow(columns, row, joinsNotNullableMap) {
  const nullifyMap = {};
  const result = columns.reduce((result2, { path, field }, columnIndex) => {
    let decoder;
    if (is(field, Column)) {
      decoder = field;
    } else if (is(field, SQL)) {
      decoder = field.decoder;
    } else if (is(field, Subquery)) {
      decoder = field._.sql.decoder;
    } else {
      decoder = field.sql.decoder;
    }
    let node = result2;
    for (const [pathChunkIndex, pathChunk] of path.entries()) {
      if (pathChunkIndex < path.length - 1) {
        if (!(pathChunk in node)) {
          node[pathChunk] = {};
        }
        node = node[pathChunk];
      } else {
        const rawValue = row[columnIndex];
        const value = node[pathChunk] = rawValue === null ? null : decoder.mapFromDriverValue(rawValue);
        if (joinsNotNullableMap && is(field, Column) && path.length === 2) {
          const objectName = path[0];
          if (!(objectName in nullifyMap)) {
            nullifyMap[objectName] = value === null ? getTableName(field.table) : false;
          } else if (typeof nullifyMap[objectName] === "string" && nullifyMap[objectName] !== getTableName(field.table)) {
            nullifyMap[objectName] = false;
          }
        }
      }
    }
    return result2;
  }, {});
  if (joinsNotNullableMap && Object.keys(nullifyMap).length > 0) {
    for (const [objectName, tableName] of Object.entries(nullifyMap)) {
      if (typeof tableName === "string" && !joinsNotNullableMap[tableName]) {
        result[objectName] = null;
      }
    }
  }
  return result;
}
function orderSelectedFields(fields, pathPrefix) {
  return Object.entries(fields).reduce((result, [name, field]) => {
    if (typeof name !== "string") {
      return result;
    }
    const newPath = pathPrefix ? [...pathPrefix, name] : [name];
    if (is(field, Column) || is(field, SQL) || is(field, SQL.Aliased) || is(field, Subquery)) {
      result.push({ path: newPath, field });
    } else if (is(field, Table)) {
      result.push(...orderSelectedFields(field[Table.Symbol.Columns], newPath));
    } else {
      result.push(...orderSelectedFields(field, newPath));
    }
    return result;
  }, []);
}
function haveSameKeys(left, right) {
  const leftKeys = Object.keys(left);
  const rightKeys = Object.keys(right);
  if (leftKeys.length !== rightKeys.length) {
    return false;
  }
  for (const [index, key] of leftKeys.entries()) {
    if (key !== rightKeys[index]) {
      return false;
    }
  }
  return true;
}
function mapUpdateSet(table, values) {
  const entries = Object.entries(values).filter(([, value]) => value !== undefined).map(([key, value]) => {
    if (is(value, SQL) || is(value, Column)) {
      return [key, value];
    } else {
      return [key, new Param(value, table[Table.Symbol.Columns][key])];
    }
  });
  if (entries.length === 0) {
    throw new Error("No values to set");
  }
  return Object.fromEntries(entries);
}
function applyMixins(baseClass, extendedClasses) {
  for (const extendedClass of extendedClasses) {
    for (const name of Object.getOwnPropertyNames(extendedClass.prototype)) {
      if (name === "constructor")
        continue;
      Object.defineProperty(baseClass.prototype, name, Object.getOwnPropertyDescriptor(extendedClass.prototype, name) || /* @__PURE__ */ Object.create(null));
    }
  }
}
function getTableColumns(table) {
  return table[Table.Symbol.Columns];
}
function getTableLikeName(table) {
  return is(table, Subquery) ? table._.alias : is(table, View) ? table[ViewBaseConfig].name : is(table, SQL) ? undefined : table[Table.Symbol.IsAlias] ? table[Table.Symbol.Name] : table[Table.Symbol.BaseName];
}
function getColumnNameAndConfig(a, b) {
  return {
    name: typeof a === "string" && a.length > 0 ? a : "",
    config: typeof a === "object" ? a : b
  };
}
function isConfig(data) {
  if (typeof data !== "object" || data === null)
    return false;
  if (data.constructor.name !== "Object")
    return false;
  if ("logger" in data) {
    const type = typeof data["logger"];
    if (type !== "boolean" && (type !== "object" || typeof data["logger"]["logQuery"] !== "function") && type !== "undefined")
      return false;
    return true;
  }
  if ("schema" in data) {
    const type = typeof data["schema"];
    if (type !== "object" && type !== "undefined")
      return false;
    return true;
  }
  if ("casing" in data) {
    const type = typeof data["casing"];
    if (type !== "string" && type !== "undefined")
      return false;
    return true;
  }
  if ("mode" in data) {
    if (data["mode"] !== "default" || data["mode"] !== "planetscale" || data["mode"] !== undefined)
      return false;
    return true;
  }
  if ("connection" in data) {
    const type = typeof data["connection"];
    if (type !== "string" && type !== "object" && type !== "undefined")
      return false;
    return true;
  }
  if ("client" in data) {
    const type = typeof data["client"];
    if (type !== "object" && type !== "function" && type !== "undefined")
      return false;
    return true;
  }
  if (Object.keys(data).length === 0)
    return true;
  return false;
}
var textDecoder2;
var init_utils = __esm(() => {
  init_column();
  init_entity();
  init_sql();
  init_subquery();
  init_table();
  init_view_common();
  textDecoder2 = typeof TextDecoder === "undefined" ? null : new TextDecoder;
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/pg-core/table.js
var InlineForeignKeys, EnableRLS, PgTable;
var init_table2 = __esm(() => {
  init_entity();
  init_table();
  InlineForeignKeys = Symbol.for("drizzle:PgInlineForeignKeys");
  EnableRLS = Symbol.for("drizzle:EnableRLS");
  PgTable = class PgTable extends Table {
    static [entityKind] = "PgTable";
    static Symbol = Object.assign({}, Table.Symbol, {
      InlineForeignKeys,
      EnableRLS
    });
    [InlineForeignKeys] = [];
    [EnableRLS] = false;
    [Table.Symbol.ExtraConfigBuilder] = undefined;
    [Table.Symbol.ExtraConfigColumns] = {};
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/pg-core/primary-keys.js
var PrimaryKeyBuilder, PrimaryKey;
var init_primary_keys = __esm(() => {
  init_entity();
  init_table2();
  PrimaryKeyBuilder = class PrimaryKeyBuilder {
    static [entityKind] = "PgPrimaryKeyBuilder";
    columns;
    name;
    constructor(columns, name) {
      this.columns = columns;
      this.name = name;
    }
    build(table) {
      return new PrimaryKey(table, this.columns, this.name);
    }
  };
  PrimaryKey = class PrimaryKey {
    constructor(table, columns, name) {
      this.table = table;
      this.columns = columns;
      this.name = name;
    }
    static [entityKind] = "PgPrimaryKey";
    columns;
    name;
    getName() {
      return this.name ?? `${this.table[PgTable.Symbol.Name]}_${this.columns.map((column) => column.name).join("_")}_pk`;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/expressions/conditions.js
function bindIfParam(value, column) {
  if (isDriverValueEncoder(column) && !isSQLWrapper(value) && !is(value, Param) && !is(value, Placeholder) && !is(value, Column) && !is(value, Table) && !is(value, View)) {
    return new Param(value, column);
  }
  return value;
}
function and(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter((c) => c !== undefined);
  if (conditions.length === 0) {
    return;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" and ")),
    new StringChunk(")")
  ]);
}
function or(...unfilteredConditions) {
  const conditions = unfilteredConditions.filter((c) => c !== undefined);
  if (conditions.length === 0) {
    return;
  }
  if (conditions.length === 1) {
    return new SQL(conditions);
  }
  return new SQL([
    new StringChunk("("),
    sql.join(conditions, new StringChunk(" or ")),
    new StringChunk(")")
  ]);
}
function not(condition) {
  return sql`not ${condition}`;
}
function inArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return sql`false`;
    }
    return sql`${column} in ${values.map((v) => bindIfParam(v, column))}`;
  }
  return sql`${column} in ${bindIfParam(values, column)}`;
}
function notInArray(column, values) {
  if (Array.isArray(values)) {
    if (values.length === 0) {
      return sql`true`;
    }
    return sql`${column} not in ${values.map((v) => bindIfParam(v, column))}`;
  }
  return sql`${column} not in ${bindIfParam(values, column)}`;
}
function isNull(value) {
  return sql`${value} is null`;
}
function isNotNull(value) {
  return sql`${value} is not null`;
}
function exists(subquery) {
  return sql`exists ${subquery}`;
}
function notExists(subquery) {
  return sql`not exists ${subquery}`;
}
function between(column, min, max) {
  return sql`${column} between ${bindIfParam(min, column)} and ${bindIfParam(max, column)}`;
}
function notBetween(column, min, max) {
  return sql`${column} not between ${bindIfParam(min, column)} and ${bindIfParam(max, column)}`;
}
function like(column, value) {
  return sql`${column} like ${value}`;
}
function notLike(column, value) {
  return sql`${column} not like ${value}`;
}
function ilike(column, value) {
  return sql`${column} ilike ${value}`;
}
function notIlike(column, value) {
  return sql`${column} not ilike ${value}`;
}
var eq = (left, right) => {
  return sql`${left} = ${bindIfParam(right, left)}`;
}, ne = (left, right) => {
  return sql`${left} <> ${bindIfParam(right, left)}`;
}, gt = (left, right) => {
  return sql`${left} > ${bindIfParam(right, left)}`;
}, gte = (left, right) => {
  return sql`${left} >= ${bindIfParam(right, left)}`;
}, lt = (left, right) => {
  return sql`${left} < ${bindIfParam(right, left)}`;
}, lte = (left, right) => {
  return sql`${left} <= ${bindIfParam(right, left)}`;
};
var init_conditions = __esm(() => {
  init_column();
  init_entity();
  init_table();
  init_sql();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/expressions/select.js
function asc(column) {
  return sql`${column} asc`;
}
function desc(column) {
  return sql`${column} desc`;
}
var init_select = __esm(() => {
  init_sql();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/expressions/index.js
var init_expressions = __esm(() => {
  init_conditions();
  init_select();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/relations.js
function getOperators() {
  return {
    and,
    between,
    eq,
    exists,
    gt,
    gte,
    ilike,
    inArray,
    isNull,
    isNotNull,
    like,
    lt,
    lte,
    ne,
    not,
    notBetween,
    notExists,
    notLike,
    notIlike,
    notInArray,
    or,
    sql
  };
}
function getOrderByOperators() {
  return {
    sql,
    asc,
    desc
  };
}
function extractTablesRelationalConfig(schema, configHelpers) {
  if (Object.keys(schema).length === 1 && "default" in schema && !is(schema["default"], Table)) {
    schema = schema["default"];
  }
  const tableNamesMap = {};
  const relationsBuffer = {};
  const tablesConfig = {};
  for (const [key, value] of Object.entries(schema)) {
    if (is(value, Table)) {
      const dbName = getTableUniqueName(value);
      const bufferedRelations = relationsBuffer[dbName];
      tableNamesMap[dbName] = key;
      tablesConfig[key] = {
        tsName: key,
        dbName: value[Table.Symbol.Name],
        schema: value[Table.Symbol.Schema],
        columns: value[Table.Symbol.Columns],
        relations: bufferedRelations?.relations ?? {},
        primaryKey: bufferedRelations?.primaryKey ?? []
      };
      for (const column of Object.values(value[Table.Symbol.Columns])) {
        if (column.primary) {
          tablesConfig[key].primaryKey.push(column);
        }
      }
      const extraConfig = value[Table.Symbol.ExtraConfigBuilder]?.(value[Table.Symbol.ExtraConfigColumns]);
      if (extraConfig) {
        for (const configEntry of Object.values(extraConfig)) {
          if (is(configEntry, PrimaryKeyBuilder)) {
            tablesConfig[key].primaryKey.push(...configEntry.columns);
          }
        }
      }
    } else if (is(value, Relations)) {
      const dbName = getTableUniqueName(value.table);
      const tableName = tableNamesMap[dbName];
      const relations2 = value.config(configHelpers(value.table));
      let primaryKey;
      for (const [relationName, relation] of Object.entries(relations2)) {
        if (tableName) {
          const tableConfig = tablesConfig[tableName];
          tableConfig.relations[relationName] = relation;
          if (primaryKey) {
            tableConfig.primaryKey.push(...primaryKey);
          }
        } else {
          if (!(dbName in relationsBuffer)) {
            relationsBuffer[dbName] = {
              relations: {},
              primaryKey
            };
          }
          relationsBuffer[dbName].relations[relationName] = relation;
        }
      }
    }
  }
  return { tables: tablesConfig, tableNamesMap };
}
function createOne(sourceTable) {
  return function one(table, config) {
    return new One(sourceTable, table, config, config?.fields.reduce((res, f) => res && f.notNull, true) ?? false);
  };
}
function createMany(sourceTable) {
  return function many(referencedTable, config) {
    return new Many(sourceTable, referencedTable, config);
  };
}
function normalizeRelation(schema, tableNamesMap, relation) {
  if (is(relation, One) && relation.config) {
    return {
      fields: relation.config.fields,
      references: relation.config.references
    };
  }
  const referencedTableTsName = tableNamesMap[getTableUniqueName(relation.referencedTable)];
  if (!referencedTableTsName) {
    throw new Error(`Table "${relation.referencedTable[Table.Symbol.Name]}" not found in schema`);
  }
  const referencedTableConfig = schema[referencedTableTsName];
  if (!referencedTableConfig) {
    throw new Error(`Table "${referencedTableTsName}" not found in schema`);
  }
  const sourceTable = relation.sourceTable;
  const sourceTableTsName = tableNamesMap[getTableUniqueName(sourceTable)];
  if (!sourceTableTsName) {
    throw new Error(`Table "${sourceTable[Table.Symbol.Name]}" not found in schema`);
  }
  const reverseRelations = [];
  for (const referencedTableRelation of Object.values(referencedTableConfig.relations)) {
    if (relation.relationName && relation !== referencedTableRelation && referencedTableRelation.relationName === relation.relationName || !relation.relationName && referencedTableRelation.referencedTable === relation.sourceTable) {
      reverseRelations.push(referencedTableRelation);
    }
  }
  if (reverseRelations.length > 1) {
    throw relation.relationName ? new Error(`There are multiple relations with name "${relation.relationName}" in table "${referencedTableTsName}"`) : new Error(`There are multiple relations between "${referencedTableTsName}" and "${relation.sourceTable[Table.Symbol.Name]}". Please specify relation name`);
  }
  if (reverseRelations[0] && is(reverseRelations[0], One) && reverseRelations[0].config) {
    return {
      fields: reverseRelations[0].config.references,
      references: reverseRelations[0].config.fields
    };
  }
  throw new Error(`There is not enough information to infer relation "${sourceTableTsName}.${relation.fieldName}"`);
}
function createTableRelationsHelpers(sourceTable) {
  return {
    one: createOne(sourceTable),
    many: createMany(sourceTable)
  };
}
function mapRelationalRow(tablesConfig, tableConfig, row, buildQueryResultSelection, mapColumnValue = (value) => value) {
  const result = {};
  for (const [
    selectionItemIndex,
    selectionItem
  ] of buildQueryResultSelection.entries()) {
    if (selectionItem.isJson) {
      const relation = tableConfig.relations[selectionItem.tsKey];
      const rawSubRows = row[selectionItemIndex];
      const subRows = typeof rawSubRows === "string" ? JSON.parse(rawSubRows) : rawSubRows;
      result[selectionItem.tsKey] = is(relation, One) ? subRows && mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRows, selectionItem.selection, mapColumnValue) : subRows.map((subRow) => mapRelationalRow(tablesConfig, tablesConfig[selectionItem.relationTableTsKey], subRow, selectionItem.selection, mapColumnValue));
    } else {
      const value = mapColumnValue(row[selectionItemIndex]);
      const field = selectionItem.field;
      let decoder;
      if (is(field, Column)) {
        decoder = field;
      } else if (is(field, SQL)) {
        decoder = field.decoder;
      } else {
        decoder = field.sql.decoder;
      }
      result[selectionItem.tsKey] = value === null ? null : decoder.mapFromDriverValue(value);
    }
  }
  return result;
}
var Relation, Relations, One, Many;
var init_relations = __esm(() => {
  init_table();
  init_column();
  init_entity();
  init_primary_keys();
  init_expressions();
  init_sql();
  Relation = class Relation {
    constructor(sourceTable, referencedTable, relationName) {
      this.sourceTable = sourceTable;
      this.referencedTable = referencedTable;
      this.relationName = relationName;
      this.referencedTableName = referencedTable[Table.Symbol.Name];
    }
    static [entityKind] = "Relation";
    referencedTableName;
    fieldName;
  };
  Relations = class Relations {
    constructor(table, config) {
      this.table = table;
      this.config = config;
    }
    static [entityKind] = "Relations";
  };
  One = class One extends Relation {
    constructor(sourceTable, referencedTable, config, isNullable) {
      super(sourceTable, referencedTable, config?.relationName);
      this.config = config;
      this.isNullable = isNullable;
    }
    static [entityKind] = "One";
    withFieldName(fieldName) {
      const relation = new One(this.sourceTable, this.referencedTable, this.config, this.isNullable);
      relation.fieldName = fieldName;
      return relation;
    }
  };
  Many = class Many extends Relation {
    constructor(sourceTable, referencedTable, config) {
      super(sourceTable, referencedTable, config?.relationName);
      this.config = config;
    }
    static [entityKind] = "Many";
    withFieldName(fieldName) {
      const relation = new Many(this.sourceTable, this.referencedTable, this.config);
      relation.fieldName = fieldName;
      return relation;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/functions/aggregate.js
function count(expression) {
  return sql`count(${expression || sql.raw("*")})`.mapWith(Number);
}
var init_aggregate = __esm(() => {
  init_sql();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/functions/vector.js
var init_vector = () => {};

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/functions/index.js
var init_functions = __esm(() => {
  init_aggregate();
  init_vector();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sql/index.js
var init_sql2 = __esm(() => {
  init_expressions();
  init_functions();
  init_sql();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/index.js
var init_drizzle_orm = __esm(() => {
  init_alias();
  init_column_builder();
  init_column();
  init_entity();
  init_errors();
  init_logger();
  init_query_promise();
  init_relations();
  init_sql2();
  init_subquery();
  init_table();
  init_utils();
  init_view_common();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/selection-proxy.js
var SelectionProxyHandler;
var init_selection_proxy = __esm(() => {
  init_alias();
  init_column();
  init_entity();
  init_sql();
  init_subquery();
  init_view_common();
  SelectionProxyHandler = class SelectionProxyHandler {
    static [entityKind] = "SelectionProxyHandler";
    config;
    constructor(config) {
      this.config = { ...config };
    }
    get(subquery, prop) {
      if (prop === "_") {
        return {
          ...subquery["_"],
          selectedFields: new Proxy(subquery._.selectedFields, this)
        };
      }
      if (prop === ViewBaseConfig) {
        return {
          ...subquery[ViewBaseConfig],
          selectedFields: new Proxy(subquery[ViewBaseConfig].selectedFields, this)
        };
      }
      if (typeof prop === "symbol") {
        return subquery[prop];
      }
      const columns = is(subquery, Subquery) ? subquery._.selectedFields : is(subquery, View) ? subquery[ViewBaseConfig].selectedFields : subquery;
      const value = columns[prop];
      if (is(value, SQL.Aliased)) {
        if (this.config.sqlAliasedBehavior === "sql" && !value.isSelectionField) {
          return value.sql;
        }
        const newValue = value.clone();
        newValue.isSelectionField = true;
        return newValue;
      }
      if (is(value, SQL)) {
        if (this.config.sqlBehavior === "sql") {
          return value;
        }
        throw new Error(`You tried to reference "${prop}" field from a subquery, which is a raw SQL field, but it doesn't have an alias declared. Please add an alias to the field using ".as('alias')" method.`);
      }
      if (is(value, Column)) {
        if (this.config.alias) {
          return new Proxy(value, new ColumnAliasProxyHandler(new Proxy(value.table, new TableAliasProxyHandler(this.config.alias, this.config.replaceOriginalName ?? false))));
        }
        return value;
      }
      if (typeof value !== "object" || value === null) {
        return value;
      }
      return new Proxy(value, new SelectionProxyHandler(this.config));
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/foreign-keys.js
var ForeignKeyBuilder, ForeignKey;
var init_foreign_keys = __esm(() => {
  init_entity();
  init_table_utils();
  ForeignKeyBuilder = class ForeignKeyBuilder {
    static [entityKind] = "SQLiteForeignKeyBuilder";
    reference;
    _onUpdate;
    _onDelete;
    constructor(config, actions) {
      this.reference = () => {
        const { name, columns, foreignColumns } = config();
        return { name, columns, foreignTable: foreignColumns[0].table, foreignColumns };
      };
      if (actions) {
        this._onUpdate = actions.onUpdate;
        this._onDelete = actions.onDelete;
      }
    }
    onUpdate(action) {
      this._onUpdate = action;
      return this;
    }
    onDelete(action) {
      this._onDelete = action;
      return this;
    }
    build(table) {
      return new ForeignKey(table, this);
    }
  };
  ForeignKey = class ForeignKey {
    constructor(table, builder) {
      this.table = table;
      this.reference = builder.reference;
      this.onUpdate = builder._onUpdate;
      this.onDelete = builder._onDelete;
    }
    static [entityKind] = "SQLiteForeignKey";
    reference;
    onUpdate;
    onDelete;
    getName() {
      const { name, columns, foreignColumns } = this.reference();
      const columnNames = columns.map((column) => column.name);
      const foreignColumnNames = foreignColumns.map((column) => column.name);
      const chunks = [
        this.table[TableName],
        ...columnNames,
        foreignColumns[0].table[TableName],
        ...foreignColumnNames
      ];
      return name ?? `${chunks.join("_")}_fk`;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/unique-constraint.js
function uniqueKeyName(table, columns) {
  return `${table[TableName]}_${columns.join("_")}_unique`;
}
var init_unique_constraint = __esm(() => {
  init_table_utils();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/common.js
var SQLiteColumnBuilder, SQLiteColumn;
var init_common = __esm(() => {
  init_column_builder();
  init_column();
  init_entity();
  init_foreign_keys();
  init_unique_constraint();
  SQLiteColumnBuilder = class SQLiteColumnBuilder extends ColumnBuilder {
    static [entityKind] = "SQLiteColumnBuilder";
    foreignKeyConfigs = [];
    references(ref, actions = {}) {
      this.foreignKeyConfigs.push({ ref, actions });
      return this;
    }
    unique(name) {
      this.config.isUnique = true;
      this.config.uniqueName = name;
      return this;
    }
    generatedAlwaysAs(as, config) {
      this.config.generated = {
        as,
        type: "always",
        mode: config?.mode ?? "virtual"
      };
      return this;
    }
    buildForeignKeys(column, table) {
      return this.foreignKeyConfigs.map(({ ref, actions }) => {
        return ((ref2, actions2) => {
          const builder = new ForeignKeyBuilder(() => {
            const foreignColumn = ref2();
            return { columns: [column], foreignColumns: [foreignColumn] };
          });
          if (actions2.onUpdate) {
            builder.onUpdate(actions2.onUpdate);
          }
          if (actions2.onDelete) {
            builder.onDelete(actions2.onDelete);
          }
          return builder.build(table);
        })(ref, actions);
      });
    }
  };
  SQLiteColumn = class SQLiteColumn extends Column {
    constructor(table, config) {
      if (!config.uniqueName) {
        config.uniqueName = uniqueKeyName(table, [config.name]);
      }
      super(table, config);
      this.table = table;
    }
    static [entityKind] = "SQLiteColumn";
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/blob.js
function blob(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "json") {
    return new SQLiteBlobJsonBuilder(name);
  }
  if (config?.mode === "bigint") {
    return new SQLiteBigIntBuilder(name);
  }
  return new SQLiteBlobBufferBuilder(name);
}
var SQLiteBigIntBuilder, SQLiteBigInt, SQLiteBlobJsonBuilder, SQLiteBlobJson, SQLiteBlobBufferBuilder, SQLiteBlobBuffer;
var init_blob = __esm(() => {
  init_entity();
  init_utils();
  init_common();
  SQLiteBigIntBuilder = class SQLiteBigIntBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteBigIntBuilder";
    constructor(name) {
      super(name, "bigint", "SQLiteBigInt");
    }
    build(table) {
      return new SQLiteBigInt(table, this.config);
    }
  };
  SQLiteBigInt = class SQLiteBigInt extends SQLiteColumn {
    static [entityKind] = "SQLiteBigInt";
    getSQLType() {
      return "blob";
    }
    mapFromDriverValue(value) {
      if (typeof Buffer !== "undefined" && Buffer.from) {
        const buf = Buffer.isBuffer(value) ? value : value instanceof ArrayBuffer ? Buffer.from(value) : value.buffer ? Buffer.from(value.buffer, value.byteOffset, value.byteLength) : Buffer.from(value);
        return BigInt(buf.toString("utf8"));
      }
      return BigInt(textDecoder2.decode(value));
    }
    mapToDriverValue(value) {
      return Buffer.from(value.toString());
    }
  };
  SQLiteBlobJsonBuilder = class SQLiteBlobJsonBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteBlobJsonBuilder";
    constructor(name) {
      super(name, "json", "SQLiteBlobJson");
    }
    build(table) {
      return new SQLiteBlobJson(table, this.config);
    }
  };
  SQLiteBlobJson = class SQLiteBlobJson extends SQLiteColumn {
    static [entityKind] = "SQLiteBlobJson";
    getSQLType() {
      return "blob";
    }
    mapFromDriverValue(value) {
      if (typeof Buffer !== "undefined" && Buffer.from) {
        const buf = Buffer.isBuffer(value) ? value : value instanceof ArrayBuffer ? Buffer.from(value) : value.buffer ? Buffer.from(value.buffer, value.byteOffset, value.byteLength) : Buffer.from(value);
        return JSON.parse(buf.toString("utf8"));
      }
      return JSON.parse(textDecoder2.decode(value));
    }
    mapToDriverValue(value) {
      return Buffer.from(JSON.stringify(value));
    }
  };
  SQLiteBlobBufferBuilder = class SQLiteBlobBufferBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteBlobBufferBuilder";
    constructor(name) {
      super(name, "buffer", "SQLiteBlobBuffer");
    }
    build(table) {
      return new SQLiteBlobBuffer(table, this.config);
    }
  };
  SQLiteBlobBuffer = class SQLiteBlobBuffer extends SQLiteColumn {
    static [entityKind] = "SQLiteBlobBuffer";
    mapFromDriverValue(value) {
      if (Buffer.isBuffer(value)) {
        return value;
      }
      return Buffer.from(value);
    }
    getSQLType() {
      return "blob";
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/custom.js
function customType(customTypeParams) {
  return (a, b) => {
    const { name, config } = getColumnNameAndConfig(a, b);
    return new SQLiteCustomColumnBuilder(name, config, customTypeParams);
  };
}
var SQLiteCustomColumnBuilder, SQLiteCustomColumn;
var init_custom = __esm(() => {
  init_entity();
  init_utils();
  init_common();
  SQLiteCustomColumnBuilder = class SQLiteCustomColumnBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteCustomColumnBuilder";
    constructor(name, fieldConfig, customTypeParams) {
      super(name, "custom", "SQLiteCustomColumn");
      this.config.fieldConfig = fieldConfig;
      this.config.customTypeParams = customTypeParams;
    }
    build(table) {
      return new SQLiteCustomColumn(table, this.config);
    }
  };
  SQLiteCustomColumn = class SQLiteCustomColumn extends SQLiteColumn {
    static [entityKind] = "SQLiteCustomColumn";
    sqlName;
    mapTo;
    mapFrom;
    constructor(table, config) {
      super(table, config);
      this.sqlName = config.customTypeParams.dataType(config.fieldConfig);
      this.mapTo = config.customTypeParams.toDriver;
      this.mapFrom = config.customTypeParams.fromDriver;
    }
    getSQLType() {
      return this.sqlName;
    }
    mapFromDriverValue(value) {
      return typeof this.mapFrom === "function" ? this.mapFrom(value) : value;
    }
    mapToDriverValue(value) {
      return typeof this.mapTo === "function" ? this.mapTo(value) : value;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/integer.js
function integer(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config?.mode === "timestamp" || config?.mode === "timestamp_ms") {
    return new SQLiteTimestampBuilder(name, config.mode);
  }
  if (config?.mode === "boolean") {
    return new SQLiteBooleanBuilder(name, config.mode);
  }
  return new SQLiteIntegerBuilder(name);
}
var SQLiteBaseIntegerBuilder, SQLiteBaseInteger, SQLiteIntegerBuilder, SQLiteInteger, SQLiteTimestampBuilder, SQLiteTimestamp, SQLiteBooleanBuilder, SQLiteBoolean;
var init_integer = __esm(() => {
  init_entity();
  init_sql();
  init_utils();
  init_common();
  SQLiteBaseIntegerBuilder = class SQLiteBaseIntegerBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteBaseIntegerBuilder";
    constructor(name, dataType, columnType) {
      super(name, dataType, columnType);
      this.config.autoIncrement = false;
    }
    primaryKey(config) {
      if (config?.autoIncrement) {
        this.config.autoIncrement = true;
      }
      this.config.hasDefault = true;
      return super.primaryKey();
    }
  };
  SQLiteBaseInteger = class SQLiteBaseInteger extends SQLiteColumn {
    static [entityKind] = "SQLiteBaseInteger";
    autoIncrement = this.config.autoIncrement;
    getSQLType() {
      return "integer";
    }
  };
  SQLiteIntegerBuilder = class SQLiteIntegerBuilder extends SQLiteBaseIntegerBuilder {
    static [entityKind] = "SQLiteIntegerBuilder";
    constructor(name) {
      super(name, "number", "SQLiteInteger");
    }
    build(table) {
      return new SQLiteInteger(table, this.config);
    }
  };
  SQLiteInteger = class SQLiteInteger extends SQLiteBaseInteger {
    static [entityKind] = "SQLiteInteger";
  };
  SQLiteTimestampBuilder = class SQLiteTimestampBuilder extends SQLiteBaseIntegerBuilder {
    static [entityKind] = "SQLiteTimestampBuilder";
    constructor(name, mode) {
      super(name, "date", "SQLiteTimestamp");
      this.config.mode = mode;
    }
    defaultNow() {
      return this.default(sql`(cast((julianday('now') - 2440587.5)*86400000 as integer))`);
    }
    build(table) {
      return new SQLiteTimestamp(table, this.config);
    }
  };
  SQLiteTimestamp = class SQLiteTimestamp extends SQLiteBaseInteger {
    static [entityKind] = "SQLiteTimestamp";
    mode = this.config.mode;
    mapFromDriverValue(value) {
      if (this.config.mode === "timestamp") {
        return new Date(value * 1000);
      }
      return new Date(value);
    }
    mapToDriverValue(value) {
      const unix = value.getTime();
      if (this.config.mode === "timestamp") {
        return Math.floor(unix / 1000);
      }
      return unix;
    }
  };
  SQLiteBooleanBuilder = class SQLiteBooleanBuilder extends SQLiteBaseIntegerBuilder {
    static [entityKind] = "SQLiteBooleanBuilder";
    constructor(name, mode) {
      super(name, "boolean", "SQLiteBoolean");
      this.config.mode = mode;
    }
    build(table) {
      return new SQLiteBoolean(table, this.config);
    }
  };
  SQLiteBoolean = class SQLiteBoolean extends SQLiteBaseInteger {
    static [entityKind] = "SQLiteBoolean";
    mode = this.config.mode;
    mapFromDriverValue(value) {
      return Number(value) === 1;
    }
    mapToDriverValue(value) {
      return value ? 1 : 0;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/numeric.js
function numeric(a, b) {
  const { name, config } = getColumnNameAndConfig(a, b);
  const mode = config?.mode;
  return mode === "number" ? new SQLiteNumericNumberBuilder(name) : mode === "bigint" ? new SQLiteNumericBigIntBuilder(name) : new SQLiteNumericBuilder(name);
}
var SQLiteNumericBuilder, SQLiteNumeric, SQLiteNumericNumberBuilder, SQLiteNumericNumber, SQLiteNumericBigIntBuilder, SQLiteNumericBigInt;
var init_numeric = __esm(() => {
  init_entity();
  init_utils();
  init_common();
  SQLiteNumericBuilder = class SQLiteNumericBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteNumericBuilder";
    constructor(name) {
      super(name, "string", "SQLiteNumeric");
    }
    build(table) {
      return new SQLiteNumeric(table, this.config);
    }
  };
  SQLiteNumeric = class SQLiteNumeric extends SQLiteColumn {
    static [entityKind] = "SQLiteNumeric";
    mapFromDriverValue(value) {
      if (typeof value === "string")
        return value;
      return String(value);
    }
    getSQLType() {
      return "numeric";
    }
  };
  SQLiteNumericNumberBuilder = class SQLiteNumericNumberBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteNumericNumberBuilder";
    constructor(name) {
      super(name, "number", "SQLiteNumericNumber");
    }
    build(table) {
      return new SQLiteNumericNumber(table, this.config);
    }
  };
  SQLiteNumericNumber = class SQLiteNumericNumber extends SQLiteColumn {
    static [entityKind] = "SQLiteNumericNumber";
    mapFromDriverValue(value) {
      if (typeof value === "number")
        return value;
      return Number(value);
    }
    mapToDriverValue = String;
    getSQLType() {
      return "numeric";
    }
  };
  SQLiteNumericBigIntBuilder = class SQLiteNumericBigIntBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteNumericBigIntBuilder";
    constructor(name) {
      super(name, "bigint", "SQLiteNumericBigInt");
    }
    build(table) {
      return new SQLiteNumericBigInt(table, this.config);
    }
  };
  SQLiteNumericBigInt = class SQLiteNumericBigInt extends SQLiteColumn {
    static [entityKind] = "SQLiteNumericBigInt";
    mapFromDriverValue = BigInt;
    mapToDriverValue = String;
    getSQLType() {
      return "numeric";
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/real.js
function real(name) {
  return new SQLiteRealBuilder(name ?? "");
}
var SQLiteRealBuilder, SQLiteReal;
var init_real = __esm(() => {
  init_entity();
  init_common();
  SQLiteRealBuilder = class SQLiteRealBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteRealBuilder";
    constructor(name) {
      super(name, "number", "SQLiteReal");
    }
    build(table) {
      return new SQLiteReal(table, this.config);
    }
  };
  SQLiteReal = class SQLiteReal extends SQLiteColumn {
    static [entityKind] = "SQLiteReal";
    getSQLType() {
      return "real";
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/text.js
function text(a, b = {}) {
  const { name, config } = getColumnNameAndConfig(a, b);
  if (config.mode === "json") {
    return new SQLiteTextJsonBuilder(name);
  }
  return new SQLiteTextBuilder(name, config);
}
var SQLiteTextBuilder, SQLiteText, SQLiteTextJsonBuilder, SQLiteTextJson;
var init_text = __esm(() => {
  init_entity();
  init_utils();
  init_common();
  SQLiteTextBuilder = class SQLiteTextBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteTextBuilder";
    constructor(name, config) {
      super(name, "string", "SQLiteText");
      this.config.enumValues = config.enum;
      this.config.length = config.length;
    }
    build(table) {
      return new SQLiteText(table, this.config);
    }
  };
  SQLiteText = class SQLiteText extends SQLiteColumn {
    static [entityKind] = "SQLiteText";
    enumValues = this.config.enumValues;
    length = this.config.length;
    constructor(table, config) {
      super(table, config);
    }
    getSQLType() {
      return `text${this.config.length ? `(${this.config.length})` : ""}`;
    }
  };
  SQLiteTextJsonBuilder = class SQLiteTextJsonBuilder extends SQLiteColumnBuilder {
    static [entityKind] = "SQLiteTextJsonBuilder";
    constructor(name) {
      super(name, "json", "SQLiteTextJson");
    }
    build(table) {
      return new SQLiteTextJson(table, this.config);
    }
  };
  SQLiteTextJson = class SQLiteTextJson extends SQLiteColumn {
    static [entityKind] = "SQLiteTextJson";
    getSQLType() {
      return "text";
    }
    mapFromDriverValue(value) {
      return JSON.parse(value);
    }
    mapToDriverValue(value) {
      return JSON.stringify(value);
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/all.js
function getSQLiteColumnBuilders() {
  return {
    blob,
    customType,
    integer,
    numeric,
    real,
    text
  };
}
var init_all = __esm(() => {
  init_blob();
  init_custom();
  init_integer();
  init_numeric();
  init_real();
  init_text();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/table.js
function sqliteTableBase(name, columns, extraConfig, schema, baseName = name) {
  const rawTable = new SQLiteTable(name, schema, baseName);
  const parsedColumns = typeof columns === "function" ? columns(getSQLiteColumnBuilders()) : columns;
  const builtColumns = Object.fromEntries(Object.entries(parsedColumns).map(([name2, colBuilderBase]) => {
    const colBuilder = colBuilderBase;
    colBuilder.setName(name2);
    const column = colBuilder.build(rawTable);
    rawTable[InlineForeignKeys2].push(...colBuilder.buildForeignKeys(column, rawTable));
    return [name2, column];
  }));
  const table = Object.assign(rawTable, builtColumns);
  table[Table.Symbol.Columns] = builtColumns;
  table[Table.Symbol.ExtraConfigColumns] = builtColumns;
  if (extraConfig) {
    table[SQLiteTable.Symbol.ExtraConfigBuilder] = extraConfig;
  }
  return table;
}
var InlineForeignKeys2, SQLiteTable, sqliteTable = (name, columns, extraConfig) => {
  return sqliteTableBase(name, columns, extraConfig);
};
var init_table3 = __esm(() => {
  init_entity();
  init_table();
  init_all();
  InlineForeignKeys2 = Symbol.for("drizzle:SQLiteInlineForeignKeys");
  SQLiteTable = class SQLiteTable extends Table {
    static [entityKind] = "SQLiteTable";
    static Symbol = Object.assign({}, Table.Symbol, {
      InlineForeignKeys: InlineForeignKeys2
    });
    [Table.Symbol.Columns];
    [InlineForeignKeys2] = [];
    [Table.Symbol.ExtraConfigBuilder] = undefined;
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/checks.js
var init_checks = () => {};

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/indexes.js
function index(name) {
  return new IndexBuilderOn(name, false);
}
var IndexBuilderOn, IndexBuilder, Index;
var init_indexes = __esm(() => {
  init_entity();
  IndexBuilderOn = class IndexBuilderOn {
    constructor(name, unique) {
      this.name = name;
      this.unique = unique;
    }
    static [entityKind] = "SQLiteIndexBuilderOn";
    on(...columns) {
      return new IndexBuilder(this.name, columns, this.unique);
    }
  };
  IndexBuilder = class IndexBuilder {
    static [entityKind] = "SQLiteIndexBuilder";
    config;
    constructor(name, columns, unique) {
      this.config = {
        name,
        columns,
        unique,
        where: undefined
      };
    }
    where(condition) {
      this.config.where = condition;
      return this;
    }
    build(table) {
      return new Index(this.config, table);
    }
  };
  Index = class Index {
    static [entityKind] = "SQLiteIndex";
    config;
    constructor(config, table) {
      this.config = { ...config, table };
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/primary-keys.js
var init_primary_keys2 = () => {};

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/utils.js
function extractUsedTable(table) {
  if (is(table, SQLiteTable)) {
    return [`${table[Table.Symbol.BaseName]}`];
  }
  if (is(table, Subquery)) {
    return table._.usedTables ?? [];
  }
  if (is(table, SQL)) {
    return table.usedTables ?? [];
  }
  return [];
}
var init_utils2 = __esm(() => {
  init_entity();
  init_sql();
  init_subquery();
  init_table();
  init_table3();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/delete.js
var SQLiteDeleteBase;
var init_delete = __esm(() => {
  init_entity();
  init_query_promise();
  init_selection_proxy();
  init_table3();
  init_table();
  init_utils();
  init_utils2();
  SQLiteDeleteBase = class SQLiteDeleteBase extends QueryPromise {
    constructor(table, session, dialect, withList) {
      super();
      this.table = table;
      this.session = session;
      this.dialect = dialect;
      this.config = { table, withList };
    }
    static [entityKind] = "SQLiteDelete";
    config;
    where(where) {
      this.config.where = where;
      return this;
    }
    orderBy(...columns) {
      if (typeof columns[0] === "function") {
        const orderBy = columns[0](new Proxy(this.config.table[Table.Symbol.Columns], new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })));
        const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
        this.config.orderBy = orderByArray;
      } else {
        const orderByArray = columns;
        this.config.orderBy = orderByArray;
      }
      return this;
    }
    limit(limit) {
      this.config.limit = limit;
      return this;
    }
    returning(fields = this.table[SQLiteTable.Symbol.Columns]) {
      this.config.returning = orderSelectedFields(fields);
      return this;
    }
    getSQL() {
      return this.dialect.buildDeleteQuery(this.config);
    }
    toSQL() {
      const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
      return rest;
    }
    _prepare(isOneTimeQuery = true) {
      return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, undefined, {
        type: "delete",
        tables: extractUsedTable(this.config.table)
      });
    }
    prepare() {
      return this._prepare(false);
    }
    run = (placeholderValues) => {
      return this._prepare().run(placeholderValues);
    };
    all = (placeholderValues) => {
      return this._prepare().all(placeholderValues);
    };
    get = (placeholderValues) => {
      return this._prepare().get(placeholderValues);
    };
    values = (placeholderValues) => {
      return this._prepare().values(placeholderValues);
    };
    async execute(placeholderValues) {
      return this._prepare().execute(placeholderValues);
    }
    $dynamic() {
      return this;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/casing.js
function toSnakeCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.map((word) => word.toLowerCase()).join("_");
}
function toCamelCase(input) {
  const words = input.replace(/['\u2019]/g, "").match(/[\da-z]+|[A-Z]+(?![a-z])|[A-Z][\da-z]+/g) ?? [];
  return words.reduce((acc, word, i) => {
    const formattedWord = i === 0 ? word.toLowerCase() : `${word[0].toUpperCase()}${word.slice(1)}`;
    return acc + formattedWord;
  }, "");
}
function noopCase(input) {
  return input;
}
var CasingCache;
var init_casing = __esm(() => {
  init_entity();
  init_table();
  CasingCache = class CasingCache {
    static [entityKind] = "CasingCache";
    cache = {};
    cachedTables = {};
    convert;
    constructor(casing) {
      this.convert = casing === "snake_case" ? toSnakeCase : casing === "camelCase" ? toCamelCase : noopCase;
    }
    getColumnCasing(column) {
      if (!column.keyAsName)
        return column.name;
      const schema = column.table[Table.Symbol.Schema] ?? "public";
      const tableName = column.table[Table.Symbol.OriginalName];
      const key = `${schema}.${tableName}.${column.name}`;
      if (!this.cache[key]) {
        this.cacheTable(column.table);
      }
      return this.cache[key];
    }
    cacheTable(table) {
      const schema = table[Table.Symbol.Schema] ?? "public";
      const tableName = table[Table.Symbol.OriginalName];
      const tableKey = `${schema}.${tableName}`;
      if (!this.cachedTables[tableKey]) {
        for (const column of Object.values(table[Table.Symbol.Columns])) {
          const columnKey = `${tableKey}.${column.name}`;
          this.cache[columnKey] = this.convert(column.name);
        }
        this.cachedTables[tableKey] = true;
      }
    }
    clearCache() {
      this.cache = {};
      this.cachedTables = {};
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/columns/index.js
var init_columns = __esm(() => {
  init_blob();
  init_common();
  init_custom();
  init_integer();
  init_numeric();
  init_real();
  init_text();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/view-base.js
var SQLiteViewBase;
var init_view_base = __esm(() => {
  init_entity();
  init_sql();
  SQLiteViewBase = class SQLiteViewBase extends View {
    static [entityKind] = "SQLiteViewBase";
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/dialect.js
var SQLiteDialect, SQLiteSyncDialect, SQLiteAsyncDialect;
var init_dialect = __esm(() => {
  init_alias();
  init_casing();
  init_column();
  init_entity();
  init_errors();
  init_relations();
  init_sql2();
  init_sql();
  init_columns();
  init_table3();
  init_subquery();
  init_table();
  init_utils();
  init_view_common();
  init_view_base();
  SQLiteDialect = class SQLiteDialect {
    static [entityKind] = "SQLiteDialect";
    casing;
    constructor(config) {
      this.casing = new CasingCache(config?.casing);
    }
    escapeName(name) {
      return `"${name.replace(/"/g, '""')}"`;
    }
    escapeParam(_num) {
      return "?";
    }
    escapeString(str) {
      return `'${str.replace(/'/g, "''")}'`;
    }
    buildWithCTE(queries) {
      if (!queries?.length)
        return;
      const withSqlChunks = [sql`with `];
      for (const [i, w] of queries.entries()) {
        withSqlChunks.push(sql`${sql.identifier(w._.alias)} as (${w._.sql})`);
        if (i < queries.length - 1) {
          withSqlChunks.push(sql`, `);
        }
      }
      withSqlChunks.push(sql` `);
      return sql.join(withSqlChunks);
    }
    buildDeleteQuery({
      table,
      where,
      returning,
      withList,
      limit,
      orderBy
    }) {
      const withSql = this.buildWithCTE(withList);
      const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : undefined;
      const whereSql = where ? sql` where ${where}` : undefined;
      const orderBySql = this.buildOrderBy(orderBy);
      const limitSql = this.buildLimit(limit);
      return sql`${withSql}delete from ${table}${whereSql}${returningSql}${orderBySql}${limitSql}`;
    }
    buildUpdateSet(table, set) {
      const tableColumns = table[Table.Symbol.Columns];
      const columnNames = Object.keys(tableColumns).filter((colName) => set[colName] !== undefined || tableColumns[colName]?.onUpdateFn !== undefined);
      const setSize = columnNames.length;
      return sql.join(columnNames.flatMap((colName, i) => {
        const col = tableColumns[colName];
        const onUpdateFnResult = col.onUpdateFn?.();
        const value = set[colName] ?? (is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col));
        const res = sql`${sql.identifier(this.casing.getColumnCasing(col))} = ${value}`;
        if (i < setSize - 1) {
          return [res, sql.raw(", ")];
        }
        return [res];
      }));
    }
    buildUpdateQuery({
      table,
      set,
      where,
      returning,
      withList,
      joins,
      from,
      limit,
      orderBy
    }) {
      const withSql = this.buildWithCTE(withList);
      const setSql = this.buildUpdateSet(table, set);
      const fromSql = from && sql.join([sql.raw(" from "), this.buildFromTable(from)]);
      const joinsSql = this.buildJoins(joins);
      const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : undefined;
      const whereSql = where ? sql` where ${where}` : undefined;
      const orderBySql = this.buildOrderBy(orderBy);
      const limitSql = this.buildLimit(limit);
      return sql`${withSql}update ${table} set ${setSql}${fromSql}${joinsSql}${whereSql}${returningSql}${orderBySql}${limitSql}`;
    }
    buildSelection(fields, { isSingleTable = false } = {}) {
      const columnsLen = fields.length;
      const chunks = fields.flatMap(({ field }, i) => {
        const chunk = [];
        if (is(field, SQL.Aliased) && field.isSelectionField) {
          chunk.push(sql.identifier(field.fieldAlias));
        } else if (is(field, SQL.Aliased) || is(field, SQL)) {
          const query = is(field, SQL.Aliased) ? field.sql : field;
          if (isSingleTable) {
            chunk.push(new SQL(query.queryChunks.map((c) => {
              if (is(c, Column)) {
                return sql.identifier(this.casing.getColumnCasing(c));
              }
              return c;
            })));
          } else {
            chunk.push(query);
          }
          if (is(field, SQL.Aliased)) {
            chunk.push(sql` as ${sql.identifier(field.fieldAlias)}`);
          }
        } else if (is(field, Column)) {
          const tableName = field.table[Table.Symbol.Name];
          if (field.columnType === "SQLiteNumericBigInt") {
            if (isSingleTable) {
              chunk.push(sql`cast(${sql.identifier(this.casing.getColumnCasing(field))} as text)`);
            } else {
              chunk.push(sql`cast(${sql.identifier(tableName)}.${sql.identifier(this.casing.getColumnCasing(field))} as text)`);
            }
          } else {
            if (isSingleTable) {
              chunk.push(sql.identifier(this.casing.getColumnCasing(field)));
            } else {
              chunk.push(sql`${sql.identifier(tableName)}.${sql.identifier(this.casing.getColumnCasing(field))}`);
            }
          }
        } else if (is(field, Subquery)) {
          const entries = Object.entries(field._.selectedFields);
          if (entries.length === 1) {
            const entry = entries[0][1];
            const fieldDecoder = is(entry, SQL) ? entry.decoder : is(entry, Column) ? { mapFromDriverValue: (v) => entry.mapFromDriverValue(v) } : entry.sql.decoder;
            if (fieldDecoder)
              field._.sql.decoder = fieldDecoder;
          }
          chunk.push(field);
        }
        if (i < columnsLen - 1) {
          chunk.push(sql`, `);
        }
        return chunk;
      });
      return sql.join(chunks);
    }
    buildJoins(joins) {
      if (!joins || joins.length === 0) {
        return;
      }
      const joinsArray = [];
      if (joins) {
        for (const [index, joinMeta] of joins.entries()) {
          if (index === 0) {
            joinsArray.push(sql` `);
          }
          const table = joinMeta.table;
          const onSql = joinMeta.on ? sql` on ${joinMeta.on}` : undefined;
          if (is(table, SQLiteTable)) {
            const tableName = table[SQLiteTable.Symbol.Name];
            const tableSchema = table[SQLiteTable.Symbol.Schema];
            const origTableName = table[SQLiteTable.Symbol.OriginalName];
            const alias = tableName === origTableName ? undefined : joinMeta.alias;
            joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join ${tableSchema ? sql`${sql.identifier(tableSchema)}.` : undefined}${sql.identifier(origTableName)}${alias && sql` ${sql.identifier(alias)}`}${onSql}`);
          } else {
            joinsArray.push(sql`${sql.raw(joinMeta.joinType)} join ${table}${onSql}`);
          }
          if (index < joins.length - 1) {
            joinsArray.push(sql` `);
          }
        }
      }
      return sql.join(joinsArray);
    }
    buildLimit(limit) {
      return typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : undefined;
    }
    buildOrderBy(orderBy) {
      const orderByList = [];
      if (orderBy) {
        for (const [index, orderByValue] of orderBy.entries()) {
          orderByList.push(orderByValue);
          if (index < orderBy.length - 1) {
            orderByList.push(sql`, `);
          }
        }
      }
      return orderByList.length > 0 ? sql` order by ${sql.join(orderByList)}` : undefined;
    }
    buildFromTable(table) {
      if (is(table, Table) && table[Table.Symbol.IsAlias]) {
        return sql`${sql`${sql.identifier(table[Table.Symbol.Schema] ?? "")}.`.if(table[Table.Symbol.Schema])}${sql.identifier(table[Table.Symbol.OriginalName])} ${sql.identifier(table[Table.Symbol.Name])}`;
      }
      return table;
    }
    buildSelectQuery({
      withList,
      fields,
      fieldsFlat,
      where,
      having,
      table,
      joins,
      orderBy,
      groupBy,
      limit,
      offset,
      distinct,
      setOperators
    }) {
      const fieldsList = fieldsFlat ?? orderSelectedFields(fields);
      for (const f of fieldsList) {
        if (is(f.field, Column) && getTableName(f.field.table) !== (is(table, Subquery) ? table._.alias : is(table, SQLiteViewBase) ? table[ViewBaseConfig].name : is(table, SQL) ? undefined : getTableName(table)) && !((table2) => joins?.some(({ alias }) => alias === (table2[Table.Symbol.IsAlias] ? getTableName(table2) : table2[Table.Symbol.BaseName])))(f.field.table)) {
          const tableName = getTableName(f.field.table);
          throw new Error(`Your "${f.path.join("->")}" field references a column "${tableName}"."${f.field.name}", but the table "${tableName}" is not part of the query! Did you forget to join it?`);
        }
      }
      const isSingleTable = !joins || joins.length === 0;
      const withSql = this.buildWithCTE(withList);
      const distinctSql = distinct ? sql` distinct` : undefined;
      const selection = this.buildSelection(fieldsList, { isSingleTable });
      const tableSql = this.buildFromTable(table);
      const joinsSql = this.buildJoins(joins);
      const whereSql = where ? sql` where ${where}` : undefined;
      const havingSql = having ? sql` having ${having}` : undefined;
      const groupByList = [];
      if (groupBy) {
        for (const [index, groupByValue] of groupBy.entries()) {
          groupByList.push(groupByValue);
          if (index < groupBy.length - 1) {
            groupByList.push(sql`, `);
          }
        }
      }
      const groupBySql = groupByList.length > 0 ? sql` group by ${sql.join(groupByList)}` : undefined;
      const orderBySql = this.buildOrderBy(orderBy);
      const limitSql = this.buildLimit(limit);
      const offsetSql = offset ? sql` offset ${offset}` : undefined;
      const finalQuery = sql`${withSql}select${distinctSql} ${selection} from ${tableSql}${joinsSql}${whereSql}${groupBySql}${havingSql}${orderBySql}${limitSql}${offsetSql}`;
      if (setOperators.length > 0) {
        return this.buildSetOperations(finalQuery, setOperators);
      }
      return finalQuery;
    }
    buildSetOperations(leftSelect, setOperators) {
      const [setOperator, ...rest] = setOperators;
      if (!setOperator) {
        throw new Error("Cannot pass undefined values to any set operator");
      }
      if (rest.length === 0) {
        return this.buildSetOperationQuery({ leftSelect, setOperator });
      }
      return this.buildSetOperations(this.buildSetOperationQuery({ leftSelect, setOperator }), rest);
    }
    buildSetOperationQuery({
      leftSelect,
      setOperator: { type, isAll, rightSelect, limit, orderBy, offset }
    }) {
      const leftChunk = sql`${leftSelect.getSQL()} `;
      const rightChunk = sql`${rightSelect.getSQL()}`;
      let orderBySql;
      if (orderBy && orderBy.length > 0) {
        const orderByValues = [];
        for (const singleOrderBy of orderBy) {
          if (is(singleOrderBy, SQLiteColumn)) {
            orderByValues.push(sql.identifier(singleOrderBy.name));
          } else if (is(singleOrderBy, SQL)) {
            for (let i = 0;i < singleOrderBy.queryChunks.length; i++) {
              const chunk = singleOrderBy.queryChunks[i];
              if (is(chunk, SQLiteColumn)) {
                singleOrderBy.queryChunks[i] = sql.identifier(this.casing.getColumnCasing(chunk));
              }
            }
            orderByValues.push(sql`${singleOrderBy}`);
          } else {
            orderByValues.push(sql`${singleOrderBy}`);
          }
        }
        orderBySql = sql` order by ${sql.join(orderByValues, sql`, `)}`;
      }
      const limitSql = typeof limit === "object" || typeof limit === "number" && limit >= 0 ? sql` limit ${limit}` : undefined;
      const operatorChunk = sql.raw(`${type} ${isAll ? "all " : ""}`);
      const offsetSql = offset ? sql` offset ${offset}` : undefined;
      return sql`${leftChunk}${operatorChunk}${rightChunk}${orderBySql}${limitSql}${offsetSql}`;
    }
    buildInsertQuery({
      table,
      values: valuesOrSelect,
      onConflict,
      returning,
      withList,
      select
    }) {
      const valuesSqlList = [];
      const columns = table[Table.Symbol.Columns];
      const colEntries = Object.entries(columns).filter(([_, col]) => !col.shouldDisableInsert());
      const insertOrder = colEntries.map(([, column]) => sql.identifier(this.casing.getColumnCasing(column)));
      if (select) {
        const select2 = valuesOrSelect;
        if (is(select2, SQL)) {
          valuesSqlList.push(select2);
        } else {
          valuesSqlList.push(select2.getSQL());
        }
      } else {
        const values = valuesOrSelect;
        valuesSqlList.push(sql.raw("values "));
        for (const [valueIndex, value] of values.entries()) {
          const valueList = [];
          for (const [fieldName, col] of colEntries) {
            const colValue = value[fieldName];
            if (colValue === undefined || is(colValue, Param) && colValue.value === undefined) {
              let defaultValue;
              if (col.default !== null && col.default !== undefined) {
                defaultValue = is(col.default, SQL) ? col.default : sql.param(col.default, col);
              } else if (col.defaultFn !== undefined) {
                const defaultFnResult = col.defaultFn();
                defaultValue = is(defaultFnResult, SQL) ? defaultFnResult : sql.param(defaultFnResult, col);
              } else if (!col.default && col.onUpdateFn !== undefined) {
                const onUpdateFnResult = col.onUpdateFn();
                defaultValue = is(onUpdateFnResult, SQL) ? onUpdateFnResult : sql.param(onUpdateFnResult, col);
              } else {
                defaultValue = sql`null`;
              }
              valueList.push(defaultValue);
            } else {
              valueList.push(colValue);
            }
          }
          valuesSqlList.push(valueList);
          if (valueIndex < values.length - 1) {
            valuesSqlList.push(sql`, `);
          }
        }
      }
      const withSql = this.buildWithCTE(withList);
      const valuesSql = sql.join(valuesSqlList);
      const returningSql = returning ? sql` returning ${this.buildSelection(returning, { isSingleTable: true })}` : undefined;
      const onConflictSql = onConflict?.length ? sql.join(onConflict) : undefined;
      return sql`${withSql}insert into ${table} ${insertOrder} ${valuesSql}${onConflictSql}${returningSql}`;
    }
    sqlToQuery(sql2, invokeSource) {
      return sql2.toQuery({
        casing: this.casing,
        escapeName: this.escapeName,
        escapeParam: this.escapeParam,
        escapeString: this.escapeString,
        invokeSource
      });
    }
    buildRelationalQuery({
      fullSchema,
      schema,
      tableNamesMap,
      table,
      tableConfig,
      queryConfig: config,
      tableAlias,
      nestedQueryRelation,
      joinOn
    }) {
      let selection = [];
      let limit, offset, orderBy = [], where;
      const joins = [];
      if (config === true) {
        const selectionEntries = Object.entries(tableConfig.columns);
        selection = selectionEntries.map(([key, value]) => ({
          dbKey: value.name,
          tsKey: key,
          field: aliasedTableColumn(value, tableAlias),
          relationTableTsKey: undefined,
          isJson: false,
          selection: []
        }));
      } else {
        const aliasedColumns = Object.fromEntries(Object.entries(tableConfig.columns).map(([key, value]) => [
          key,
          aliasedTableColumn(value, tableAlias)
        ]));
        if (config.where) {
          const whereSql = typeof config.where === "function" ? config.where(aliasedColumns, getOperators()) : config.where;
          where = whereSql && mapColumnsInSQLToAlias(whereSql, tableAlias);
        }
        const fieldsSelection = [];
        let selectedColumns = [];
        if (config.columns) {
          let isIncludeMode = false;
          for (const [field, value] of Object.entries(config.columns)) {
            if (value === undefined) {
              continue;
            }
            if (field in tableConfig.columns) {
              if (!isIncludeMode && value === true) {
                isIncludeMode = true;
              }
              selectedColumns.push(field);
            }
          }
          if (selectedColumns.length > 0) {
            selectedColumns = isIncludeMode ? selectedColumns.filter((c) => config.columns?.[c] === true) : Object.keys(tableConfig.columns).filter((key) => !selectedColumns.includes(key));
          }
        } else {
          selectedColumns = Object.keys(tableConfig.columns);
        }
        for (const field of selectedColumns) {
          const column = tableConfig.columns[field];
          fieldsSelection.push({ tsKey: field, value: column });
        }
        let selectedRelations = [];
        if (config.with) {
          selectedRelations = Object.entries(config.with).filter((entry) => !!entry[1]).map(([tsKey, queryConfig]) => ({
            tsKey,
            queryConfig,
            relation: tableConfig.relations[tsKey]
          }));
        }
        let extras;
        if (config.extras) {
          extras = typeof config.extras === "function" ? config.extras(aliasedColumns, { sql }) : config.extras;
          for (const [tsKey, value] of Object.entries(extras)) {
            fieldsSelection.push({
              tsKey,
              value: mapColumnsInAliasedSQLToAlias(value, tableAlias)
            });
          }
        }
        for (const { tsKey, value } of fieldsSelection) {
          selection.push({
            dbKey: is(value, SQL.Aliased) ? value.fieldAlias : tableConfig.columns[tsKey].name,
            tsKey,
            field: is(value, Column) ? aliasedTableColumn(value, tableAlias) : value,
            relationTableTsKey: undefined,
            isJson: false,
            selection: []
          });
        }
        let orderByOrig = typeof config.orderBy === "function" ? config.orderBy(aliasedColumns, getOrderByOperators()) : config.orderBy ?? [];
        if (!Array.isArray(orderByOrig)) {
          orderByOrig = [orderByOrig];
        }
        orderBy = orderByOrig.map((orderByValue) => {
          if (is(orderByValue, Column)) {
            return aliasedTableColumn(orderByValue, tableAlias);
          }
          return mapColumnsInSQLToAlias(orderByValue, tableAlias);
        });
        limit = config.limit;
        offset = config.offset;
        for (const {
          tsKey: selectedRelationTsKey,
          queryConfig: selectedRelationConfigValue,
          relation
        } of selectedRelations) {
          const normalizedRelation = normalizeRelation(schema, tableNamesMap, relation);
          const relationTableName = getTableUniqueName(relation.referencedTable);
          const relationTableTsName = tableNamesMap[relationTableName];
          const relationTableAlias = `${tableAlias}_${selectedRelationTsKey}`;
          const joinOn2 = and(...normalizedRelation.fields.map((field2, i) => eq(aliasedTableColumn(normalizedRelation.references[i], relationTableAlias), aliasedTableColumn(field2, tableAlias))));
          const builtRelation = this.buildRelationalQuery({
            fullSchema,
            schema,
            tableNamesMap,
            table: fullSchema[relationTableTsName],
            tableConfig: schema[relationTableTsName],
            queryConfig: is(relation, One) ? selectedRelationConfigValue === true ? { limit: 1 } : { ...selectedRelationConfigValue, limit: 1 } : selectedRelationConfigValue,
            tableAlias: relationTableAlias,
            joinOn: joinOn2,
            nestedQueryRelation: relation
          });
          const field = sql`(${builtRelation.sql})`.as(selectedRelationTsKey);
          selection.push({
            dbKey: selectedRelationTsKey,
            tsKey: selectedRelationTsKey,
            field,
            relationTableTsKey: relationTableTsName,
            isJson: true,
            selection: builtRelation.selection
          });
        }
      }
      if (selection.length === 0) {
        throw new DrizzleError({
          message: `No fields selected for table "${tableConfig.tsName}" ("${tableAlias}"). You need to have at least one item in "columns", "with" or "extras". If you need to select all columns, omit the "columns" key or set it to undefined.`
        });
      }
      let result;
      where = and(joinOn, where);
      if (nestedQueryRelation) {
        let field = sql`json_array(${sql.join(selection.map(({ field: field2 }) => is(field2, SQLiteColumn) ? sql.identifier(this.casing.getColumnCasing(field2)) : is(field2, SQL.Aliased) ? field2.sql : field2), sql`, `)})`;
        if (is(nestedQueryRelation, Many)) {
          field = sql`coalesce(json_group_array(${field}), json_array())`;
        }
        const nestedSelection = [
          {
            dbKey: "data",
            tsKey: "data",
            field: field.as("data"),
            isJson: true,
            relationTableTsKey: tableConfig.tsName,
            selection
          }
        ];
        const needsSubquery = limit !== undefined || offset !== undefined || orderBy.length > 0;
        if (needsSubquery) {
          result = this.buildSelectQuery({
            table: aliasedTable(table, tableAlias),
            fields: {},
            fieldsFlat: [
              {
                path: [],
                field: sql.raw("*")
              }
            ],
            where,
            limit,
            offset,
            orderBy,
            setOperators: []
          });
          where = undefined;
          limit = undefined;
          offset = undefined;
          orderBy = undefined;
        } else {
          result = aliasedTable(table, tableAlias);
        }
        result = this.buildSelectQuery({
          table: is(result, SQLiteTable) ? result : new Subquery(result, {}, tableAlias),
          fields: {},
          fieldsFlat: nestedSelection.map(({ field: field2 }) => ({
            path: [],
            field: is(field2, Column) ? aliasedTableColumn(field2, tableAlias) : field2
          })),
          joins,
          where,
          limit,
          offset,
          orderBy,
          setOperators: []
        });
      } else {
        result = this.buildSelectQuery({
          table: aliasedTable(table, tableAlias),
          fields: {},
          fieldsFlat: selection.map(({ field }) => ({
            path: [],
            field: is(field, Column) ? aliasedTableColumn(field, tableAlias) : field
          })),
          joins,
          where,
          limit,
          offset,
          orderBy,
          setOperators: []
        });
      }
      return {
        tableTsKey: tableConfig.tsName,
        sql: result,
        selection
      };
    }
  };
  SQLiteSyncDialect = class SQLiteSyncDialect extends SQLiteDialect {
    static [entityKind] = "SQLiteSyncDialect";
    migrate(migrations, session, config) {
      const migrationsTable = config === undefined ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
      const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
      session.run(migrationTableCreate);
      const dbMigrations = session.values(sql`SELECT id, hash, created_at FROM ${sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`);
      const lastDbMigration = dbMigrations[0] ?? undefined;
      session.run(sql`BEGIN`);
      try {
        for (const migration of migrations) {
          if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
            for (const stmt of migration.sql) {
              session.run(sql.raw(stmt));
            }
            session.run(sql`INSERT INTO ${sql.identifier(migrationsTable)} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`);
          }
        }
        session.run(sql`COMMIT`);
      } catch (e) {
        session.run(sql`ROLLBACK`);
        throw e;
      }
    }
  };
  SQLiteAsyncDialect = class SQLiteAsyncDialect extends SQLiteDialect {
    static [entityKind] = "SQLiteAsyncDialect";
    async migrate(migrations, session, config) {
      const migrationsTable = config === undefined ? "__drizzle_migrations" : typeof config === "string" ? "__drizzle_migrations" : config.migrationsTable ?? "__drizzle_migrations";
      const migrationTableCreate = sql`
			CREATE TABLE IF NOT EXISTS ${sql.identifier(migrationsTable)} (
				id SERIAL PRIMARY KEY,
				hash text NOT NULL,
				created_at numeric
			)
		`;
      await session.run(migrationTableCreate);
      const dbMigrations = await session.values(sql`SELECT id, hash, created_at FROM ${sql.identifier(migrationsTable)} ORDER BY created_at DESC LIMIT 1`);
      const lastDbMigration = dbMigrations[0] ?? undefined;
      await session.transaction(async (tx) => {
        for (const migration of migrations) {
          if (!lastDbMigration || Number(lastDbMigration[2]) < migration.folderMillis) {
            for (const stmt of migration.sql) {
              await tx.run(sql.raw(stmt));
            }
            await tx.run(sql`INSERT INTO ${sql.identifier(migrationsTable)} ("hash", "created_at") VALUES(${migration.hash}, ${migration.folderMillis})`);
          }
        }
      });
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/query-builders/query-builder.js
var TypedQueryBuilder;
var init_query_builder = __esm(() => {
  init_entity();
  TypedQueryBuilder = class TypedQueryBuilder {
    static [entityKind] = "TypedQueryBuilder";
    getSelectedFields() {
      return this._.selectedFields;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/select.js
function createSetOperator(type, isAll) {
  return (leftSelect, rightSelect, ...restSelects) => {
    const setOperators = [rightSelect, ...restSelects].map((select) => ({
      type,
      isAll,
      rightSelect: select
    }));
    for (const setOperator of setOperators) {
      if (!haveSameKeys(leftSelect.getSelectedFields(), setOperator.rightSelect.getSelectedFields())) {
        throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
      }
    }
    return leftSelect.addSetOperators(setOperators);
  };
}
var SQLiteSelectBuilder, SQLiteSelectQueryBuilderBase, SQLiteSelectBase, getSQLiteSetOperators = () => ({
  union,
  unionAll,
  intersect,
  except
}), union, unionAll, intersect, except;
var init_select2 = __esm(() => {
  init_entity();
  init_query_builder();
  init_query_promise();
  init_selection_proxy();
  init_sql();
  init_subquery();
  init_table();
  init_utils();
  init_view_common();
  init_utils2();
  init_view_base();
  SQLiteSelectBuilder = class SQLiteSelectBuilder {
    static [entityKind] = "SQLiteSelectBuilder";
    fields;
    session;
    dialect;
    withList;
    distinct;
    constructor(config) {
      this.fields = config.fields;
      this.session = config.session;
      this.dialect = config.dialect;
      this.withList = config.withList;
      this.distinct = config.distinct;
    }
    from(source) {
      const isPartialSelect = !!this.fields;
      let fields;
      if (this.fields) {
        fields = this.fields;
      } else if (is(source, Subquery)) {
        fields = Object.fromEntries(Object.keys(source._.selectedFields).map((key) => [key, source[key]]));
      } else if (is(source, SQLiteViewBase)) {
        fields = source[ViewBaseConfig].selectedFields;
      } else if (is(source, SQL)) {
        fields = {};
      } else {
        fields = getTableColumns(source);
      }
      return new SQLiteSelectBase({
        table: source,
        fields,
        isPartialSelect,
        session: this.session,
        dialect: this.dialect,
        withList: this.withList,
        distinct: this.distinct
      });
    }
  };
  SQLiteSelectQueryBuilderBase = class SQLiteSelectQueryBuilderBase extends TypedQueryBuilder {
    static [entityKind] = "SQLiteSelectQueryBuilder";
    _;
    config;
    joinsNotNullableMap;
    tableName;
    isPartialSelect;
    session;
    dialect;
    cacheConfig = undefined;
    usedTables = /* @__PURE__ */ new Set;
    constructor({ table, fields, isPartialSelect, session, dialect, withList, distinct }) {
      super();
      this.config = {
        withList,
        table,
        fields: { ...fields },
        distinct,
        setOperators: []
      };
      this.isPartialSelect = isPartialSelect;
      this.session = session;
      this.dialect = dialect;
      this._ = {
        selectedFields: fields,
        config: this.config
      };
      this.tableName = getTableLikeName(table);
      this.joinsNotNullableMap = typeof this.tableName === "string" ? { [this.tableName]: true } : {};
      for (const item of extractUsedTable(table))
        this.usedTables.add(item);
    }
    getUsedTables() {
      return [...this.usedTables];
    }
    createJoin(joinType) {
      return (table, on) => {
        const baseTableName = this.tableName;
        const tableName = getTableLikeName(table);
        for (const item of extractUsedTable(table))
          this.usedTables.add(item);
        if (typeof tableName === "string" && this.config.joins?.some((join) => join.alias === tableName)) {
          throw new Error(`Alias "${tableName}" is already used in this query`);
        }
        if (!this.isPartialSelect) {
          if (Object.keys(this.joinsNotNullableMap).length === 1 && typeof baseTableName === "string") {
            this.config.fields = {
              [baseTableName]: this.config.fields
            };
          }
          if (typeof tableName === "string" && !is(table, SQL)) {
            const selection = is(table, Subquery) ? table._.selectedFields : is(table, View) ? table[ViewBaseConfig].selectedFields : table[Table.Symbol.Columns];
            this.config.fields[tableName] = selection;
          }
        }
        if (typeof on === "function") {
          on = on(new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })));
        }
        if (!this.config.joins) {
          this.config.joins = [];
        }
        this.config.joins.push({ on, table, joinType, alias: tableName });
        if (typeof tableName === "string") {
          switch (joinType) {
            case "left": {
              this.joinsNotNullableMap[tableName] = false;
              break;
            }
            case "right": {
              this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
              this.joinsNotNullableMap[tableName] = true;
              break;
            }
            case "cross":
            case "inner": {
              this.joinsNotNullableMap[tableName] = true;
              break;
            }
            case "full": {
              this.joinsNotNullableMap = Object.fromEntries(Object.entries(this.joinsNotNullableMap).map(([key]) => [key, false]));
              this.joinsNotNullableMap[tableName] = false;
              break;
            }
          }
        }
        return this;
      };
    }
    leftJoin = this.createJoin("left");
    rightJoin = this.createJoin("right");
    innerJoin = this.createJoin("inner");
    fullJoin = this.createJoin("full");
    crossJoin = this.createJoin("cross");
    createSetOperator(type, isAll) {
      return (rightSelection) => {
        const rightSelect = typeof rightSelection === "function" ? rightSelection(getSQLiteSetOperators()) : rightSelection;
        if (!haveSameKeys(this.getSelectedFields(), rightSelect.getSelectedFields())) {
          throw new Error("Set operator error (union / intersect / except): selected fields are not the same or are in a different order");
        }
        this.config.setOperators.push({ type, isAll, rightSelect });
        return this;
      };
    }
    union = this.createSetOperator("union", false);
    unionAll = this.createSetOperator("union", true);
    intersect = this.createSetOperator("intersect", false);
    except = this.createSetOperator("except", false);
    addSetOperators(setOperators) {
      this.config.setOperators.push(...setOperators);
      return this;
    }
    where(where) {
      if (typeof where === "function") {
        where = where(new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })));
      }
      this.config.where = where;
      return this;
    }
    having(having) {
      if (typeof having === "function") {
        having = having(new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })));
      }
      this.config.having = having;
      return this;
    }
    groupBy(...columns) {
      if (typeof columns[0] === "function") {
        const groupBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })));
        this.config.groupBy = Array.isArray(groupBy) ? groupBy : [groupBy];
      } else {
        this.config.groupBy = columns;
      }
      return this;
    }
    orderBy(...columns) {
      if (typeof columns[0] === "function") {
        const orderBy = columns[0](new Proxy(this.config.fields, new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })));
        const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).orderBy = orderByArray;
        } else {
          this.config.orderBy = orderByArray;
        }
      } else {
        const orderByArray = columns;
        if (this.config.setOperators.length > 0) {
          this.config.setOperators.at(-1).orderBy = orderByArray;
        } else {
          this.config.orderBy = orderByArray;
        }
      }
      return this;
    }
    limit(limit) {
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).limit = limit;
      } else {
        this.config.limit = limit;
      }
      return this;
    }
    offset(offset) {
      if (this.config.setOperators.length > 0) {
        this.config.setOperators.at(-1).offset = offset;
      } else {
        this.config.offset = offset;
      }
      return this;
    }
    getSQL() {
      return this.dialect.buildSelectQuery(this.config);
    }
    toSQL() {
      const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
      return rest;
    }
    as(alias) {
      const usedTables = [];
      usedTables.push(...extractUsedTable(this.config.table));
      if (this.config.joins) {
        for (const it of this.config.joins)
          usedTables.push(...extractUsedTable(it.table));
      }
      return new Proxy(new Subquery(this.getSQL(), this.config.fields, alias, false, [...new Set(usedTables)]), new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
    }
    getSelectedFields() {
      return new Proxy(this.config.fields, new SelectionProxyHandler({ alias: this.tableName, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
    }
    $dynamic() {
      return this;
    }
  };
  SQLiteSelectBase = class SQLiteSelectBase extends SQLiteSelectQueryBuilderBase {
    static [entityKind] = "SQLiteSelect";
    _prepare(isOneTimeQuery = true) {
      if (!this.session) {
        throw new Error("Cannot execute a query on a query builder. Please use a database instance instead.");
      }
      const fieldsList = orderSelectedFields(this.config.fields);
      const query = this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), fieldsList, "all", true, undefined, {
        type: "select",
        tables: [...this.usedTables]
      }, this.cacheConfig);
      query.joinsNotNullableMap = this.joinsNotNullableMap;
      return query;
    }
    $withCache(config) {
      this.cacheConfig = config === undefined ? { config: {}, enable: true, autoInvalidate: true } : config === false ? { enable: false } : { enable: true, autoInvalidate: true, ...config };
      return this;
    }
    prepare() {
      return this._prepare(false);
    }
    run = (placeholderValues) => {
      return this._prepare().run(placeholderValues);
    };
    all = (placeholderValues) => {
      return this._prepare().all(placeholderValues);
    };
    get = (placeholderValues) => {
      return this._prepare().get(placeholderValues);
    };
    values = (placeholderValues) => {
      return this._prepare().values(placeholderValues);
    };
    async execute() {
      return this.all();
    }
  };
  applyMixins(SQLiteSelectBase, [QueryPromise]);
  union = createSetOperator("union", false);
  unionAll = createSetOperator("union", true);
  intersect = createSetOperator("intersect", false);
  except = createSetOperator("except", false);
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/query-builder.js
var QueryBuilder;
var init_query_builder2 = __esm(() => {
  init_entity();
  init_selection_proxy();
  init_dialect();
  init_subquery();
  init_select2();
  QueryBuilder = class QueryBuilder {
    static [entityKind] = "SQLiteQueryBuilder";
    dialect;
    dialectConfig;
    constructor(dialect) {
      this.dialect = is(dialect, SQLiteDialect) ? dialect : undefined;
      this.dialectConfig = is(dialect, SQLiteDialect) ? undefined : dialect;
    }
    $with = (alias, selection) => {
      const queryBuilder = this;
      const as = (qb) => {
        if (typeof qb === "function") {
          qb = qb(queryBuilder);
        }
        return new Proxy(new WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
      };
      return { as };
    };
    with(...queries) {
      const self = this;
      function select(fields) {
        return new SQLiteSelectBuilder({
          fields: fields ?? undefined,
          session: undefined,
          dialect: self.getDialect(),
          withList: queries
        });
      }
      function selectDistinct(fields) {
        return new SQLiteSelectBuilder({
          fields: fields ?? undefined,
          session: undefined,
          dialect: self.getDialect(),
          withList: queries,
          distinct: true
        });
      }
      return { select, selectDistinct };
    }
    select(fields) {
      return new SQLiteSelectBuilder({ fields: fields ?? undefined, session: undefined, dialect: this.getDialect() });
    }
    selectDistinct(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? undefined,
        session: undefined,
        dialect: this.getDialect(),
        distinct: true
      });
    }
    getDialect() {
      if (!this.dialect) {
        this.dialect = new SQLiteSyncDialect(this.dialectConfig);
      }
      return this.dialect;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/insert.js
var SQLiteInsertBuilder, SQLiteInsertBase;
var init_insert = __esm(() => {
  init_entity();
  init_query_promise();
  init_sql();
  init_table3();
  init_table();
  init_utils();
  init_utils2();
  init_query_builder2();
  SQLiteInsertBuilder = class SQLiteInsertBuilder {
    constructor(table, session, dialect, withList) {
      this.table = table;
      this.session = session;
      this.dialect = dialect;
      this.withList = withList;
    }
    static [entityKind] = "SQLiteInsertBuilder";
    values(values) {
      values = Array.isArray(values) ? values : [values];
      if (values.length === 0) {
        throw new Error("values() must be called with at least one value");
      }
      const mappedValues = values.map((entry) => {
        const result = {};
        const cols = this.table[Table.Symbol.Columns];
        for (const colKey of Object.keys(entry)) {
          const colValue = entry[colKey];
          result[colKey] = is(colValue, SQL) ? colValue : new Param(colValue, cols[colKey]);
        }
        return result;
      });
      return new SQLiteInsertBase(this.table, mappedValues, this.session, this.dialect, this.withList);
    }
    select(selectQuery) {
      const select = typeof selectQuery === "function" ? selectQuery(new QueryBuilder) : selectQuery;
      if (!is(select, SQL) && !haveSameKeys(this.table[Columns], select._.selectedFields)) {
        throw new Error("Insert select error: selected fields are not the same or are in a different order compared to the table definition");
      }
      return new SQLiteInsertBase(this.table, select, this.session, this.dialect, this.withList, true);
    }
  };
  SQLiteInsertBase = class SQLiteInsertBase extends QueryPromise {
    constructor(table, values, session, dialect, withList, select) {
      super();
      this.session = session;
      this.dialect = dialect;
      this.config = { table, values, withList, select };
    }
    static [entityKind] = "SQLiteInsert";
    config;
    returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
      this.config.returning = orderSelectedFields(fields);
      return this;
    }
    onConflictDoNothing(config = {}) {
      if (!this.config.onConflict)
        this.config.onConflict = [];
      if (config.target === undefined) {
        this.config.onConflict.push(sql` on conflict do nothing`);
      } else {
        const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
        const whereSql = config.where ? sql` where ${config.where}` : sql``;
        this.config.onConflict.push(sql` on conflict ${targetSql} do nothing${whereSql}`);
      }
      return this;
    }
    onConflictDoUpdate(config) {
      if (config.where && (config.targetWhere || config.setWhere)) {
        throw new Error('You cannot use both "where" and "targetWhere"/"setWhere" at the same time - "where" is deprecated, use "targetWhere" or "setWhere" instead.');
      }
      if (!this.config.onConflict)
        this.config.onConflict = [];
      const whereSql = config.where ? sql` where ${config.where}` : undefined;
      const targetWhereSql = config.targetWhere ? sql` where ${config.targetWhere}` : undefined;
      const setWhereSql = config.setWhere ? sql` where ${config.setWhere}` : undefined;
      const targetSql = Array.isArray(config.target) ? sql`${config.target}` : sql`${[config.target]}`;
      const setSql = this.dialect.buildUpdateSet(this.config.table, mapUpdateSet(this.config.table, config.set));
      this.config.onConflict.push(sql` on conflict ${targetSql}${targetWhereSql} do update set ${setSql}${whereSql}${setWhereSql}`);
      return this;
    }
    getSQL() {
      return this.dialect.buildInsertQuery(this.config);
    }
    toSQL() {
      const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
      return rest;
    }
    _prepare(isOneTimeQuery = true) {
      return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, undefined, {
        type: "insert",
        tables: extractUsedTable(this.config.table)
      });
    }
    prepare() {
      return this._prepare(false);
    }
    run = (placeholderValues) => {
      return this._prepare().run(placeholderValues);
    };
    all = (placeholderValues) => {
      return this._prepare().all(placeholderValues);
    };
    get = (placeholderValues) => {
      return this._prepare().get(placeholderValues);
    };
    values = (placeholderValues) => {
      return this._prepare().values(placeholderValues);
    };
    async execute() {
      return this.config.returning ? this.all() : this.run();
    }
    $dynamic() {
      return this;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/update.js
var SQLiteUpdateBuilder, SQLiteUpdateBase;
var init_update = __esm(() => {
  init_entity();
  init_query_promise();
  init_selection_proxy();
  init_table3();
  init_subquery();
  init_table();
  init_utils();
  init_view_common();
  init_utils2();
  init_view_base();
  SQLiteUpdateBuilder = class SQLiteUpdateBuilder {
    constructor(table, session, dialect, withList) {
      this.table = table;
      this.session = session;
      this.dialect = dialect;
      this.withList = withList;
    }
    static [entityKind] = "SQLiteUpdateBuilder";
    set(values) {
      return new SQLiteUpdateBase(this.table, mapUpdateSet(this.table, values), this.session, this.dialect, this.withList);
    }
  };
  SQLiteUpdateBase = class SQLiteUpdateBase extends QueryPromise {
    constructor(table, set, session, dialect, withList) {
      super();
      this.session = session;
      this.dialect = dialect;
      this.config = { set, table, withList, joins: [] };
    }
    static [entityKind] = "SQLiteUpdate";
    config;
    from(source) {
      this.config.from = source;
      return this;
    }
    createJoin(joinType) {
      return (table, on) => {
        const tableName = getTableLikeName(table);
        if (typeof tableName === "string" && this.config.joins.some((join) => join.alias === tableName)) {
          throw new Error(`Alias "${tableName}" is already used in this query`);
        }
        if (typeof on === "function") {
          const from = this.config.from ? is(table, SQLiteTable) ? table[Table.Symbol.Columns] : is(table, Subquery) ? table._.selectedFields : is(table, SQLiteViewBase) ? table[ViewBaseConfig].selectedFields : undefined : undefined;
          on = on(new Proxy(this.config.table[Table.Symbol.Columns], new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })), from && new Proxy(from, new SelectionProxyHandler({ sqlAliasedBehavior: "sql", sqlBehavior: "sql" })));
        }
        this.config.joins.push({ on, table, joinType, alias: tableName });
        return this;
      };
    }
    leftJoin = this.createJoin("left");
    rightJoin = this.createJoin("right");
    innerJoin = this.createJoin("inner");
    fullJoin = this.createJoin("full");
    where(where) {
      this.config.where = where;
      return this;
    }
    orderBy(...columns) {
      if (typeof columns[0] === "function") {
        const orderBy = columns[0](new Proxy(this.config.table[Table.Symbol.Columns], new SelectionProxyHandler({ sqlAliasedBehavior: "alias", sqlBehavior: "sql" })));
        const orderByArray = Array.isArray(orderBy) ? orderBy : [orderBy];
        this.config.orderBy = orderByArray;
      } else {
        const orderByArray = columns;
        this.config.orderBy = orderByArray;
      }
      return this;
    }
    limit(limit) {
      this.config.limit = limit;
      return this;
    }
    returning(fields = this.config.table[SQLiteTable.Symbol.Columns]) {
      this.config.returning = orderSelectedFields(fields);
      return this;
    }
    getSQL() {
      return this.dialect.buildUpdateQuery(this.config);
    }
    toSQL() {
      const { typings: _typings, ...rest } = this.dialect.sqlToQuery(this.getSQL());
      return rest;
    }
    _prepare(isOneTimeQuery = true) {
      return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](this.dialect.sqlToQuery(this.getSQL()), this.config.returning, this.config.returning ? "all" : "run", true, undefined, {
        type: "insert",
        tables: extractUsedTable(this.config.table)
      });
    }
    prepare() {
      return this._prepare(false);
    }
    run = (placeholderValues) => {
      return this._prepare().run(placeholderValues);
    };
    all = (placeholderValues) => {
      return this._prepare().all(placeholderValues);
    };
    get = (placeholderValues) => {
      return this._prepare().get(placeholderValues);
    };
    values = (placeholderValues) => {
      return this._prepare().values(placeholderValues);
    };
    async execute() {
      return this.config.returning ? this.all() : this.run();
    }
    $dynamic() {
      return this;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/index.js
var init_query_builders = __esm(() => {
  init_delete();
  init_insert();
  init_query_builder2();
  init_select2();
  init_update();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/count.js
var SQLiteCountBuilder;
var init_count = __esm(() => {
  init_entity();
  init_sql();
  SQLiteCountBuilder = class SQLiteCountBuilder extends SQL {
    constructor(params) {
      super(SQLiteCountBuilder.buildEmbeddedCount(params.source, params.filters).queryChunks);
      this.params = params;
      this.session = params.session;
      this.sql = SQLiteCountBuilder.buildCount(params.source, params.filters);
    }
    sql;
    static [entityKind] = "SQLiteCountBuilderAsync";
    [Symbol.toStringTag] = "SQLiteCountBuilderAsync";
    session;
    static buildEmbeddedCount(source, filters) {
      return sql`(select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters})`;
    }
    static buildCount(source, filters) {
      return sql`select count(*) from ${source}${sql.raw(" where ").if(filters)}${filters}`;
    }
    then(onfulfilled, onrejected) {
      return Promise.resolve(this.session.count(this.sql)).then(onfulfilled, onrejected);
    }
    catch(onRejected) {
      return this.then(undefined, onRejected);
    }
    finally(onFinally) {
      return this.then((value) => {
        onFinally?.();
        return value;
      }, (reason) => {
        onFinally?.();
        throw reason;
      });
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/query.js
var RelationalQueryBuilder, SQLiteRelationalQuery, SQLiteSyncRelationalQuery;
var init_query = __esm(() => {
  init_entity();
  init_query_promise();
  init_relations();
  RelationalQueryBuilder = class RelationalQueryBuilder {
    constructor(mode, fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session) {
      this.mode = mode;
      this.fullSchema = fullSchema;
      this.schema = schema;
      this.tableNamesMap = tableNamesMap;
      this.table = table;
      this.tableConfig = tableConfig;
      this.dialect = dialect;
      this.session = session;
    }
    static [entityKind] = "SQLiteAsyncRelationalQueryBuilder";
    findMany(config) {
      return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? config : {}, "many");
    }
    findFirst(config) {
      return this.mode === "sync" ? new SQLiteSyncRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? { ...config, limit: 1 } : { limit: 1 }, "first") : new SQLiteRelationalQuery(this.fullSchema, this.schema, this.tableNamesMap, this.table, this.tableConfig, this.dialect, this.session, config ? { ...config, limit: 1 } : { limit: 1 }, "first");
    }
  };
  SQLiteRelationalQuery = class SQLiteRelationalQuery extends QueryPromise {
    constructor(fullSchema, schema, tableNamesMap, table, tableConfig, dialect, session, config, mode) {
      super();
      this.fullSchema = fullSchema;
      this.schema = schema;
      this.tableNamesMap = tableNamesMap;
      this.table = table;
      this.tableConfig = tableConfig;
      this.dialect = dialect;
      this.session = session;
      this.config = config;
      this.mode = mode;
    }
    static [entityKind] = "SQLiteAsyncRelationalQuery";
    mode;
    getSQL() {
      return this.dialect.buildRelationalQuery({
        fullSchema: this.fullSchema,
        schema: this.schema,
        tableNamesMap: this.tableNamesMap,
        table: this.table,
        tableConfig: this.tableConfig,
        queryConfig: this.config,
        tableAlias: this.tableConfig.tsName
      }).sql;
    }
    _prepare(isOneTimeQuery = false) {
      const { query, builtQuery } = this._toSQL();
      return this.session[isOneTimeQuery ? "prepareOneTimeQuery" : "prepareQuery"](builtQuery, undefined, this.mode === "first" ? "get" : "all", true, (rawRows, mapColumnValue) => {
        const rows = rawRows.map((row) => mapRelationalRow(this.schema, this.tableConfig, row, query.selection, mapColumnValue));
        if (this.mode === "first") {
          return rows[0];
        }
        return rows;
      });
    }
    prepare() {
      return this._prepare(false);
    }
    _toSQL() {
      const query = this.dialect.buildRelationalQuery({
        fullSchema: this.fullSchema,
        schema: this.schema,
        tableNamesMap: this.tableNamesMap,
        table: this.table,
        tableConfig: this.tableConfig,
        queryConfig: this.config,
        tableAlias: this.tableConfig.tsName
      });
      const builtQuery = this.dialect.sqlToQuery(query.sql);
      return { query, builtQuery };
    }
    toSQL() {
      return this._toSQL().builtQuery;
    }
    executeRaw() {
      if (this.mode === "first") {
        return this._prepare(false).get();
      }
      return this._prepare(false).all();
    }
    async execute() {
      return this.executeRaw();
    }
  };
  SQLiteSyncRelationalQuery = class SQLiteSyncRelationalQuery extends SQLiteRelationalQuery {
    static [entityKind] = "SQLiteSyncRelationalQuery";
    sync() {
      return this.executeRaw();
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/query-builders/raw.js
var SQLiteRaw;
var init_raw = __esm(() => {
  init_entity();
  init_query_promise();
  SQLiteRaw = class SQLiteRaw extends QueryPromise {
    constructor(execute, getSQL, action, dialect, mapBatchResult) {
      super();
      this.execute = execute;
      this.getSQL = getSQL;
      this.dialect = dialect;
      this.mapBatchResult = mapBatchResult;
      this.config = { action };
    }
    static [entityKind] = "SQLiteRaw";
    config;
    getQuery() {
      return { ...this.dialect.sqlToQuery(this.getSQL()), method: this.config.action };
    }
    mapResult(result, isFromBatch) {
      return isFromBatch ? this.mapBatchResult(result) : result;
    }
    _prepare() {
      return this;
    }
    isResponseInArrayMode() {
      return false;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/db.js
var BaseSQLiteDatabase;
var init_db = __esm(() => {
  init_entity();
  init_selection_proxy();
  init_sql();
  init_query_builders();
  init_subquery();
  init_count();
  init_query();
  init_raw();
  BaseSQLiteDatabase = class BaseSQLiteDatabase {
    constructor(resultKind, dialect, session, schema) {
      this.resultKind = resultKind;
      this.dialect = dialect;
      this.session = session;
      this._ = schema ? {
        schema: schema.schema,
        fullSchema: schema.fullSchema,
        tableNamesMap: schema.tableNamesMap
      } : {
        schema: undefined,
        fullSchema: {},
        tableNamesMap: {}
      };
      this.query = {};
      const query = this.query;
      if (this._.schema) {
        for (const [tableName, columns] of Object.entries(this._.schema)) {
          query[tableName] = new RelationalQueryBuilder(resultKind, schema.fullSchema, this._.schema, this._.tableNamesMap, schema.fullSchema[tableName], columns, dialect, session);
        }
      }
      this.$cache = { invalidate: async (_params) => {} };
    }
    static [entityKind] = "BaseSQLiteDatabase";
    query;
    $with = (alias, selection) => {
      const self = this;
      const as = (qb) => {
        if (typeof qb === "function") {
          qb = qb(new QueryBuilder(self.dialect));
        }
        return new Proxy(new WithSubquery(qb.getSQL(), selection ?? ("getSelectedFields" in qb ? qb.getSelectedFields() ?? {} : {}), alias, true), new SelectionProxyHandler({ alias, sqlAliasedBehavior: "alias", sqlBehavior: "error" }));
      };
      return { as };
    };
    $count(source, filters) {
      return new SQLiteCountBuilder({ source, filters, session: this.session });
    }
    with(...queries) {
      const self = this;
      function select(fields) {
        return new SQLiteSelectBuilder({
          fields: fields ?? undefined,
          session: self.session,
          dialect: self.dialect,
          withList: queries
        });
      }
      function selectDistinct(fields) {
        return new SQLiteSelectBuilder({
          fields: fields ?? undefined,
          session: self.session,
          dialect: self.dialect,
          withList: queries,
          distinct: true
        });
      }
      function update(table) {
        return new SQLiteUpdateBuilder(table, self.session, self.dialect, queries);
      }
      function insert(into) {
        return new SQLiteInsertBuilder(into, self.session, self.dialect, queries);
      }
      function delete_(from) {
        return new SQLiteDeleteBase(from, self.session, self.dialect, queries);
      }
      return { select, selectDistinct, update, insert, delete: delete_ };
    }
    select(fields) {
      return new SQLiteSelectBuilder({ fields: fields ?? undefined, session: this.session, dialect: this.dialect });
    }
    selectDistinct(fields) {
      return new SQLiteSelectBuilder({
        fields: fields ?? undefined,
        session: this.session,
        dialect: this.dialect,
        distinct: true
      });
    }
    update(table) {
      return new SQLiteUpdateBuilder(table, this.session, this.dialect);
    }
    $cache;
    insert(into) {
      return new SQLiteInsertBuilder(into, this.session, this.dialect);
    }
    delete(from) {
      return new SQLiteDeleteBase(from, this.session, this.dialect);
    }
    run(query) {
      const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
      if (this.resultKind === "async") {
        return new SQLiteRaw(async () => this.session.run(sequel), () => sequel, "run", this.dialect, this.session.extractRawRunValueFromBatchResult.bind(this.session));
      }
      return this.session.run(sequel);
    }
    all(query) {
      const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
      if (this.resultKind === "async") {
        return new SQLiteRaw(async () => this.session.all(sequel), () => sequel, "all", this.dialect, this.session.extractRawAllValueFromBatchResult.bind(this.session));
      }
      return this.session.all(sequel);
    }
    get(query) {
      const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
      if (this.resultKind === "async") {
        return new SQLiteRaw(async () => this.session.get(sequel), () => sequel, "get", this.dialect, this.session.extractRawGetValueFromBatchResult.bind(this.session));
      }
      return this.session.get(sequel);
    }
    values(query) {
      const sequel = typeof query === "string" ? sql.raw(query) : query.getSQL();
      if (this.resultKind === "async") {
        return new SQLiteRaw(async () => this.session.values(sequel), () => sequel, "values", this.dialect, this.session.extractRawValuesValueFromBatchResult.bind(this.session));
      }
      return this.session.values(sequel);
    }
    transaction(transaction, config) {
      return this.session.transaction(transaction, config);
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/cache/core/cache.js
async function hashQuery(sql, params) {
  const dataToHash = `${sql}-${JSON.stringify(params)}`;
  const encoder = new TextEncoder;
  const data = encoder.encode(dataToHash);
  const hashBuffer = await crypto.subtle.digest("SHA-256", data);
  const hashArray = [...new Uint8Array(hashBuffer)];
  const hashHex = hashArray.map((b) => b.toString(16).padStart(2, "0")).join("");
  return hashHex;
}
var Cache, NoopCache;
var init_cache = __esm(() => {
  init_entity();
  Cache = class Cache {
    static [entityKind] = "Cache";
  };
  NoopCache = class NoopCache extends Cache {
    strategy() {
      return "all";
    }
    static [entityKind] = "NoopCache";
    async get(_key) {
      return;
    }
    async put(_hashedQuery, _response, _tables, _config) {}
    async onMutate(_params) {}
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/cache/core/index.js
var init_core = __esm(() => {
  init_cache();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/alias.js
var init_alias2 = () => {};

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/session.js
var ExecuteResultSync, SQLitePreparedQuery, SQLiteSession, SQLiteTransaction;
var init_session = __esm(() => {
  init_cache();
  init_entity();
  init_errors();
  init_query_promise();
  init_db();
  ExecuteResultSync = class ExecuteResultSync extends QueryPromise {
    constructor(resultCb) {
      super();
      this.resultCb = resultCb;
    }
    static [entityKind] = "ExecuteResultSync";
    async execute() {
      return this.resultCb();
    }
    sync() {
      return this.resultCb();
    }
  };
  SQLitePreparedQuery = class SQLitePreparedQuery {
    constructor(mode, executeMethod, query, cache, queryMetadata, cacheConfig) {
      this.mode = mode;
      this.executeMethod = executeMethod;
      this.query = query;
      this.cache = cache;
      this.queryMetadata = queryMetadata;
      this.cacheConfig = cacheConfig;
      if (cache && cache.strategy() === "all" && cacheConfig === undefined) {
        this.cacheConfig = { enable: true, autoInvalidate: true };
      }
      if (!this.cacheConfig?.enable) {
        this.cacheConfig = undefined;
      }
    }
    static [entityKind] = "PreparedQuery";
    joinsNotNullableMap;
    async queryWithCache(queryString, params, query) {
      if (this.cache === undefined || is(this.cache, NoopCache) || this.queryMetadata === undefined) {
        try {
          return await query();
        } catch (e) {
          throw new DrizzleQueryError(queryString, params, e);
        }
      }
      if (this.cacheConfig && !this.cacheConfig.enable) {
        try {
          return await query();
        } catch (e) {
          throw new DrizzleQueryError(queryString, params, e);
        }
      }
      if ((this.queryMetadata.type === "insert" || this.queryMetadata.type === "update" || this.queryMetadata.type === "delete") && this.queryMetadata.tables.length > 0) {
        try {
          const [res] = await Promise.all([
            query(),
            this.cache.onMutate({ tables: this.queryMetadata.tables })
          ]);
          return res;
        } catch (e) {
          throw new DrizzleQueryError(queryString, params, e);
        }
      }
      if (!this.cacheConfig) {
        try {
          return await query();
        } catch (e) {
          throw new DrizzleQueryError(queryString, params, e);
        }
      }
      if (this.queryMetadata.type === "select") {
        const fromCache = await this.cache.get(this.cacheConfig.tag ?? await hashQuery(queryString, params), this.queryMetadata.tables, this.cacheConfig.tag !== undefined, this.cacheConfig.autoInvalidate);
        if (fromCache === undefined) {
          let result;
          try {
            result = await query();
          } catch (e) {
            throw new DrizzleQueryError(queryString, params, e);
          }
          await this.cache.put(this.cacheConfig.tag ?? await hashQuery(queryString, params), result, this.cacheConfig.autoInvalidate ? this.queryMetadata.tables : [], this.cacheConfig.tag !== undefined, this.cacheConfig.config);
          return result;
        }
        return fromCache;
      }
      try {
        return await query();
      } catch (e) {
        throw new DrizzleQueryError(queryString, params, e);
      }
    }
    getQuery() {
      return this.query;
    }
    mapRunResult(result, _isFromBatch) {
      return result;
    }
    mapAllResult(_result, _isFromBatch) {
      throw new Error("Not implemented");
    }
    mapGetResult(_result, _isFromBatch) {
      throw new Error("Not implemented");
    }
    execute(placeholderValues) {
      if (this.mode === "async") {
        return this[this.executeMethod](placeholderValues);
      }
      return new ExecuteResultSync(() => this[this.executeMethod](placeholderValues));
    }
    mapResult(response, isFromBatch) {
      switch (this.executeMethod) {
        case "run": {
          return this.mapRunResult(response, isFromBatch);
        }
        case "all": {
          return this.mapAllResult(response, isFromBatch);
        }
        case "get": {
          return this.mapGetResult(response, isFromBatch);
        }
      }
    }
  };
  SQLiteSession = class SQLiteSession {
    constructor(dialect) {
      this.dialect = dialect;
    }
    static [entityKind] = "SQLiteSession";
    prepareOneTimeQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
      return this.prepareQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig);
    }
    run(query) {
      const staticQuery = this.dialect.sqlToQuery(query);
      try {
        return this.prepareOneTimeQuery(staticQuery, undefined, "run", false).run();
      } catch (err) {
        throw new DrizzleError({ cause: err, message: `Failed to run the query '${staticQuery.sql}'` });
      }
    }
    extractRawRunValueFromBatchResult(result) {
      return result;
    }
    all(query) {
      return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), undefined, "run", false).all();
    }
    extractRawAllValueFromBatchResult(_result) {
      throw new Error("Not implemented");
    }
    get(query) {
      return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), undefined, "run", false).get();
    }
    extractRawGetValueFromBatchResult(_result) {
      throw new Error("Not implemented");
    }
    values(query) {
      return this.prepareOneTimeQuery(this.dialect.sqlToQuery(query), undefined, "run", false).values();
    }
    async count(sql) {
      const result = await this.values(sql);
      return result[0][0];
    }
    extractRawValuesValueFromBatchResult(_result) {
      throw new Error("Not implemented");
    }
  };
  SQLiteTransaction = class SQLiteTransaction extends BaseSQLiteDatabase {
    constructor(resultType, dialect, session, schema, nestedIndex = 0) {
      super(resultType, dialect, session, schema);
      this.schema = schema;
      this.nestedIndex = nestedIndex;
    }
    static [entityKind] = "SQLiteTransaction";
    rollback() {
      throw new TransactionRollbackError;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/view.js
var init_view = () => {};

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/sqlite-core/index.js
var init_sqlite_core = __esm(() => {
  init_alias2();
  init_checks();
  init_columns();
  init_db();
  init_dialect();
  init_foreign_keys();
  init_indexes();
  init_primary_keys2();
  init_query_builders();
  init_session();
  init_table3();
  init_unique_constraint();
  init_utils2();
  init_view();
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/libsql/session.js
function normalizeRow(obj) {
  return Object.keys(obj).reduce((acc, key) => {
    if (Object.prototype.propertyIsEnumerable.call(obj, key)) {
      acc[key] = obj[key];
    }
    return acc;
  }, {});
}
function normalizeFieldValue(value) {
  if (typeof ArrayBuffer !== "undefined" && value instanceof ArrayBuffer) {
    if (typeof Buffer !== "undefined") {
      if (!(value instanceof Buffer)) {
        return Buffer.from(value);
      }
      return value;
    }
    if (typeof TextDecoder !== "undefined") {
      return new TextDecoder().decode(value);
    }
    throw new Error("TextDecoder is not available. Please provide either Buffer or TextDecoder polyfill.");
  }
  return value;
}
var LibSQLSession, LibSQLTransaction, LibSQLPreparedQuery;
var init_session2 = __esm(() => {
  init_core();
  init_entity();
  init_logger();
  init_sql();
  init_sqlite_core();
  init_session();
  init_utils();
  LibSQLSession = class LibSQLSession extends SQLiteSession {
    constructor(client, dialect, schema, options, tx) {
      super(dialect);
      this.client = client;
      this.schema = schema;
      this.options = options;
      this.tx = tx;
      this.logger = options.logger ?? new NoopLogger;
      this.cache = options.cache ?? new NoopCache;
    }
    static [entityKind] = "LibSQLSession";
    logger;
    cache;
    prepareQuery(query, fields, executeMethod, isResponseInArrayMode, customResultMapper, queryMetadata, cacheConfig) {
      return new LibSQLPreparedQuery(this.client, query, this.logger, this.cache, queryMetadata, cacheConfig, fields, this.tx, executeMethod, isResponseInArrayMode, customResultMapper);
    }
    async batch(queries) {
      const preparedQueries = [];
      const builtQueries = [];
      for (const query of queries) {
        const preparedQuery = query._prepare();
        const builtQuery = preparedQuery.getQuery();
        preparedQueries.push(preparedQuery);
        builtQueries.push({ sql: builtQuery.sql, args: builtQuery.params });
      }
      const batchResults = await this.client.batch(builtQueries);
      return batchResults.map((result, i) => preparedQueries[i].mapResult(result, true));
    }
    async migrate(queries) {
      const preparedQueries = [];
      const builtQueries = [];
      for (const query of queries) {
        const preparedQuery = query._prepare();
        const builtQuery = preparedQuery.getQuery();
        preparedQueries.push(preparedQuery);
        builtQueries.push({ sql: builtQuery.sql, args: builtQuery.params });
      }
      const batchResults = await this.client.migrate(builtQueries);
      return batchResults.map((result, i) => preparedQueries[i].mapResult(result, true));
    }
    async transaction(transaction, _config) {
      const libsqlTx = await this.client.transaction();
      const session = new LibSQLSession(this.client, this.dialect, this.schema, this.options, libsqlTx);
      const tx = new LibSQLTransaction("async", this.dialect, session, this.schema);
      try {
        const result = await transaction(tx);
        await libsqlTx.commit();
        return result;
      } catch (err) {
        await libsqlTx.rollback();
        throw err;
      }
    }
    extractRawAllValueFromBatchResult(result) {
      return result.rows;
    }
    extractRawGetValueFromBatchResult(result) {
      return result.rows[0];
    }
    extractRawValuesValueFromBatchResult(result) {
      return result.rows;
    }
  };
  LibSQLTransaction = class LibSQLTransaction extends SQLiteTransaction {
    static [entityKind] = "LibSQLTransaction";
    async transaction(transaction) {
      const savepointName = `sp${this.nestedIndex}`;
      const tx = new LibSQLTransaction("async", this.dialect, this.session, this.schema, this.nestedIndex + 1);
      await this.session.run(sql.raw(`savepoint ${savepointName}`));
      try {
        const result = await transaction(tx);
        await this.session.run(sql.raw(`release savepoint ${savepointName}`));
        return result;
      } catch (err) {
        await this.session.run(sql.raw(`rollback to savepoint ${savepointName}`));
        throw err;
      }
    }
  };
  LibSQLPreparedQuery = class LibSQLPreparedQuery extends SQLitePreparedQuery {
    constructor(client, query, logger, cache, queryMetadata, cacheConfig, fields, tx, executeMethod, _isResponseInArrayMode, customResultMapper) {
      super("async", executeMethod, query, cache, queryMetadata, cacheConfig);
      this.client = client;
      this.logger = logger;
      this.fields = fields;
      this.tx = tx;
      this._isResponseInArrayMode = _isResponseInArrayMode;
      this.customResultMapper = customResultMapper;
      this.customResultMapper = customResultMapper;
      this.fields = fields;
    }
    static [entityKind] = "LibSQLPreparedQuery";
    async run(placeholderValues) {
      const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
      this.logger.logQuery(this.query.sql, params);
      return await this.queryWithCache(this.query.sql, params, async () => {
        const stmt = { sql: this.query.sql, args: params };
        return this.tx ? this.tx.execute(stmt) : this.client.execute(stmt);
      });
    }
    async all(placeholderValues) {
      const { fields, logger, query, tx, client, customResultMapper } = this;
      if (!fields && !customResultMapper) {
        const params = fillPlaceholders(query.params, placeholderValues ?? {});
        logger.logQuery(query.sql, params);
        return await this.queryWithCache(query.sql, params, async () => {
          const stmt = { sql: query.sql, args: params };
          return (tx ? tx.execute(stmt) : client.execute(stmt)).then(({ rows: rows2 }) => this.mapAllResult(rows2));
        });
      }
      const rows = await this.values(placeholderValues);
      return this.mapAllResult(rows);
    }
    mapAllResult(rows, isFromBatch) {
      if (isFromBatch) {
        rows = rows.rows;
      }
      if (!this.fields && !this.customResultMapper) {
        return rows.map((row) => normalizeRow(row));
      }
      if (this.customResultMapper) {
        return this.customResultMapper(rows, normalizeFieldValue);
      }
      return rows.map((row) => {
        return mapResultRow(this.fields, Array.prototype.slice.call(row).map((v) => normalizeFieldValue(v)), this.joinsNotNullableMap);
      });
    }
    async get(placeholderValues) {
      const { fields, logger, query, tx, client, customResultMapper } = this;
      if (!fields && !customResultMapper) {
        const params = fillPlaceholders(query.params, placeholderValues ?? {});
        logger.logQuery(query.sql, params);
        return await this.queryWithCache(query.sql, params, async () => {
          const stmt = { sql: query.sql, args: params };
          return (tx ? tx.execute(stmt) : client.execute(stmt)).then(({ rows: rows2 }) => this.mapGetResult(rows2));
        });
      }
      const rows = await this.values(placeholderValues);
      return this.mapGetResult(rows);
    }
    mapGetResult(rows, isFromBatch) {
      if (isFromBatch) {
        rows = rows.rows;
      }
      const row = rows[0];
      if (!this.fields && !this.customResultMapper) {
        return normalizeRow(row);
      }
      if (!row) {
        return;
      }
      if (this.customResultMapper) {
        return this.customResultMapper(rows, normalizeFieldValue);
      }
      return mapResultRow(this.fields, Array.prototype.slice.call(row).map((v) => normalizeFieldValue(v)), this.joinsNotNullableMap);
    }
    async values(placeholderValues) {
      const params = fillPlaceholders(this.query.params, placeholderValues ?? {});
      this.logger.logQuery(this.query.sql, params);
      return await this.queryWithCache(this.query.sql, params, async () => {
        const stmt = { sql: this.query.sql, args: params };
        return (this.tx ? this.tx.execute(stmt) : this.client.execute(stmt)).then(({ rows }) => rows);
      });
    }
    isResponseInArrayMode() {
      return this._isResponseInArrayMode;
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/libsql/driver-core.js
function construct(client, config = {}) {
  const dialect = new SQLiteAsyncDialect({ casing: config.casing });
  let logger;
  if (config.logger === true) {
    logger = new DefaultLogger;
  } else if (config.logger !== false) {
    logger = config.logger;
  }
  let schema;
  if (config.schema) {
    const tablesConfig = extractTablesRelationalConfig(config.schema, createTableRelationsHelpers);
    schema = {
      fullSchema: config.schema,
      schema: tablesConfig.tables,
      tableNamesMap: tablesConfig.tableNamesMap
    };
  }
  const session = new LibSQLSession(client, dialect, schema, { logger, cache: config.cache }, undefined);
  const db = new LibSQLDatabase("async", dialect, session, schema);
  db.$client = client;
  db.$cache = config.cache;
  if (db.$cache) {
    db.$cache["invalidate"] = config.cache?.onMutate;
  }
  return db;
}
var LibSQLDatabase;
var init_driver_core = __esm(() => {
  init_entity();
  init_logger();
  init_relations();
  init_db();
  init_dialect();
  init_session2();
  LibSQLDatabase = class LibSQLDatabase extends BaseSQLiteDatabase {
    static [entityKind] = "LibSQLDatabase";
    async batch(batch) {
      return this.session.batch(batch);
    }
  };
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/libsql/driver.js
import { createClient } from "@libsql/client";
function drizzle(...params) {
  if (typeof params[0] === "string") {
    const instance = createClient({
      url: params[0]
    });
    return construct(instance, params[1]);
  }
  if (isConfig(params[0])) {
    const { connection, client, ...drizzleConfig } = params[0];
    if (client)
      return construct(client, drizzleConfig);
    const instance = typeof connection === "string" ? createClient({ url: connection }) : createClient(connection);
    return construct(instance, drizzleConfig);
  }
  return construct(params[0], params[1]);
}
var init_driver = __esm(() => {
  init_utils();
  init_driver_core();
  ((drizzle2) => {
    function mock(config) {
      return construct({}, config);
    }
    drizzle2.mock = mock;
  })(drizzle || (drizzle = {}));
});

// node_modules/.bun/drizzle-orm@0.45.2+4c72a294ad61dd71/node_modules/drizzle-orm/libsql/index.js
var init_libsql = __esm(() => {
  init_driver();
  init_session2();
});

// packages/web/src/api/database/schema.ts
var exports_schema = {};
__export(exports_schema, {
  assets: () => assets,
  dailyReports: () => dailyReports,
  scanRuns: () => scanRuns,
  settings: () => settings,
  signals: () => signals,
  subscribers: () => subscribers
});
var assets, signals, dailyReports, subscribers, settings, scanRuns;
var init_schema = __esm(() => {
  init_sqlite_core();
  assets = sqliteTable("assets", {
    id: integer("id").primaryKey({ autoIncrement: true }),
    symbol: text("symbol").notNull().unique(),
    name: text("name").notNull(),
    kind: text("kind").notNull(),
    isOtc: integer("is_otc", { mode: "boolean" }).notNull().default(false),
    payout: integer("payout").notNull().default(0),
    isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
    feedSymbol: text("feed_symbol"),
    feedStatus: text("feed_status").notNull().default("unknown"),
    lastCandleAt: integer("last_candle_at", { mode: "timestamp" }),
    updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date)
  }, (t) => [index("assets_payout_idx").on(t.payout)]);
  signals = sqliteTable("signals", {
    id: integer("id").primaryKey({ autoIncrement: true }),
    symbol: text("symbol").notNull(),
    assetName: text("asset_name").notNull(),
    direction: text("direction").notNull(),
    confidence: integer("confidence").notNull(),
    score: real("score").notNull(),
    payout: integer("payout").notNull().default(0),
    lowPayout: integer("low_payout", { mode: "boolean" }).notNull().default(false),
    price: real("price").notNull(),
    expirySeconds: integer("expiry_seconds").notNull(),
    entryAt: integer("entry_at", { mode: "timestamp" }).notNull(),
    expiresAt: integer("expires_at", { mode: "timestamp" }).notNull(),
    biasH30: text("bias_h30").notNull(),
    biasM15: text("bias_m15").notNull(),
    triggerM5: text("trigger_m5").notNull(),
    reasons: text("reasons", { mode: "json" }).notNull(),
    details: text("details", { mode: "json" }).notNull(),
    factors: text("factors", { mode: "json" }),
    snapshot: text("snapshot", { mode: "json" }),
    tradeDay: text("trade_day"),
    outcome: text("outcome").notNull().default("pending"),
    resultPrice: real("result_price"),
    resolvedAt: integer("resolved_at", { mode: "timestamp" }),
    resolveNote: text("resolve_note"),
    sentToTelegram: integer("sent_to_telegram", { mode: "boolean" }).notNull().default(false),
    createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date)
  }, (t) => [
    index("signals_created_idx").on(t.createdAt),
    index("signals_symbol_idx").on(t.symbol),
    index("signals_trade_day_idx").on(t.tradeDay),
    index("signals_outcome_idx").on(t.outcome)
  ]);
  dailyReports = sqliteTable("daily_reports", {
    id: integer("id").primaryKey({ autoIncrement: true }),
    day: text("day").notNull().unique(),
    trades: integer("trades").notNull().default(0),
    wins: integer("wins").notNull().default(0),
    losses: integer("losses").notNull().default(0),
    draws: integer("draws").notNull().default(0),
    pending: integer("pending").notNull().default(0),
    winrate: real("winrate").notNull().default(0),
    bestWinStreak: integer("best_win_streak").notNull().default(0),
    worstLossStreak: integer("worst_loss_streak").notNull().default(0),
    analysis: text("analysis", { mode: "json" }).notNull(),
    summary: text("summary").notNull(),
    sentToTelegram: integer("sent_to_telegram", { mode: "boolean" }).notNull().default(false),
    generatedAt: integer("generated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date)
  });
  subscribers = sqliteTable("subscribers", {
    id: integer("id").primaryKey({ autoIncrement: true }),
    chatId: text("chat_id").notNull().unique(),
    title: text("title"),
    isActive: integer("is_active", { mode: "boolean" }).notNull().default(true),
    createdAt: integer("created_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date)
  });
  settings = sqliteTable("settings", {
    id: integer("id").primaryKey({ autoIncrement: true }),
    minConfidence: integer("min_confidence").notNull().default(80),
    scanIntervalSec: integer("scan_interval_sec").notNull().default(60),
    minPayout: integer("min_payout").notNull().default(82),
    maxPayout: integer("max_payout").notNull().default(92),
    cooldownMinutes: integer("cooldown_minutes").notNull().default(15),
    telegramEnabled: integer("telegram_enabled", { mode: "boolean" }).notNull().default(true),
    fallbackPairs: integer("fallback_pairs", { mode: "boolean" }).notNull().default(true),
    scannerEnabled: integer("scanner_enabled", { mode: "boolean" }).notNull().default(true),
    poSsid: text("po_ssid"),
    excludedSymbols: text("excluded_symbols").notNull().default("SYPUSD_otc,IRRUSD_otc"),
    updatedAt: integer("updated_at", { mode: "timestamp" }).notNull().$defaultFn(() => new Date)
  });
  scanRuns = sqliteTable("scan_runs", {
    id: integer("id").primaryKey({ autoIncrement: true }),
    startedAt: integer("started_at", { mode: "timestamp" }).notNull(),
    durationMs: integer("duration_ms").notNull(),
    scanned: integer("scanned").notNull(),
    signalsFound: integer("signals_found").notNull(),
    errors: integer("errors").notNull().default(0),
    note: text("note")
  });
});

// packages/web/src/api/database/__client.ts
import { createClient as createClient2 } from "@libsql/client";
var client, db2;
var init___client = __esm(() => {
  init_libsql();
  init_schema();
  client = createClient2({
    url: process.env.DATABASE_URL,
    authToken: process.env.DATABASE_AUTH_TOKEN
  });
  db2 = drizzle(client, { schema: exports_schema });
});

// packages/web/src/api/database/index.ts
var init_database = __esm(() => {
  init___client();
});

// packages/web/src/api/engine/store.ts
async function getSettings() {
  const rows = await db2.select().from(settings).where(eq(settings.id, 1));
  const existing = rows[0];
  if (existing)
    return existing;
  const [created] = await db2.insert(settings).values({ id: 1 }).returning();
  return created;
}
async function updateSettings(patch) {
  await getSettings();
  const [row] = await db2.update(settings).set({ ...patch, updatedAt: new Date }).where(eq(settings.id, 1)).returning();
  return row;
}
function parseExcluded(raw) {
  if (!raw)
    return new Set;
  return new Set(raw.split(/[,\s;]+/).map((s) => s.trim().toUpperCase()).filter(Boolean));
}
function isExcluded(symbol, excluded) {
  return excluded.has(symbol.trim().toUpperCase());
}
async function addSubscriber(chatId, title) {
  const existing = await db2.select().from(subscribers).where(eq(subscribers.chatId, chatId));
  if (existing[0]) {
    if (!existing[0].isActive) {
      await db2.update(subscribers).set({ isActive: true }).where(eq(subscribers.chatId, chatId));
    }
    return existing[0];
  }
  const [row] = await db2.insert(subscribers).values({ chatId, title: title ?? null }).returning();
  return row;
}
async function deactivateSubscriber(chatId) {
  await db2.update(subscribers).set({ isActive: false }).where(eq(subscribers.chatId, chatId));
}
async function activeSubscribers() {
  return db2.select().from(subscribers).where(eq(subscribers.isActive, true));
}
var init_store = __esm(() => {
  init_drizzle_orm();
  init_database();
  init_schema();
});

// packages/web/src/api/env.ts
function setEnvOverride(key, value) {
  if (value == null || value.trim() === "")
    overrides.delete(key);
  else
    overrides.set(key, value.trim());
}
function envStr(key, fallback = "") {
  const override = overrides.get(key);
  if (override != null)
    return override;
  const value = bag[key];
  return value == null ? fallback : value.trim();
}
function envFlag(key, fallback) {
  const value = envStr(key);
  if (!value)
    return fallback;
  return value !== "0" && value.toLowerCase() !== "false";
}
function engineEnabled() {
  return envFlag("ENGINE_ENABLED", true);
}
async function resolveWs() {
  if (isBun)
    return WebSocket;
  const mod = await import("ws");
  const impl = mod.WebSocket ?? mod.default;
  if (!impl)
    throw new Error("пакет ws не найден — установите зависимости");
  return impl;
}
var bag, overrides, isBun, WS;
var init_env = __esm(async () => {
  bag = process.env;
  overrides = new Map;
  isBun = typeof globalThis.Bun !== "undefined";
  WS = await resolveWs();
});

// packages/web/src/api/market/po-feed.ts
function authMessage() {
  const raw = envStr("POCKET_OPTION_SSID");
  if (!raw)
    return null;
  const match = raw.match(/42\[\s*"auth".*?\}\s*\]/s);
  if (match)
    return match[0];
  const token = raw.replace(/["'\s]/g, "");
  if (!token)
    return null;
  const uid = envStr("POCKET_OPTION_UID", "0");
  const isDemo = envFlag("POCKET_OPTION_DEMO", true) ? 1 : 0;
  return `42["auth",{"session":"${token}","isDemo":${isDemo},"uid":${uid},"platform":2}]`;
}
function ssidLooksLikeCookie() {
  const raw = envStr("POCKET_OPTION_SSID");
  if (!raw)
    return false;
  if (/"session"\s*:/.test(raw))
    return true;
  return !raw.startsWith("42[");
}
function fromTuple(row) {
  const [t, a, b, c, d] = row;
  if (t == null || a == null || b == null || c == null || d == null)
    return null;
  const hi = Math.max(a, b, c, d);
  const lo = Math.min(a, b, c, d);
  if (c === hi && d === lo)
    return { time: Math.floor(t), open: a, high: c, low: d, close: b };
  if (b === hi && c === lo)
    return { time: Math.floor(t), open: a, high: b, low: c, close: d };
  return { time: Math.floor(t), open: a, high: hi, low: lo, close: d };
}
function normalize(rows) {
  const out = [];
  for (const row of rows) {
    if (Array.isArray(row)) {
      if (row.length >= 5) {
        const candle = fromTuple(row);
        if (candle)
          out.push(candle);
      }
      continue;
    }
    if (!row || typeof row !== "object")
      continue;
    const r = row;
    const time = r.time ?? r.t ?? r.timestamp;
    const open = r.open ?? r.o;
    const close = r.close ?? r.c;
    const high = r.high ?? r.h ?? Math.max(open ?? 0, close ?? 0);
    const low = r.low ?? r.l ?? Math.min(open ?? 0, close ?? 0);
    if (time == null || open == null || close == null)
      continue;
    out.push({ time: Math.floor(time), open, high, low, close });
  }
  return out.sort((a, b) => a.time - b.time);
}
function fromTicks(rows, period) {
  const buckets = new Map;
  for (const row of rows) {
    if (!Array.isArray(row) || row.length < 2)
      continue;
    const t = Number(row[0]);
    const p = Number(row[1]);
    if (!Number.isFinite(t) || !Number.isFinite(p))
      continue;
    const key = Math.floor(t / period) * period;
    const existing = buckets.get(key);
    if (!existing)
      buckets.set(key, { time: key, open: p, high: p, low: p, close: p });
    else {
      existing.high = Math.max(existing.high, p);
      existing.low = Math.min(existing.low, p);
      existing.close = p;
    }
  }
  return [...buckets.values()].sort((a, b) => a.time - b.time);
}
function extract(payload, period) {
  if (Array.isArray(payload))
    return { asset: null, candles: normalize(payload) };
  if (!payload || typeof payload !== "object")
    return { asset: null, candles: [] };
  const obj = payload;
  const asset = typeof obj.asset === "string" ? obj.asset : null;
  for (const key of ["candles", "data", "history_candles"]) {
    const value = obj[key];
    if (Array.isArray(value) && value.length) {
      const candles = normalize(value);
      if (candles.length)
        return { asset, candles };
    }
  }
  if (Array.isArray(obj.history) && obj.history.length) {
    return { asset, candles: fromTicks(obj.history, period) };
  }
  return { asset, candles: [] };
}
function feedState() {
  return { state, note: stateNote, lastPayloadAt, authedAt, clockSkewSec };
}
function watchFeedState(cb) {
  watchers.add(cb);
  return () => {
    watchers.delete(cb);
  };
}
function setState(next, note = "") {
  const prev = state;
  state = next;
  stateNote = note;
  if (prev === next)
    return;
  for (const cb of watchers) {
    try {
      cb({ state: next, prev, note });
    } catch (error) {
      console.error("[po-feed] наблюдатель состояния упал:", error.message);
    }
  }
}
function observeSkew(maxTs, live) {
  if (!Number.isFinite(maxTs) || maxTs <= 0)
    return;
  if (!live && maxTs <= maxSeenTs)
    return;
  if (maxTs > maxSeenTs)
    maxSeenTs = maxTs;
  const snapped = Math.round((maxTs - Date.now() / 1000) / SKEW_GRID_SEC) * SKEW_GRID_SEC;
  if (!skewKnown || snapped !== clockSkewSec) {
    if (skewKnown && snapped !== clockSkewSec) {
      console.log(`[po-feed] сдвиг часов брокера: ${clockSkewSec} → ${snapped} с`);
    }
    clockSkewSec = snapped;
    skewKnown = true;
  }
}
async function waitForSkew(timeoutMs = 2500) {
  const until = Date.now() + timeoutMs;
  while (!skewKnown && Date.now() < until) {
    await new Promise((r) => setTimeout(r, 100));
  }
}
function toRealClock(candles) {
  if (!clockSkewSec)
    return candles;
  return candles.map((c) => ({ ...c, time: c.time - clockSkewSec }));
}
function settleAll(error) {
  listeners.clear();
}
function scheduleReconnect() {
  if (!keepAlive || state === "unauthorized" || reconnectTimer)
    return;
  const delay = reconnectDelayMs;
  reconnectDelayMs = Math.min(reconnectDelayMs * 2, RECONNECT_MAX_MS);
  reconnectTimer = setTimeout(() => {
    reconnectTimer = null;
    connect().catch(() => {});
  }, delay);
}
function deliver(asset, candles) {
  lastPayloadAt = Date.now();
  setState("live");
  if (asset) {
    const exact = listeners.get(asset);
    if (exact) {
      exact(candles);
      return;
    }
    return;
  }
  const first = listeners.values().next();
  if (!first.done)
    first.value(candles);
}
function cacheKey2(asset, period) {
  return `${asset}:${period}`;
}
function hasLatestClosed(candles, period) {
  const last = candles.at(-1);
  if (!last)
    return false;
  const gridOpen = Math.floor(Date.now() / 1000 / period) * period - period;
  return last.time >= gridOpen;
}
function connect() {
  if (socket && socket.readyState === WS_OPEN && state === "live")
    return Promise.resolve();
  if (socket && (socket.readyState === WS_CONNECTING || state === "connecting")) {
    return Promise.resolve();
  }
  const auth = authMessage();
  if (!auth) {
    setState("unauthorized", "POCKET_OPTION_SSID не задан");
    return Promise.reject(new Error(stateNote));
  }
  if (reconnectTimer) {
    clearTimeout(reconnectTimer);
    reconnectTimer = null;
  }
  setState("connecting");
  const url = envFlag("POCKET_OPTION_DEMO", true) ? WS_DEMO : WS_LIVE;
  const ws = new WS(url, { headers: { Origin: "https://pocketoption.com", "User-Agent": UA } });
  ws.binaryType = "arraybuffer";
  socket = ws;
  let pendingEvent = null;
  const handlePayload = (event, text) => {
    if (event === "successauth") {
      authedAt = Date.now();
      setState("live");
      reconnectDelayMs = RECONNECT_MIN_MS;
      return;
    }
    const isStream = STREAM_EVENTS.has(event);
    if (!isStream && !CANDLE_EVENTS.has(event))
      return;
    let payload;
    try {
      payload = JSON.parse(text);
    } catch {
      return;
    }
    if (isStream) {
      if (Array.isArray(payload)) {
        for (const row of payload) {
          if (Array.isArray(row) && row.length >= 2)
            observeSkew(Number(row[1]), true);
        }
      }
      return;
    }
    const hint = payload && typeof payload === "object" ? payload.asset : null;
    const symbol = typeof hint === "string" ? hint : null;
    const period = (symbol ? askedPeriod.get(symbol) : null) ?? DEFAULT_PERIOD;
    const { asset, candles } = extract(payload, period);
    if (!candles.length)
      return;
    observeSkew(candles.at(-1).time, false);
    deliver(asset ?? symbol, toRealClock(candles));
  };
  const handleText = (text) => {
    if (text.startsWith("0{")) {
      ws.send("40");
      return;
    }
    if (text === "2") {
      ws.send("3");
      return;
    }
    if (text.startsWith("40")) {
      ws.send(auth);
      return;
    }
    const placeholder = text.match(/^\d+-\[\s*"([^"]+)"/);
    if (placeholder) {
      pendingEvent = placeholder[1] ?? null;
      return;
    }
    if (text.startsWith("42[")) {
      try {
        const [event, payload] = JSON.parse(text.slice(2));
        handlePayload(event, JSON.stringify(payload ?? null));
      } catch {}
      return;
    }
    if (pendingEvent && (text.startsWith("[") || text.startsWith("{"))) {
      const event = pendingEvent;
      pendingEvent = null;
      handlePayload(event, text);
    }
  };
  const handleBinary = (text) => {
    const event = pendingEvent;
    pendingEvent = null;
    if (event)
      handlePayload(event, text);
  };
  ws.addEventListener("message", (event) => {
    const data = event.data;
    if (typeof data === "string") {
      handleText(data);
      return;
    }
    if (data instanceof ArrayBuffer) {
      handleBinary(new TextDecoder().decode(new Uint8Array(data)));
      return;
    }
    if (data instanceof Uint8Array) {
      handleBinary(new TextDecoder().decode(data));
      return;
    }
    if (typeof Blob !== "undefined" && data instanceof Blob) {
      data.text().then(handleBinary);
      return;
    }
    handleText(String(data));
  });
  ws.addEventListener("close", () => {
    if (socket === ws)
      socket = null;
    if (state !== "unauthorized") {
      setState(keepAlive ? "connecting" : "idle", keepAlive ? "переподключение" : "соединение закрыто");
    }
    settleAll(new Error("Pocket Option: соединение закрыто"));
    scheduleReconnect();
  });
  ws.addEventListener("error", () => {
    if (socket === ws)
      socket = null;
    if (state !== "unauthorized") {
      setState(keepAlive ? "connecting" : "error", keepAlive ? "переподключение" : "ошибка WebSocket");
    }
    settleAll(new Error("Pocket Option: ошибка WebSocket"));
    scheduleReconnect();
  });
  return new Promise((resolve) => {
    const started = Date.now();
    const check = setInterval(() => {
      const open = ws.readyState === WS_OPEN;
      if (open && state === "live" || Date.now() - started > CONNECT_TIMEOUT_MS) {
        clearInterval(check);
        resolve();
      }
    }, 100);
  });
}
async function poCandles(asset, period = 300, bars = 300) {
  const want = Math.min(Math.max(bars, MIN_BARS), PAGE_BARS * MAX_PAGES);
  const key = cacheKey2(asset, period);
  const cached = historyCache.get(key);
  if (cached && Date.now() - cached.at < HISTORY_TTL_MS && cached.candles.length >= MIN_BARS && hasLatestClosed(cached.candles, period)) {
    return cached.candles;
  }
  keepAlive = true;
  await connect();
  const ws = socket;
  if (!ws || ws.readyState !== WS_OPEN) {
    throw new Error(`PO-фид недоступен (${stateNote || state})`);
  }
  await waitForSkew();
  if (listeners.has(asset)) {
    throw new Error(`${asset}: запрос истории уже выполняется`);
  }
  const debug = envFlag("PO_FEED_DEBUG", false);
  askedPeriod.set(asset, period);
  const merged = new Map;
  let onPage = null;
  listeners.set(asset, (candles) => {
    for (const candle of candles)
      merged.set(candle.time, candle);
    onPage?.();
  });
  const requestPage = (time, page) => new Promise((resolve) => {
    const timer = setTimeout(() => {
      onPage = null;
      resolve();
    }, PAGE_TIMEOUT_MS);
    onPage = () => {
      clearTimeout(timer);
      onPage = null;
      resolve();
    };
    ws.send(`42["loadHistoryPeriod",{"asset":"${asset}","time":${time},"index":${Date.now() + page},"offset":${period * PAGE_BARS},"period":${period}}]`);
  });
  try {
    ws.send(`42["changeSymbol",{"asset":"${asset}","period":${period}}]`);
    let cursor = Math.floor(Date.now() / 1000) + clockSkewSec;
    let empty = 0;
    for (let page = 1;page <= MAX_PAGES; page++) {
      const before = merged.size;
      await requestPage(cursor, page);
      const added = merged.size - before;
      if (debug) {
        console.log(`[po-feed] ${asset} страница ${page}: +${added} → ${merged.size}`);
      }
      if (merged.size >= want)
        break;
      if (added === 0 && ++empty >= 2)
        break;
      if (added > 0)
        empty = 0;
      cursor = Math.min(...merged.keys()) + clockSkewSec - period;
    }
  } finally {
    listeners.delete(asset);
  }
  const candles = [...merged.values()].sort((a, b) => a.time - b.time);
  if (!candles.length) {
    if (state !== "live") {
      setState("unauthorized", "PO не отвечает на запрос свечей — нужен рабочий cookie ssid");
    }
    throw new Error(`${asset}: PO не отдал свечи (нужен рабочий cookie ssid)`);
  }
  historyCache.set(key, { at: Date.now(), candles });
  return candles;
}
var WS_DEMO = "wss://demo-api-eu.po.market/socket.io/?EIO=4&transport=websocket", WS_LIVE = "wss://api-eu.po.market/socket.io/?EIO=4&transport=websocket", UA, STREAM_EVENTS, CANDLE_EVENTS, PAGE_BARS = 150, MAX_PAGES = 6, HISTORY_TTL_MS = 50000, MIN_BARS = 180, DEFAULT_PERIOD = 300, PAGE_TIMEOUT_MS = 6000, CONNECT_TIMEOUT_MS = 9000, SKEW_GRID_SEC = 1800, RECONNECT_MIN_MS = 1500, RECONNECT_MAX_MS = 30000, WS_CONNECTING = 0, WS_OPEN = 1, socket = null, state = "idle", stateNote = "", lastPayloadAt = 0, authedAt = 0, clockSkewSec = 0, skewKnown = false, maxSeenTs = 0, keepAlive = false, reconnectTimer = null, reconnectDelayMs, listeners, historyCache, watchScope, watchers, askedPeriod;
var init_po_feed = __esm(async () => {
  await init_env();
  UA = envStr("POCKET_OPTION_UA", "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36");
  STREAM_EVENTS = new Set(["updateStream"]);
  CANDLE_EVENTS = new Set([
    "candles",
    "history",
    "loadHistoryPeriod",
    "loadHistoryPeriodFast",
    "updateHistoryNew",
    "updateHistoryNewFast"
  ]);
  reconnectDelayMs = RECONNECT_MIN_MS;
  listeners = new Map;
  historyCache = new Map;
  watchScope = globalThis;
  watchScope.__poFeedWatchers ??= new Set;
  watchers = watchScope.__poFeedWatchers;
  askedPeriod = new Map;
});

// packages/web/src/api/market/candles.ts
function toFeedSymbol(poSymbol) {
  if (poSymbol.endsWith("_otc"))
    return null;
  const base = poSymbol.replace(/_otc$/, "");
  if (/^[A-Z]{6}$/.test(base))
    return `${base}=X`;
  return null;
}
function isOtc(poSymbol) {
  return poSymbol.endsWith("_otc");
}
async function fetchFiveMinute(feedSymbol) {
  const gridOpen = Math.floor(Date.now() / 1000 / 300) * 300 - 300;
  const cached = cache2.get(feedSymbol);
  if (cached) {
    const age = Date.now() - cached.at;
    const hasLatest = (cached.data.at(-1)?.time ?? 0) >= gridOpen;
    if (hasLatest ? age < CACHE_TTL_MS : age < MIN_REFETCH_MS)
      return cached.data;
  }
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(feedSymbol)}?interval=5m&range=5d`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
      Accept: "application/json"
    },
    signal: AbortSignal.timeout(12000)
  });
  if (!res.ok)
    throw new Error(`feed ${feedSymbol}: HTTP ${res.status}`);
  const json = await res.json();
  const result = json.chart?.result?.[0];
  const quote = result?.indicators?.quote?.[0];
  const ts = result?.timestamp;
  if (!ts || !quote)
    throw new Error(`feed ${feedSymbol}: пустой ответ`);
  const candles = [];
  for (let i = 0;i < ts.length; i++) {
    const o = quote.open?.[i];
    const h = quote.high?.[i];
    const l = quote.low?.[i];
    const c = quote.close?.[i];
    if (o == null || h == null || l == null || c == null)
      continue;
    candles.push({ time: ts[i], open: o, high: h, low: l, close: c });
  }
  const now = Math.floor(Date.now() / 1000);
  while (candles.length && candles.at(-1).time + 300 > now)
    candles.pop();
  cache2.set(feedSymbol, { at: Date.now(), data: candles });
  return candles;
}
function aggregate2(candles, bucketSeconds) {
  const buckets = new Map;
  for (const c of candles) {
    const key = Math.floor(c.time / bucketSeconds) * bucketSeconds;
    const existing = buckets.get(key);
    if (!existing) {
      buckets.set(key, { time: key, open: c.open, high: c.high, low: c.low, close: c.close });
    } else {
      existing.high = Math.max(existing.high, c.high);
      existing.low = Math.min(existing.low, c.low);
      existing.close = c.close;
    }
  }
  const out = [...buckets.values()].sort((a, b) => a.time - b.time);
  const now = Math.floor(Date.now() / 1000);
  while (out.length && out.at(-1).time + bucketSeconds > now)
    out.pop();
  return out;
}
function buildSet(m5, source) {
  return {
    m5,
    m15: aggregate2(m5, 900),
    m30: aggregate2(m5, 1800),
    lastCandleAt: m5.at(-1).time,
    source
  };
}
async function getCandleSet(poSymbol) {
  if (ssidLooksLikeCookie()) {
    try {
      const m5 = await poCandles(poSymbol, 300, 240);
      if (m5.length >= 60)
        return buildSet(m5, "pocket-option");
    } catch (error) {
      if (isOtc(poSymbol))
        throw error;
    }
  }
  const feedSymbol = toFeedSymbol(poSymbol);
  if (!feedSymbol) {
    throw new Error(`${poSymbol}: OTC-пара — публичного фида нет, нужен рабочий cookie ssid Pocket Option`);
  }
  const m5 = await fetchFiveMinute(feedSymbol);
  if (m5.length < 60)
    throw new Error(`${poSymbol}: мало свечей (${m5.length})`);
  return buildSet(m5, "public-feed");
}
function isStale(lastCandleAt) {
  return Date.now() / 1000 - lastCandleAt > 20 * 60;
}
var cache2, CACHE_TTL_MS = 55000, MIN_REFETCH_MS = 20000;
var init_candles = __esm(async () => {
  await init_po_feed();
  cache2 = new Map;
});

// packages/web/src/api/market/pocket-option.ts
function authMessage2() {
  const raw = envStr("POCKET_OPTION_SSID");
  if (!raw)
    throw new Error("POCKET_OPTION_SSID не задан");
  const match = raw.match(/42\[\s*"auth".*?\}\s*\]/s);
  if (match)
    return match[0];
  const token = raw.replace(/["'\s]/g, "");
  const uid = envStr("POCKET_OPTION_UID", "0");
  const isDemo = envFlag("POCKET_OPTION_DEMO", true) ? 1 : 0;
  return `42["auth",{"session":"${token}","isDemo":${isDemo},"uid":${uid},"platform":2}]`;
}
function parseAssets(payload) {
  const raw = JSON.parse(payload);
  const out = [];
  for (const entry of raw) {
    if (!Array.isArray(entry))
      continue;
    const [id, symbol, name, kind, , payout, , , , , , , , , isActiveFlag] = entry;
    if (typeof symbol !== "string" || typeof kind !== "string")
      continue;
    out.push({
      id: Number(id) || 0,
      symbol,
      name: typeof name === "string" ? name : symbol,
      kind,
      payout: Number(payout) || 0,
      isOtc: symbol.endsWith("_otc"),
      isActive: Boolean(isActiveFlag)
    });
  }
  return out;
}
function fetchSnapshot(timeoutMs = 20000) {
  return new Promise((resolve, reject) => {
    let auth;
    try {
      auth = authMessage2();
    } catch (error) {
      reject(error);
      return;
    }
    const url = envFlag("POCKET_OPTION_DEMO", true) ? WS_URL : LIVE_WS_URL;
    const ws = new WS(url, {
      headers: { Origin: "https://pocketoption.com", "User-Agent": UA2 }
    });
    let pendingEvent = null;
    let authOk = false;
    let settled = false;
    const timer = setTimeout(() => {
      if (settled)
        return;
      settled = true;
      try {
        ws.close();
      } catch {}
      reject(new Error("Pocket Option: таймаут получения активов"));
    }, timeoutMs);
    const finish = (snapshot) => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      try {
        ws.close();
      } catch {}
      resolve(snapshot);
    };
    const handleFrame = (text) => {
      if (pendingEvent === "updateAssets" && text.startsWith("[")) {
        pendingEvent = null;
        try {
          finish({
            assets: parseAssets(text),
            fetchedAt: Date.now(),
            authOk,
            candleFeed: false
          });
        } catch (error) {
          if (!settled) {
            settled = true;
            clearTimeout(timer);
            reject(error);
          }
        }
        return;
      }
      if (text.startsWith("0{")) {
        ws.send("40");
        return;
      }
      if (text === "2") {
        ws.send("3");
        return;
      }
      if (text.startsWith("40")) {
        ws.send(auth);
        return;
      }
      if (/^\d+-\[/.test(text)) {
        try {
          pendingEvent = JSON.parse(text.replace(/^\d+-/, ""))[0];
        } catch {
          pendingEvent = null;
        }
        return;
      }
      if (text.includes("successauth") || text.includes("auth/success"))
        authOk = true;
    };
    ws.addEventListener("message", (event) => {
      const data = event.data;
      if (data instanceof ArrayBuffer) {
        handleFrame(new TextDecoder().decode(new Uint8Array(data)));
        return;
      }
      if (data instanceof Blob) {
        data.text().then(handleFrame);
        return;
      }
      handleFrame(String(data));
    });
    ws.addEventListener("error", () => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      reject(new Error("Pocket Option: ошибка WebSocket"));
    });
    ws.addEventListener("close", () => {
      if (settled)
        return;
      settled = true;
      clearTimeout(timer);
      reject(new Error("Pocket Option: соединение закрыто до получения активов"));
    });
  });
}
async function getAssets(force = false) {
  if (!force && snapshotCache && Date.now() - snapshotCache.fetchedAt < SNAPSHOT_TTL_MS) {
    return snapshotCache;
  }
  if (inflight)
    return inflight;
  inflight = fetchSnapshot().then((snap) => {
    snapshotCache = snap;
    return snap;
  }).finally(() => {
    inflight = null;
  });
  return inflight;
}
function cachedSnapshot() {
  return snapshotCache;
}
var WS_URL = "wss://demo-api-eu.po.market/socket.io/?EIO=4&transport=websocket", LIVE_WS_URL = "wss://api-eu.po.market/socket.io/?EIO=4&transport=websocket", UA2 = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36", snapshotCache = null, inflight = null, SNAPSHOT_TTL_MS;
var init_pocket_option = __esm(async () => {
  await init_env();
  SNAPSHOT_TTL_MS = 10 * 60 * 1000;
});

// packages/web/src/api/strategy/indicators.ts
function ema(values, period) {
  const out = [];
  const k = 2 / (period + 1);
  let prev = Number.NaN;
  for (let i = 0;i < values.length; i++) {
    const v = values[i];
    if (i < period - 1) {
      out.push(Number.NaN);
      continue;
    }
    if (Number.isNaN(prev)) {
      let sum = 0;
      for (let j = i - period + 1;j <= i; j++)
        sum += values[j];
      prev = sum / period;
    } else {
      prev = v * k + prev * (1 - k);
    }
    out.push(prev);
  }
  return out;
}
function rsi(values, period = 14) {
  const out = Array.from({ length: values.length }, () => Number.NaN);
  if (values.length <= period)
    return out;
  let gain = 0;
  let loss = 0;
  for (let i = 1;i <= period; i++) {
    const d = values[i] - values[i - 1];
    if (d >= 0)
      gain += d;
    else
      loss -= d;
  }
  gain /= period;
  loss /= period;
  out[period] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  for (let i = period + 1;i < values.length; i++) {
    const d = values[i] - values[i - 1];
    const g = d > 0 ? d : 0;
    const l = d < 0 ? -d : 0;
    gain = (gain * (period - 1) + g) / period;
    loss = (loss * (period - 1) + l) / period;
    out[i] = loss === 0 ? 100 : 100 - 100 / (1 + gain / loss);
  }
  return out;
}
function macd(values, fast = 12, slow = 26, signalPeriod = 9) {
  const emaFast = ema(values, fast);
  const emaSlow = ema(values, slow);
  const macdLine = values.map((_, i) => Number.isNaN(emaFast[i]) || Number.isNaN(emaSlow[i]) ? Number.NaN : emaFast[i] - emaSlow[i]);
  const valid = macdLine.filter((v) => !Number.isNaN(v));
  const signalValid = ema(valid, signalPeriod);
  const offset = macdLine.length - valid.length;
  const signal = Array.from({ length: macdLine.length }, () => Number.NaN);
  for (let i = 0;i < signalValid.length; i++)
    signal[i + offset] = signalValid[i];
  const histogram = macdLine.map((v, i) => Number.isNaN(v) || Number.isNaN(signal[i]) ? Number.NaN : v - signal[i]);
  return { macd: macdLine, signal, histogram };
}
function atr(candles, period = 14) {
  const out = Array.from({ length: candles.length }, () => Number.NaN);
  if (candles.length <= period)
    return out;
  const trs = [0];
  for (let i = 1;i < candles.length; i++) {
    const c = candles[i];
    const prev = candles[i - 1];
    trs.push(Math.max(c.high - c.low, Math.abs(c.high - prev.close), Math.abs(c.low - prev.close)));
  }
  let sum = 0;
  for (let i = 1;i <= period; i++)
    sum += trs[i];
  let prevAtr = sum / period;
  out[period] = prevAtr;
  for (let i = period + 1;i < candles.length; i++) {
    prevAtr = (prevAtr * (period - 1) + trs[i]) / period;
    out[i] = prevAtr;
  }
  return out;
}
function closes(candles) {
  return candles.map((c) => c.close);
}

// packages/web/src/api/strategy/structure.ts
function findSwings(candles, strength = 2) {
  const swings = [];
  for (let i = strength;i < candles.length - strength; i++) {
    const c = candles[i];
    let isHigh = true;
    let isLow = true;
    for (let j = i - strength;j <= i + strength; j++) {
      if (j === i)
        continue;
      if (candles[j].high >= c.high)
        isHigh = false;
      if (candles[j].low <= c.low)
        isLow = false;
    }
    if (isHigh)
      swings.push({ index: i, price: c.high, kind: "high" });
    if (isLow)
      swings.push({ index: i, price: c.low, kind: "low" });
  }
  return swings;
}
function analyzeStructure(candles) {
  const swings = findSwings(candles, 2);
  const highs = swings.filter((s) => s.kind === "high");
  const lows = swings.filter((s) => s.kind === "low");
  const lastClose = candles.at(-1)?.close ?? 0;
  const h1 = highs.at(-1);
  const h2 = highs.at(-2);
  const l1 = lows.at(-1);
  const l2 = lows.at(-2);
  let bias = "neutral";
  let pattern = "range";
  if (h1 && h2 && l1 && l2) {
    const hh = h1.price > h2.price;
    const hl = l1.price > l2.price;
    const lh = h1.price < h2.price;
    const ll = l1.price < l2.price;
    if (hh && hl) {
      bias = "bullish";
      pattern = "HH + HL";
    } else if (lh && ll) {
      bias = "bearish";
      pattern = "LH + LL";
    } else if (hh && ll) {
      pattern = "расширение диапазона";
    } else if (lh && hl) {
      pattern = "сужение (компрессия)";
    } else if (hh || hl) {
      bias = "bullish";
      pattern = hh ? "HH" : "HL";
    } else if (lh || ll) {
      bias = "bearish";
      pattern = lh ? "LH" : "LL";
    }
  }
  let bos = null;
  let choch = null;
  const recent = candles.slice(-3);
  if (h1) {
    const brokeUp = recent.some((c) => c.close > h1.price);
    if (brokeUp) {
      if (bias === "bullish")
        bos = "call";
      else
        choch = "call";
    }
  }
  if (l1) {
    const brokeDown = recent.some((c) => c.close < l1.price);
    if (brokeDown) {
      if (bias === "bearish")
        bos = "put";
      else
        choch = "put";
    }
  }
  const rangeHigh = h1?.price ?? Math.max(...candles.slice(-30).map((c) => c.high));
  const rangeLow = l1?.price ?? Math.min(...candles.slice(-30).map((c) => c.low));
  const span = rangeHigh - rangeLow;
  const rangePosition = span > 0 ? (lastClose - rangeLow) / span : 0.5;
  const zone = rangePosition > 0.62 ? "premium" : rangePosition < 0.38 ? "discount" : "equilibrium";
  return {
    bias,
    pattern,
    choch,
    bos,
    swingHigh: h1?.price ?? null,
    swingLow: l1?.price ?? null,
    rangePosition: Number(rangePosition.toFixed(3)),
    zone
  };
}
function findLevels(candles) {
  const atrSeries = atr(candles, 14);
  const a = atrSeries.at(-1) ?? 0;
  if (!a || Number.isNaN(a))
    return [];
  const tolerance = a * 0.6;
  const swings = findSwings(candles, 2);
  const lastClose = candles.at(-1).close;
  const clusters = [];
  for (const s of swings) {
    const hit = clusters.find((c) => Math.abs(c.price - s.price) <= tolerance && c.kind === s.kind);
    if (hit) {
      hit.price = (hit.price * hit.touches + s.price) / (hit.touches + 1);
      hit.touches += 1;
    } else {
      clusters.push({ price: s.price, touches: 1, kind: s.kind });
    }
  }
  return clusters.map((c) => ({
    price: c.price,
    touches: c.touches,
    kind: c.price < lastClose ? "support" : "resistance",
    distanceAtr: Number((Math.abs(c.price - lastClose) / a).toFixed(2))
  })).sort((x, y) => x.distanceAtr - y.distanceAtr);
}
function findFvg(candles, lookback = 20) {
  const out = [];
  const start = Math.max(1, candles.length - lookback);
  for (let i = start;i < candles.length - 1; i++) {
    const prev = candles[i - 1];
    const next = candles[i + 1];
    if (next.low > prev.high) {
      out.push({ direction: "call", bottom: prev.high, top: next.low, index: i });
    } else if (next.high < prev.low) {
      out.push({ direction: "put", bottom: next.high, top: prev.low, index: i });
    }
  }
  return out;
}
function detectLiquiditySweep(candles, lookback = 12) {
  if (candles.length < lookback + 2)
    return null;
  const c = candles.at(-1);
  const window = candles.slice(-lookback - 1, -1);
  const priorHigh = Math.max(...window.map((x) => x.high));
  const priorLow = Math.min(...window.map((x) => x.low));
  const body = Math.abs(c.close - c.open);
  const upperWick = c.high - Math.max(c.open, c.close);
  const lowerWick = Math.min(c.open, c.close) - c.low;
  if (c.high > priorHigh && c.close < priorHigh && upperWick > body)
    return "put";
  if (c.low < priorLow && c.close > priorLow && lowerWick > body)
    return "call";
  return null;
}
function findOrderBlock(candles, lookback = 25) {
  const atrSeries = atr(candles, 14);
  const a = atrSeries.at(-1) ?? 0;
  if (!a || Number.isNaN(a))
    return null;
  for (let i = candles.length - 2;i > Math.max(1, candles.length - lookback); i--) {
    const c = candles[i];
    const prev = candles[i - 1];
    const impulse = Math.abs(c.close - c.open);
    if (impulse < a * 1.2)
      continue;
    const bullishImpulse = c.close > c.open;
    const prevOpposite = bullishImpulse ? prev.close < prev.open : prev.close > prev.open;
    if (!prevOpposite)
      continue;
    return {
      direction: bullishImpulse ? "call" : "put",
      top: Math.max(prev.open, prev.close),
      bottom: Math.min(prev.open, prev.close)
    };
  }
  return null;
}
function detectPatterns(candles) {
  const out = [];
  if (candles.length < 4)
    return out;
  const c = candles.at(-1);
  const p = candles.at(-2);
  const p2 = candles.at(-3);
  const body = Math.abs(c.close - c.open);
  const range = c.high - c.low || 0.000000001;
  const upperWick = c.high - Math.max(c.open, c.close);
  const lowerWick = Math.min(c.open, c.close) - c.low;
  const prevBody = Math.abs(p.close - p.open);
  const bull = c.close > c.open;
  if (bull && p.close < p.open && c.close >= p.open && c.open <= p.close && body > prevBody * 1.05) {
    out.push({ name: "Бычье поглощение", direction: "call", strength: 1 });
  }
  if (!bull && p.close > p.open && c.close <= p.open && c.open >= p.close && body > prevBody * 1.05) {
    out.push({ name: "Медвежье поглощение", direction: "put", strength: 1 });
  }
  if (lowerWick > body * 2 && upperWick < body && body / range < 0.4) {
    out.push({ name: "Молот (пин-бар)", direction: "call", strength: 0.9 });
  }
  if (upperWick > body * 2 && lowerWick < body && body / range < 0.4) {
    out.push({ name: "Падающая звезда", direction: "put", strength: 0.9 });
  }
  const smallMiddle = prevBody < Math.abs(p2.close - p2.open) * 0.6;
  if (smallMiddle && p2.close < p2.open && bull && c.close > (p2.open + p2.close) / 2) {
    out.push({ name: "Утренняя звезда", direction: "call", strength: 1 });
  }
  if (smallMiddle && p2.close > p2.open && !bull && c.close < (p2.open + p2.close) / 2) {
    out.push({ name: "Вечерняя звезда", direction: "put", strength: 1 });
  }
  const inside = p.high < p2.high && p.low > p2.low;
  if (inside && c.close > p.high) {
    out.push({ name: "Пробой внутреннего бара", direction: "call", strength: 0.7 });
  }
  if (inside && c.close < p.low) {
    out.push({ name: "Пробой внутреннего бара", direction: "put", strength: 0.7 });
  }
  const c1 = candles.at(-1);
  const c2 = candles.at(-2);
  const c3 = candles.at(-3);
  if (c1.close > c1.open && c2.close > c2.open && c3.close > c3.open && c1.close > c2.close) {
    out.push({ name: "Три белых солдата", direction: "call", strength: 0.6 });
  }
  if (c1.close < c1.open && c2.close < c2.open && c3.close < c3.open && c1.close < c2.close) {
    out.push({ name: "Три чёрные вороны", direction: "put", strength: 0.6 });
  }
  return out;
}
var init_structure = () => {};

// packages/web/src/api/strategy/analyze.ts
function biasLabel(b) {
  return b === "bullish" ? "вверх" : b === "bearish" ? "вниз" : "нейтрально";
}
function dirOf(b) {
  return b === "bullish" ? "call" : b === "bearish" ? "put" : "neutral";
}
function analyze(tf) {
  const factors = [];
  const blockers = [];
  const s30 = analyzeStructure(tf.m30);
  const s15 = analyzeStructure(tf.m15);
  const s5 = analyzeStructure(tf.m5);
  const price = tf.m5.at(-1).close;
  factors.push({
    label: "30m структура",
    detail: `${s30.pattern} (${biasLabel(s30.bias)})`,
    direction: dirOf(s30.bias),
    weight: 2.4
  });
  if (s30.bos) {
    factors.push({
      label: "30m BOS",
      detail: "пробой структуры в сторону тренда",
      direction: s30.bos,
      weight: 1.2
    });
  }
  if (s30.choch) {
    factors.push({
      label: "30m CHoCH",
      detail: "смена характера структуры",
      direction: s30.choch,
      weight: 1
    });
  }
  if (s30.zone !== "equilibrium") {
    factors.push({
      label: "30m зона",
      detail: s30.zone === "discount" ? "discount (дешёвая зона)" : "premium (дорогая зона)",
      direction: s30.zone === "discount" ? "call" : "put",
      weight: 1
    });
  }
  factors.push({
    label: "15m структура",
    detail: `${s15.pattern} (${biasLabel(s15.bias)})`,
    direction: dirOf(s15.bias),
    weight: 1.8
  });
  const ob15 = findOrderBlock(tf.m15);
  if (ob15) {
    const inside = price >= ob15.bottom * 0.9995 && price <= ob15.top * 1.0005;
    factors.push({
      label: "15m order block",
      detail: inside ? "цена в зоне OB" : "OB по тренду выше/ниже",
      direction: ob15.direction,
      weight: inside ? 1.5 : 0.6
    });
  }
  const fvg15 = findFvg(tf.m15, 20);
  const nearFvg = fvg15.find((f) => price >= f.bottom && price <= f.top);
  if (nearFvg) {
    factors.push({
      label: "15m имбаланс",
      detail: "цена внутри FVG",
      direction: nearFvg.direction,
      weight: 1.2
    });
  }
  const m15Macd = macd(closes(tf.m15));
  const h15 = m15Macd.histogram.at(-1) ?? Number.NaN;
  const h15prev = m15Macd.histogram.at(-2) ?? Number.NaN;
  if (!Number.isNaN(h15) && !Number.isNaN(h15prev)) {
    const rising = h15 > h15prev;
    factors.push({
      label: "15m MACD",
      detail: `гистограмма ${h15 > 0 ? "выше" : "ниже"} нуля, ${rising ? "растёт" : "падает"}`,
      direction: h15 > 0 && rising ? "call" : h15 < 0 && !rising ? "put" : "neutral",
      weight: 1.3
    });
  }
  const patterns = detectPatterns(tf.m5);
  const bestPattern = patterns.sort((a, b) => b.strength - a.strength)[0];
  if (bestPattern) {
    factors.push({
      label: "5m паттерн",
      detail: bestPattern.name,
      direction: bestPattern.direction,
      weight: 1.6 * bestPattern.strength
    });
  }
  const sweep5 = detectLiquiditySweep(tf.m5);
  if (sweep5) {
    factors.push({
      label: "5m ликвидность",
      detail: "снятие ликвидности с возвратом",
      direction: sweep5,
      weight: 1.4
    });
  }
  const m5Macd = macd(closes(tf.m5));
  const h5 = m5Macd.histogram.at(-1) ?? Number.NaN;
  const h5prev = m5Macd.histogram.at(-2) ?? Number.NaN;
  let macdCross = "neutral";
  if (!Number.isNaN(h5) && !Number.isNaN(h5prev)) {
    const cross = h5 > 0 && h5prev <= 0 ? "call" : h5 < 0 && h5prev >= 0 ? "put" : "neutral";
    macdCross = cross;
    factors.push({
      label: "5m MACD",
      detail: cross === "neutral" ? `импульс ${h5 > h5prev ? "усиливается" : "слабеет"}` : "пересечение нулевой линии",
      direction: cross === "neutral" ? h5 > h5prev ? "call" : "put" : cross,
      weight: cross === "neutral" ? 0.8 : 1.4
    });
  }
  const r5 = rsi(closes(tf.m5));
  const rsiNow = r5.at(-1) ?? Number.NaN;
  if (!Number.isNaN(rsiNow)) {
    let rsiDir = "neutral";
    let rsiDetail = `RSI ${rsiNow.toFixed(1)}`;
    if (rsiNow <= 30) {
      rsiDir = "call";
      rsiDetail = `перепроданность (${rsiNow.toFixed(1)})`;
    } else if (rsiNow >= 70) {
      rsiDir = "put";
      rsiDetail = `перекупленность (${rsiNow.toFixed(1)})`;
    } else if (rsiNow > 50 && rsiNow < 65) {
      rsiDir = "call";
      rsiDetail = `выше середины (${rsiNow.toFixed(1)})`;
    } else if (rsiNow < 50 && rsiNow > 35) {
      rsiDir = "put";
      rsiDetail = `ниже середины (${rsiNow.toFixed(1)})`;
    }
    factors.push({ label: "5m RSI", detail: rsiDetail, direction: rsiDir, weight: 1.1 });
    const div = rsiDivergence(tf.m5, r5);
    if (div) {
      factors.push({
        label: "5m дивергенция",
        detail: div === "call" ? "бычья дивергенция RSI" : "медвежья дивергенция RSI",
        direction: div,
        weight: 1.3
      });
    }
  }
  const levels = findLevels(tf.m15);
  const nearest = levels[0];
  if (nearest && nearest.distanceAtr <= 0.5) {
    factors.push({
      label: "Уровень 15m",
      detail: `цена у ${nearest.kind === "support" ? "поддержки" : "сопротивления"} ${nearest.price.toFixed(5)} (${nearest.touches} касаний)`,
      direction: nearest.kind === "support" ? "call" : "put",
      weight: 1.5 + Math.min(nearest.touches, 4) * 0.15
    });
  } else if (nearest) {
    factors.push({
      label: "Уровень 15m",
      detail: `ближайший ${nearest.kind === "support" ? "саппорт" : "резист"} в ${nearest.distanceAtr} ATR`,
      direction: "neutral",
      weight: 0
    });
  }
  let callScore = 0;
  let putScore = 0;
  let maxScore = 0;
  for (const f of factors) {
    maxScore += f.weight;
    if (f.direction === "call")
      callScore += f.weight;
    else if (f.direction === "put")
      putScore += f.weight;
  }
  const direction = callScore === putScore ? null : callScore > putScore ? "call" : "put";
  const score = Math.max(callScore, putScore);
  const opposite = Math.min(callScore, putScore);
  const aligned30 = direction !== null && (dirOf(s30.bias) === direction || s30.bias === "neutral");
  const aligned15 = direction !== null && (dirOf(s15.bias) === direction || s15.bias === "neutral");
  if (!aligned30)
    blockers.push("30m структура против направления");
  if (!aligned15)
    blockers.push("15m структура против направления");
  if (direction && dirOf(s5.bias) !== direction && s5.bias !== "neutral") {
    blockers.push("5m структура против направления");
  }
  const alignedPattern = direction ? patterns.find((p) => p.direction === direction) : undefined;
  const triggerM5 = alignedPattern ? alignedPattern.name : direction && sweep5 === direction ? "снятие ликвидности с возвратом" : direction && macdCross === direction ? "MACD: пересечение нулевой линии" : "нет триггера";
  if (direction && triggerM5 === "нет триггера") {
    blockers.push("нет триггера входа на 5m");
  }
  const rawConfidence = maxScore > 0 ? (score - opposite * 0.75) / maxScore * 100 : 0;
  const confidence = Math.max(0, Math.min(100, Math.round(rawConfidence * 1.35)));
  const atr5 = atr(tf.m5, 14).at(-1) ?? 0;
  const atrPct = price > 0 ? atr5 / price * 100 : 0;
  const expirySeconds = pickExpiry(atrPct, Boolean(bestPattern), Boolean(sweep5));
  const reasons = factors.filter((f) => f.direction === direction && f.weight > 0).sort((a, b) => b.weight - a.weight).map((f) => `${f.label}: ${f.detail}`);
  return {
    direction,
    confidence,
    score: Number(score.toFixed(2)),
    maxScore: Number(maxScore.toFixed(2)),
    biasH30: `${s30.pattern} → ${biasLabel(s30.bias)}`,
    biasM15: `${s15.pattern} → ${biasLabel(s15.bias)}`,
    triggerM5,
    expirySeconds,
    price,
    factors,
    reasons,
    blockers,
    details: {
      structure30: s30,
      structure15: s15,
      structure5: s5,
      levels: levels.slice(0, 4),
      rsi5: Number.isNaN(rsiNow) ? null : Number(rsiNow.toFixed(2)),
      macd5Hist: Number.isNaN(h5) ? null : Number(h5.toFixed(6)),
      macd15Hist: Number.isNaN(h15) ? null : Number(h15.toFixed(6)),
      atrPct: Number(atrPct.toFixed(4)),
      patterns: patterns.map((p) => p.name),
      callScore: Number(callScore.toFixed(2)),
      putScore: Number(putScore.toFixed(2))
    }
  };
}
function rsiDivergence(candles, rsiSeries) {
  const n = candles.length;
  if (n < 20)
    return null;
  const windowA = candles.slice(n - 20, n - 10);
  const windowB = candles.slice(n - 10);
  const rsiA = rsiSeries.slice(n - 20, n - 10).filter((v) => !Number.isNaN(v));
  const rsiB = rsiSeries.slice(n - 10).filter((v) => !Number.isNaN(v));
  if (!rsiA.length || !rsiB.length)
    return null;
  const lowA = Math.min(...windowA.map((c) => c.low));
  const lowB = Math.min(...windowB.map((c) => c.low));
  const highA = Math.max(...windowA.map((c) => c.high));
  const highB = Math.max(...windowB.map((c) => c.high));
  const rsiLowA = Math.min(...rsiA);
  const rsiLowB = Math.min(...rsiB);
  const rsiHighA = Math.max(...rsiA);
  const rsiHighB = Math.max(...rsiB);
  if (lowB < lowA && rsiLowB > rsiLowA + 2)
    return "call";
  if (highB > highA && rsiHighB < rsiHighA - 2)
    return "put";
  return null;
}
function pickExpiry(atrPct, hasPattern, hasSweep) {
  let target = 300;
  if (atrPct > 0.12)
    target = 120;
  else if (atrPct > 0.07)
    target = 180;
  else if (atrPct > 0.04)
    target = 300;
  else
    target = 600;
  if (hasSweep && target > 180)
    target = 180;
  if (!hasPattern && target < 300)
    target = 300;
  return EXPIRIES.filter((e) => e >= MIN_EXPIRY).reduce((best, e) => Math.abs(e - target) < Math.abs(best - target) ? e : best);
}
var EXPIRIES, MIN_EXPIRY = 180;
var init_analyze = __esm(() => {
  init_structure();
  EXPIRIES = [60, 120, 180, 300, 600, 900];
});

// packages/web/src/api/lib/day.ts
function offsetMs(at) {
  const parts = PARTS_FMT.formatToParts(at);
  const get = (type) => Number(parts.find((p) => p.type === type)?.value ?? "0");
  const asUtc = Date.UTC(get("year"), get("month") - 1, get("day"), get("hour") % 24, get("minute"), get("second"));
  return asUtc - at.getTime();
}
function kyivDay(at = new Date) {
  return DAY_FMT.format(typeof at === "number" ? new Date(at) : at);
}
function kyivHour(at = new Date) {
  const d = typeof at === "number" ? new Date(at) : at;
  return Number(d.toLocaleString("en-US", { timeZone: TZ, hour: "2-digit", hour12: false }).slice(0, 2)) % 24;
}
function kyivDayBounds(day) {
  const [y, m, d] = day.split("-").map(Number);
  const localMidnight = Date.UTC(y, m - 1, d, 0, 0, 0);
  const nextMidnight = Date.UTC(y, m - 1, d + 1, 0, 0, 0);
  const startApprox = new Date(localMidnight - offsetMs(new Date(localMidnight)));
  const start = new Date(localMidnight - offsetMs(startApprox));
  const endApprox = new Date(nextMidnight - offsetMs(new Date(nextMidnight)));
  const end = new Date(nextMidnight - offsetMs(endApprox));
  return { start, end };
}
function shiftDay(day, days) {
  const { start } = kyivDayBounds(day);
  return kyivDay(new Date(start.getTime() + days * 86400000 + 12 * 3600000));
}
function nextMidnight(from = new Date) {
  const at = typeof from === "number" ? new Date(from) : from;
  const today = kyivDay(at);
  const { end } = kyivDayBounds(today);
  return end.getTime() > at.getTime() ? end : kyivDayBounds(shiftDay(today, 1)).end;
}
var TZ = "Europe/Kyiv", DAY_FMT, PARTS_FMT;
var init_day = __esm(() => {
  DAY_FMT = new Intl.DateTimeFormat("en-CA", {
    timeZone: TZ,
    year: "numeric",
    month: "2-digit",
    day: "2-digit"
  });
  PARTS_FMT = new Intl.DateTimeFormat("en-US", {
    timeZone: TZ,
    hour12: false,
    year: "numeric",
    month: "2-digit",
    day: "2-digit",
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit"
  });
});

// packages/web/src/api/strategy/snapshot.ts
function tail(candles, count) {
  return candles.slice(-count).map((c) => ({
    time: c.time,
    open: Number(c.open.toFixed(6)),
    high: Number(c.high.toFixed(6)),
    low: Number(c.low.toFixed(6)),
    close: Number(c.close.toFixed(6))
  }));
}
function num(value) {
  return typeof value === "number" && Number.isFinite(value) ? value : null;
}
function buildSnapshot(input) {
  const { set, analysis, asset, settings, entryAt } = input;
  const d = analysis.details;
  const callScore = num(d.callScore) ?? 0;
  const putScore = num(d.putScore) ?? 0;
  const atrPct = num(d.atrPct) ?? 0;
  const levels = Array.isArray(d.levels) ? d.levels : [];
  const wantKind = analysis.direction === "call" ? "resistance" : "support";
  const ahead = levels.filter((l) => l.kind === wantKind).sort((a, b) => Math.abs(a.distanceAtr) - Math.abs(b.distanceAtr))[0];
  return {
    version: SNAPSHOT_VERSION,
    capturedAt: new Date().toISOString(),
    tradeDay: kyivDay(entryAt),
    kyivHour: kyivHour(entryAt),
    symbol: asset.symbol,
    assetName: asset.name,
    isOtc: asset.isOtc,
    payout: asset.payout,
    lowPayout: input.lowPayout,
    feedSource: set.source,
    lastCandleAt: new Date(set.lastCandleAt * 1000).toISOString(),
    decision: {
      direction: analysis.direction ?? "none",
      confidence: analysis.confidence,
      score: analysis.score,
      maxScore: analysis.maxScore,
      callScore,
      putScore,
      margin: callScore + putScore > 0 ? Number((Math.abs(callScore - putScore) / (callScore + putScore)).toFixed(3)) : 0,
      expirySeconds: analysis.expirySeconds,
      entryPrice: analysis.price,
      triggerM5: analysis.triggerM5,
      biasH30: analysis.biasH30,
      biasM15: analysis.biasM15,
      blockers: analysis.blockers
    },
    indicators: {
      rsi5: num(d.rsi5),
      macd5Hist: num(d.macd5Hist),
      macd15Hist: num(d.macd15Hist),
      atrPct,
      atrAbs: Number((atrPct / 100 * analysis.price).toFixed(6)),
      patterns: Array.isArray(d.patterns) ? d.patterns : []
    },
    structure: {
      m30: d.structure30 ?? null,
      m15: d.structure15 ?? null,
      m5: d.structure5 ?? null
    },
    levels,
    levelAhead: ahead ? { kind: ahead.kind, price: ahead.price, distanceAtr: ahead.distanceAtr } : null,
    factors: analysis.factors,
    reasons: analysis.reasons,
    candles: { m5: tail(set.m5, 10), m15: tail(set.m15, 5), m30: tail(set.m30, 5) },
    engine: {
      minConfidence: settings.minConfidence,
      minPayout: settings.minPayout,
      maxPayout: settings.maxPayout,
      cooldownMinutes: settings.cooldownMinutes,
      scanIntervalSec: settings.scanIntervalSec
    }
  };
}
var SNAPSHOT_VERSION = 2;
var init_snapshot = __esm(() => {
  init_day();
});

// packages/web/src/api/engine/telegram.ts
function botConfigured() {
  return Boolean(envStr("TELEGRAM_BOT_TOKEN"));
}
async function call(method, body) {
  if (!botConfigured())
    return null;
  try {
    const res = await fetch(API(method), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
      signal: AbortSignal.timeout(method === "getUpdates" ? 70000 : 15000)
    });
    const json = await res.json();
    if (!json.ok) {
      if (json.description?.includes("Conflict")) {
        if (!conflictLogged) {
          conflictLogged = true;
          console.warn("[telegram] тот же токен опрашивает другая копия бота — оставь запущенным только один экземпляр");
        }
        return null;
      }
      console.error(`[telegram] ${method}: ${json.description}`);
      return null;
    }
    conflictLogged = false;
    return json.result ?? null;
  } catch (error) {
    if (error.name !== "TimeoutError") {
      console.error(`[telegram] ${method} failed:`, error.message);
    }
    return null;
  }
}
async function sendMessage(chatId, text) {
  return call("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    disable_web_page_preview: true
  });
}
async function broadcast(text) {
  const subs = await activeSubscribers();
  let sent = 0;
  for (const sub of subs) {
    const res = await sendMessage(sub.chatId, text);
    if (res)
      sent += 1;
  }
  return sent;
}
function feedLine() {
  const feed = feedState();
  const names = {
    idle: "не подключён",
    connecting: "подключается",
    live: "работает",
    unauthorized: "нет доступа",
    error: "ошибка"
  };
  const parts = [`Фид Pocket Option: ${names[feed.state] ?? feed.state}`];
  if (feed.lastPayloadAt) {
    parts.push(`данные ${Math.round((Date.now() - feed.lastPayloadAt) / 1000)} сек назад`);
  }
  if (feed.clockSkewSec)
    parts.push(`часы брокера +${feed.clockSkewSec / 3600} ч`);
  if (feed.note)
    parts.push(feed.note);
  return parts.join(" · ");
}
function expiryLabel(seconds) {
  return seconds % 60 === 0 ? `${seconds / 60} мин` : `${seconds} сек`;
}
function formatSignal(signal) {
  const arrow = signal.direction === "call" ? "\uD83D\uDFE2 CALL ▲" : "\uD83D\uDD34 PUT ▼";
  const reasons = signal.reasons.slice(0, 6);
  const bar = "▰".repeat(Math.round(signal.confidence / 10)).padEnd(10, "▱");
  return [
    `<b>${arrow}  ${signal.assetName}</b>`,
    `<code>${signal.symbol}</code>  ·  payout ${signal.payout}%`,
    ...signal.lowPayout ? ["⚠️ Низкий пейаут — вне целевого диапазона"] : [],
    "",
    `Цена входа: <b>${signal.price.toFixed(5)}</b>`,
    `Экспирация: <b>${expiryLabel(signal.expirySeconds)}</b> (до ${fmtTime(signal.expiresAt)} Киев)`,
    `Уверенность: <b>${signal.confidence}%</b> ${bar}`,
    "",
    "<b>Мультитаймфрейм</b>",
    `30m: ${signal.biasH30}`,
    `15m: ${signal.biasM15}`,
    `5m: ${signal.triggerM5}`,
    "",
    "<b>Подтверждения</b>",
    ...reasons.map((r) => `• ${r}`),
    "",
    `<i>Вход по закрытию 5m свечи. Риск — не более 1–2% депозита на сделку.</i>`
  ].join(`
`);
}
function normalizeCommand(raw) {
  const word = raw.split("@")[0].toLowerCase().replaceAll(/[!.,?]+$/g, "");
  if (word.startsWith("/"))
    return ALIASES[word.slice(1)] ?? word;
  return ALIASES[word] ?? word;
}
async function handleCommand(chatId, text, title, chatType = "private") {
  const [rawCmd, ...args] = text.trim().split(/\s+/);
  const cmd = normalizeCommand(rawCmd ?? "");
  switch (cmd) {
    case "/start": {
      await addSubscriber(chatId, title);
      await sendMessage(chatId, `${HELP}

✅ Рассылка сигналов включена.`);
      return;
    }
    case "/help": {
      await sendMessage(chatId, HELP);
      return;
    }
    case "/stop": {
      await deactivateSubscriber(chatId);
      await sendMessage(chatId, "⏸ Рассылка отключена. Включить снова — /start");
      return;
    }
    case "/signals": {
      const rows = await db2.select().from(signals).orderBy(desc(signals.createdAt)).limit(5);
      if (!rows.length) {
        await sendMessage(chatId, "Пока сигналов нет — сканер ждёт подходящий сетап.");
        return;
      }
      const text = rows.map((s) => {
        const arrow = s.direction === "call" ? "\uD83D\uDFE2 CALL" : "\uD83D\uDD34 PUT";
        return `${arrow} <b>${s.assetName}</b> · ${s.confidence}% · ${expiryLabel(s.expirySeconds)} · ${fmtTime(s.createdAt)}`;
      }).join(`
`);
      await sendMessage(chatId, `<b>Последние сигналы</b>
${text}`);
      return;
    }
    case "/last": {
      const [row] = await db2.select().from(signals).orderBy(desc(signals.createdAt)).limit(1);
      if (!row) {
        await sendMessage(chatId, "Сигналов ещё не было — сканер ждёт подходящий сетап.");
        return;
      }
      await sendMessage(chatId, formatSignal(row));
      return;
    }
    case "/scan": {
      await sendMessage(chatId, "\uD83D\uDD0E Прогоняю сканер…");
      await init_scanner();
      const out = await runScan();
      const top = out.candidates.slice().sort((a, b) => b.confidence - a.confidence).slice(0, 5).map((x) => `• ${x.name} ${x.direction ?? "—"} ${x.confidence}%${x.blockers.length ? ` — ${x.blockers[0]}` : " ✅"}`);
      await sendMessage(chatId, [
        "<b>Проход сканера</b>",
        `Пар проверено: ${out.scanned} · сигналов: ${out.signals} · ошибок: ${out.errors} · ${out.durationMs} мс`,
        out.note ? `<i>${out.note}</i>` : "",
        top.length ? `
<b>Лучшие кандидаты</b>` : "",
        ...top
      ].filter(Boolean).join(`
`));
      return;
    }
    case "/pairs": {
      const settings = await getSettings();
      const rows = await db2.select().from(assets).where(gte(assets.payout, settings.minPayout)).orderBy(desc(assets.payout)).limit(40);
      const filtered = rows.filter((a) => a.payout <= settings.maxPayout && a.kind === "currency");
      if (!filtered.length) {
        await sendMessage(chatId, "Список активов ещё не загружен, попробуй через минуту.");
        return;
      }
      const ready = filtered.filter((a) => a.feedStatus === "ok");
      const waiting = filtered.filter((a) => a.feedStatus !== "ok");
      const lines = [
        `<b>Пары с payout ${settings.minPayout}–${settings.maxPayout}%</b>`,
        "",
        `<b>В работе (${ready.length})</b>`,
        ...ready.slice(0, 20).map((a) => `• ${a.name} — ${a.payout}%`)
      ];
      if (waiting.length) {
        lines.push("", `<b>Ждут фид PO (${waiting.length})</b>`, ...waiting.slice(0, 12).map((a) => `• ${a.name} — ${a.payout}%`), "<i>Эти пары ещё не отдали свечи — проверь состояние фида через /status.</i>");
      }
      await sendMessage(chatId, lines.join(`
`));
      return;
    }
    case "/status": {
      const settings = await getSettings();
      const [run] = await db2.select().from(scanRuns).orderBy(desc(scanRuns.startedAt)).limit(1);
      const [totals] = await db2.select({ value: count() }).from(signals);
      const totalSignals = totals?.value ?? 0;
      await sendMessage(chatId, [
        "<b>Состояние</b>",
        `Сканер: ${settings.scannerEnabled ? "работает" : "остановлен"} (раз в ${settings.scanIntervalSec} сек)`,
        `Порог уверенности: ${settings.minConfidence}%`,
        `Payout-фильтр: ${settings.minPayout}–${settings.maxPayout}%`,
        `Кулдаун по паре: ${settings.cooldownMinutes} мин`,
        run ? `Последний проход: ${fmtTime(run.startedAt)} · ${run.scanned} пар · ${run.signalsFound} сигналов · ${run.durationMs} мс${run.note ? ` · ${run.note}` : ""}` : "Последний проход: ещё не было",
        `Всего сигналов в базе: ${totalSignals}`,
        feedLine()
      ].join(`
`));
      return;
    }
    case "/threshold": {
      const value = Number(args[0]);
      if (!Number.isFinite(value) || value < 60 || value > 95) {
        await sendMessage(chatId, "Укажи порог от 60 до 95, например: /threshold 80");
        return;
      }
      await updateSettings({ minConfidence: Math.round(value) });
      await sendMessage(chatId, `✅ Порог уверенности: ${Math.round(value)}%`);
      return;
    }
    default: {
      if (chatType === "private") {
        await addSubscriber(chatId, title);
        await sendMessage(chatId, `${HELP}

✅ Рассылка сигналов включена для этого чата.`);
        return;
      }
      if (cmd.startsWith("/"))
        await sendMessage(chatId, HELP);
    }
  }
}
async function pollLoop(generation) {
  let backoff = 0;
  while (poll.running && generation === poll.generation) {
    const updates = await call("getUpdates", {
      offset: poll.offset,
      timeout: 50,
      allowed_updates: ["message"]
    });
    if (!updates) {
      backoff = Math.min(backoff === 0 ? 2000 : backoff * 2, 15000);
      await new Promise((r) => setTimeout(r, backoff));
      continue;
    }
    backoff = 0;
    for (const u of updates) {
      poll.offset = u.update_id + 1;
      const msg = u.message;
      if (!msg?.text)
        continue;
      const chatId = String(msg.chat.id);
      const title = msg.chat.title ?? msg.chat.username ?? msg.chat.first_name ?? undefined;
      console.log(`[telegram] ← ${chatId} (${msg.chat.type ?? "?"}): ${msg.text}`);
      try {
        await handleCommand(chatId, msg.text, title, msg.chat.type ?? "private");
      } catch (error) {
        console.error("[telegram] handler:", error.message);
      }
    }
  }
}
function startPolling() {
  if (!botConfigured())
    return;
  if (poll.running && poll.generation > 0)
    return;
  poll.generation += 1;
  poll.running = true;
  pollLoop(poll.generation);
  console.log("[telegram] polling запущен");
}
async function publishSignal(signal) {
  const settings = await getSettings();
  if (!settings.telegramEnabled)
    return 0;
  const sent = await broadcast(formatSignal(signal));
  if (sent > 0) {
    await db2.update(signals).set({ sentToTelegram: true }).where(eq(signals.id, signal.id));
  }
  return sent;
}
var API = (method) => `https://api.telegram.org/bot${envStr("TELEGRAM_BOT_TOKEN")}/${method}`, conflictLogged = false, TZ2 = "Europe/Kyiv", fmtTime = (d) => d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", timeZone: TZ2 }), HELP, ALIASES, pollScope, poll;
var init_telegram = __esm(async () => {
  init_drizzle_orm();
  init_database();
  init_schema();
  init_store();
  await __promiseAll([
    init_env(),
    init_po_feed()
  ]);
  HELP = [
    "<b>Pocket Signal Bot</b>",
    "Сканирую валютные пары Pocket Option по Smart Money структуре, свечным паттернам, MACD, RSI и уровням — с подтверждением 30m → 15m → 5m.",
    "",
    "<b>Команды</b>",
    "/signals — последние сигналы",
    "/last — полный разбор последнего сигнала",
    "/scan — прогнать сканер сейчас",
    "/pairs — пары в работе и payout",
    "/status — состояние сканера",
    "/threshold 70 — порог уверенности (50–90)",
    "/stop — отключить рассылку",
    "/start — включить рассылку"
  ].join(`
`);
  ALIASES = {
    start: "/start",
    старт: "/start",
    начать: "/start",
    подписаться: "/start",
    stop: "/stop",
    стоп: "/stop",
    отписаться: "/stop",
    help: "/help",
    помощь: "/help",
    справка: "/help",
    signals: "/signals",
    сигналы: "/signals",
    last: "/last",
    последний: "/last",
    scan: "/scan",
    скан: "/scan",
    сканировать: "/scan",
    pairs: "/pairs",
    пары: "/pairs",
    status: "/status",
    статус: "/status",
    состояние: "/status",
    threshold: "/threshold",
    порог: "/threshold"
  };
  pollScope = globalThis;
  poll = pollScope.__poTelegramPoll ??= {
    generation: 0,
    running: false,
    offset: 0
  };
  if (poll.running) {
    poll.generation += 1;
    pollLoop(poll.generation);
  }
});

// packages/web/src/api/engine/scanner.ts
async function syncAssets() {
  const snapshot = await getAssets();
  const settings = await getSettings();
  const now = new Date;
  const poFeed = ssidLooksLikeCookie();
  const currency = snapshot.assets.filter((a) => a.kind === "currency");
  for (const asset of currency) {
    const feedSymbol = toFeedSymbol(asset.symbol);
    const feedStatus = feedSymbol ? "ok" : poFeed ? "ok" : "needs_po_feed";
    await db2.insert(assets).values({
      symbol: asset.symbol,
      name: asset.name,
      kind: asset.kind,
      isOtc: asset.isOtc,
      payout: asset.payout,
      isActive: asset.isActive,
      feedSymbol,
      feedStatus,
      updatedAt: now
    }).onConflictDoUpdate({
      target: assets.symbol,
      set: {
        name: asset.name,
        payout: asset.payout,
        isActive: asset.isActive,
        feedSymbol,
        feedStatus,
        updatedAt: now
      }
    });
  }
  const tradable = currency.filter((a) => a.payout >= settings.minPayout && a.payout <= settings.maxPayout);
  return { total: currency.length, tradable: tradable.length };
}
async function watchlist() {
  const settings = await getSettings();
  const all = await db2.select().from(assets).orderBy(desc(assets.payout));
  const excluded = parseExcluded(settings.excludedSymbols);
  const rows = excluded.size ? all.filter((a) => !isExcluded(a.symbol, excluded)) : all;
  const inRange = rows.filter((a) => a.isActive && a.payout >= settings.minPayout && a.payout <= settings.maxPayout);
  const ready = inRange.filter((a) => a.feedStatus === "ok");
  if (!settings.fallbackPairs)
    return { list: inRange, fallback: false };
  if (ready.length >= MIN_READY)
    return { list: inRange, fallback: false };
  const spare = rows.filter((a) => !a.isOtc && a.feedStatus === "ok");
  if (spare.length === 0)
    return { list: inRange, fallback: false };
  const bySymbol = new Map;
  for (const a of [...inRange, ...spare])
    bySymbol.set(a.symbol, a);
  return { list: [...bySymbol.values()], fallback: ready.length === 0 };
}
async function recentSignal(symbol, cooldownMinutes) {
  const since = new Date(Date.now() - cooldownMinutes * 60000);
  const rows = await db2.select().from(signals).where(and(eq(signals.symbol, symbol), gte(signals.createdAt, since))).limit(1);
  return rows[0];
}
async function runScan(opts = {}) {
  const publish = opts.publish ?? true;
  const startedAt = new Date;
  const started = Date.now();
  const settings = await getSettings();
  const skipped = [];
  const candidates = [];
  let scanned = 0;
  let signals2 = 0;
  let errors = 0;
  let note = "";
  try {
    await syncAssets();
  } catch (error) {
    note = `активы PO недоступны: ${error.message}`;
  }
  const wl = await watchlist();
  if (wl.fallback) {
    const prefix = "в диапазоне payout нет пар с живым фидом (OTC ждут cookie ssid) — сканирую обычные пары";
    note = note ? `${note}; ${prefix}` : prefix;
  }
  for (const asset of wl.list) {
    if (asset.feedStatus !== "ok") {
      skipped.push({ symbol: asset.symbol, reason: "нет фида свечей (нужен ssid PO)" });
      continue;
    }
    try {
      const set = await getCandleSet(asset.symbol);
      if (isStale(set.lastCandleAt)) {
        skipped.push({ symbol: asset.symbol, reason: "данные устарели (рынок закрыт)" });
        await db2.update(assets).set({ lastCandleAt: new Date(set.lastCandleAt * 1000) }).where(eq(assets.symbol, asset.symbol));
        continue;
      }
      if (set.m30.length < 30 || set.m15.length < 40) {
        skipped.push({ symbol: asset.symbol, reason: "мало истории" });
        continue;
      }
      scanned += 1;
      const result = analyze(set);
      candidates.push({
        symbol: asset.symbol,
        name: asset.name,
        direction: result.direction,
        confidence: result.confidence,
        blockers: result.blockers
      });
      await db2.update(assets).set({ lastCandleAt: new Date(set.lastCandleAt * 1000) }).where(eq(assets.symbol, asset.symbol));
      const passes = result.direction !== null && result.confidence >= settings.minConfidence && result.blockers.length === 0;
      if (!passes)
        continue;
      if (!publish) {
        skipped.push({ symbol: asset.symbol, reason: "сетап есть — ждём закрытия 5m свечи" });
        continue;
      }
      const dup = await recentSignal(asset.symbol, settings.cooldownMinutes);
      if (dup) {
        skipped.push({ symbol: asset.symbol, reason: "кулдаун после недавнего сигнала" });
        continue;
      }
      const entryAt = new Date((set.lastCandleAt + 300) * 1000);
      const expiresAt = new Date(entryAt.getTime() + result.expirySeconds * 1000);
      const leftMs = expiresAt.getTime() - Date.now();
      if (leftMs < MIN_ENTRY_WINDOW_MS) {
        skipped.push({
          symbol: asset.symbol,
          reason: `до экспирации ${Math.round(leftMs / 1000)} сек — меньше минимального окна входа`
        });
        continue;
      }
      const lowPayout = asset.payout < settings.minPayout || asset.payout > settings.maxPayout;
      const snapshot = buildSnapshot({
        set,
        analysis: result,
        asset: {
          symbol: asset.symbol,
          name: asset.name,
          isOtc: asset.isOtc,
          payout: asset.payout
        },
        lowPayout,
        settings,
        entryAt
      });
      const [signal] = await db2.insert(signals).values({
        symbol: asset.symbol,
        assetName: asset.name,
        direction: result.direction,
        confidence: result.confidence,
        score: result.score,
        payout: asset.payout,
        lowPayout,
        price: result.price,
        expirySeconds: result.expirySeconds,
        entryAt,
        expiresAt,
        biasH30: result.biasH30,
        biasM15: result.biasM15,
        triggerM5: result.triggerM5,
        reasons: result.reasons,
        details: result.details,
        factors: result.factors,
        snapshot,
        tradeDay: snapshot.tradeDay
      }).returning();
      if (signal) {
        signals2 += 1;
        const lagSec = Math.round((Date.now() - entryAt.getTime()) / 1000);
        console.log(`[scanner] сигнал ${signal.symbol} ${signal.direction} · payout ${signal.payout}%${signal.lowPayout ? " (вне диапазона)" : ""} · лаг от закрытия свечи ${lagSec} сек`);
        publishSignal(signal).catch((error) => console.error("[scanner] telegram:", error.message));
      }
    } catch (error) {
      errors += 1;
      skipped.push({ symbol: asset.symbol, reason: error.message });
    }
  }
  const durationMs = Date.now() - started;
  await db2.insert(scanRuns).values({
    startedAt,
    durationMs,
    scanned,
    signalsFound: signals2,
    errors,
    note: note || null
  });
  return { scanned, signals: signals2, errors, durationMs, note, skipped, candidates };
}
function nextAlignedAt(from) {
  const sec = Math.ceil((from / 1000 - ALIGN_LAG_SEC) / GRID_SEC) * GRID_SEC + ALIGN_LAG_SEC;
  return sec * 1000;
}
async function tick(publish) {
  if (state2.running)
    return;
  state2.running = true;
  try {
    const settings = await getSettings();
    if (!settings.scannerEnabled)
      return;
    if (settings.scanIntervalSec !== state2.intervalSec) {
      state2.intervalSec = Math.max(30, settings.scanIntervalSec);
    }
    const out = await runScan({ publish });
    console.log(`[scanner] ${out.scanned} пар · ${out.signals} сигналов · ${out.errors} ошибок · ${out.durationMs} мс${publish ? " · проход по закрытию 5m" : " · промежуточный проход"}`);
  } catch (error) {
    console.error("[scanner] проход упал:", error.message);
  } finally {
    state2.running = false;
    schedule();
  }
}
function schedule() {
  if (state2.timer)
    clearTimeout(state2.timer);
  const now = Date.now();
  const aligned = nextAlignedAt(now);
  const refresh = now + state2.intervalSec * 1000;
  const publish = aligned <= refresh;
  const at = publish ? aligned : refresh;
  state2.timer = setTimeout(() => void tick(publish), Math.max(500, at - now));
}
function startScanner(intervalSec = 60) {
  if (state2.timer)
    return;
  state2.intervalSec = Math.max(30, intervalSec);
  schedule();
  console.log(`[scanner] запущен: сигналы по закрытию 5m свечи (+${ALIGN_LAG_SEC} сек), обновление каждые ${state2.intervalSec} сек`);
}
function scannerRunning() {
  return state2.timer !== null;
}
var MIN_READY = 8, MIN_ENTRY_WINDOW_MS = 120000, scanScope, state2, GRID_SEC = 300, ALIGN_LAG_SEC = 5;
var init_scanner = __esm(async () => {
  init_drizzle_orm();
  init_database();
  init_schema();
  init_analyze();
  init_snapshot();
  init_store();
  await __promiseAll([
    init_candles(),
    init_po_feed(),
    init_pocket_option(),
    init_telegram()
  ]);
  scanScope = globalThis;
  state2 = scanScope.__poScanner ??= {
    timer: null,
    intervalSec: 60,
    running: false
  };
  if (state2.timer)
    schedule();
});

// packages/web/src/server-node.ts
import { existsSync, readFileSync, statSync } from "node:fs";
import { dirname, join, normalize as normalize2, resolve } from "node:path";
import { fileURLToPath } from "node:url";

// node_modules/.bun/@hono+node-server@2.1.1+426717865c48ce91/node_modules/@hono/node-server/dist/constants-BLSFu_RU.mjs
var X_ALREADY_SENT = "x-hono-already-sent";

// node_modules/.bun/@hono+node-server@2.1.1+426717865c48ce91/node_modules/@hono/node-server/dist/index.mjs
import { STATUS_CODES, createServer } from "node:http";
import { Http2ServerRequest, constants } from "node:http2";
import { Readable } from "node:stream";

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/helper/websocket/index.js
var defineWebSocketHelper = (handler) => {
  return (...args) => {
    if (typeof args[0] === "function") {
      const [createEvents, options] = args;
      return async function upgradeWebSocket(c, next) {
        const events = await createEvents(c);
        const result = await handler(c, events, options);
        if (result) {
          return result;
        }
        await next();
      };
    } else {
      const [c, events, options] = args;
      return (async () => {
        const upgraded = await handler(c, events, options);
        if (!upgraded) {
          throw new Error("Failed to upgrade WebSocket");
        }
        return upgraded;
      })();
    }
  };
};

// node_modules/.bun/@hono+node-server@2.1.1+426717865c48ce91/node_modules/@hono/node-server/dist/index.mjs
var RequestError = class extends Error {
  constructor(message, options) {
    super(message, options);
    this.name = "RequestError";
  }
};
var nonJoinedHeaders = new Set([
  "age",
  "authorization",
  "content-length",
  "content-type",
  "etag",
  "expires",
  "from",
  "host",
  "if-modified-since",
  "if-unmodified-since",
  "last-modified",
  "location",
  "max-forwards",
  "proxy-authorization",
  "referer",
  "retry-after",
  "server",
  "user-agent"
]);
var validHeaderName = /^[!#$%&'*+\-.^_`|~\dA-Za-z]+$/;
var isHttpWhitespace = (code) => code === 9 || code === 10 || code === 13 || code === 32;
var normalizeHeaderValue = (value) => {
  if (!isHttpWhitespace(value.charCodeAt(0)) && !isHttpWhitespace(value.charCodeAt(value.length - 1)))
    return value;
  let start = 0;
  let end = value.length;
  while (start < end && isHttpWhitespace(value.charCodeAt(start)))
    start++;
  while (end > start && isHttpWhitespace(value.charCodeAt(end - 1)))
    end--;
  return value.slice(start, end);
};
var forbiddenHeaderValue = /[\0\r\n]/;
var GlobalHeaders = globalThis.Headers;
var materializeHeaders = (rawHeaders, HeadersCtor = GlobalHeaders) => {
  const headers = new HeadersCtor;
  for (let i = 0;i < rawHeaders.length; i += 2) {
    const name = rawHeaders[i];
    if (!name.startsWith(":"))
      headers.append(name, rawHeaders[i + 1]);
  }
  return headers;
};
var RequestHeaders = class {
  #incoming;
  #rawHeaders;
  #headers;
  #invalidValue;
  constructor(incoming) {
    this.#incoming = incoming;
    if (incoming instanceof Http2ServerRequest)
      this.#rawHeaders = incoming.rawHeaders.slice();
  }
  get #lazyRawHeaders() {
    return this.#rawHeaders ??= this.#incoming.rawHeaders.slice();
  }
  get #native() {
    if (!this.#headers) {
      this.#headers = materializeHeaders(this.#lazyRawHeaders);
      this.#rawHeaders = undefined;
    }
    return this.#headers;
  }
  #normalizedName(name) {
    if (typeof name !== "string")
      return;
    if (!validHeaderName.test(name))
      throw new TypeError(`Invalid header name: ${name}`);
    return name.toLowerCase();
  }
  #lookupHttp1(lowerName) {
    const headers = this.#incoming instanceof Http2ServerRequest ? undefined : this.#incoming.headers;
    if (!headers || nonJoinedHeaders.has(lowerName) || lowerName === "set-cookie" || lowerName === "__proto__")
      return;
    if (!Object.hasOwn(headers, lowerName))
      return null;
    const rawValue = headers[lowerName];
    if (typeof rawValue === "string") {
      const value = normalizeHeaderValue(rawValue);
      return forbiddenHeaderValue.test(value) ? undefined : value;
    }
  }
  #lookup(rawHeaders, lowerName) {
    const separator = lowerName === "cookie" ? "; " : ", ";
    let value = null;
    for (let i = 0;i < rawHeaders.length; i += 2) {
      const rawName = rawHeaders[i];
      if (rawName.length === lowerName.length && rawName.toLowerCase() === lowerName) {
        const rawValue = normalizeHeaderValue(rawHeaders[i + 1]);
        if (forbiddenHeaderValue.test(rawValue)) {
          this.#invalidValue = true;
          return;
        }
        value = value === null ? rawValue : value + separator + rawValue;
      }
    }
    return value;
  }
  append(name, value) {
    this.#native.append(name, value);
  }
  delete(name) {
    this.#native.delete(name);
  }
  get(name) {
    const lowerName = this.#normalizedName(name);
    if (lowerName && !this.#headers && !this.#invalidValue) {
      const http1Value = this.#lookupHttp1(lowerName);
      if (http1Value !== undefined)
        return http1Value;
      const value = this.#lookup(this.#lazyRawHeaders, lowerName);
      if (value !== undefined)
        return value;
    }
    return this.#native.get(name);
  }
  has(name) {
    const lowerName = this.#normalizedName(name);
    if (lowerName && !this.#headers && !this.#invalidValue) {
      const http1Value = this.#lookupHttp1(lowerName);
      if (http1Value !== undefined)
        return http1Value !== null;
      const value = this.#lookup(this.#lazyRawHeaders, lowerName);
      if (value !== undefined)
        return value !== null;
    }
    return this.#native.has(name);
  }
  set(name, value) {
    this.#native.set(name, value);
  }
  getSetCookie() {
    return this.#native.getSetCookie();
  }
  keys() {
    return this.#native.keys();
  }
  values() {
    return this.#native.values();
  }
  entries() {
    return this.#native.entries();
  }
  forEach(callback, thisArg) {
    this.#native.forEach((value, key) => {
      callback.call(thisArg, value, key, this);
    });
  }
  [Symbol.iterator]() {
    return this.entries();
  }
};
Object.defineProperty(RequestHeaders.prototype, Symbol.for("nodejs.util.inspect.custom"), { value: function(depth, options, inspectFn) {
  return `Headers (lightweight) ${inspectFn(Object.fromEntries(this), {
    ...options,
    depth: depth == null ? null : depth - 1
  })}`;
} });
Object.setPrototypeOf(RequestHeaders.prototype, GlobalHeaders.prototype);
var newHeadersFromIncoming = (incoming) => globalThis.Headers === GlobalHeaders ? new RequestHeaders(incoming) : materializeHeaders(incoming.rawHeaders, globalThis.Headers);
var reValidRequestUrl = /^\/[!#$&-;=?-\[\]_a-z~]*$/;
var reDotSegment = /\/\.\.?(?:[/?#]|$)/;
var reValidHost = /^[a-z0-9._-]+(?::(?:[1-5]\d{3,4}|[6-9]\d{3}))?$/;
var buildUrl = (scheme, host, incomingUrl) => {
  const url = `${scheme}://${host}${incomingUrl}`;
  if (!reValidHost.test(host)) {
    const urlObj = new URL(url);
    if (urlObj.hostname.length !== host.length && urlObj.hostname !== (host.includes(":") ? host.replace(/:\d+$/, "") : host).toLowerCase())
      throw new RequestError("Invalid host header");
    return urlObj.href;
  } else if (incomingUrl.length === 0)
    return url + "/";
  else {
    if (incomingUrl.charCodeAt(0) !== 47)
      throw new RequestError("Invalid URL");
    if (!reValidRequestUrl.test(incomingUrl) || reDotSegment.test(incomingUrl))
      return new URL(url).href;
    return url;
  }
};
var toRequestError = (e) => {
  if (e instanceof RequestError)
    return e;
  return new RequestError(e.message, { cause: e });
};
var GlobalRequest = global.Request;
var Request$1 = class extends GlobalRequest {
  constructor(input, options) {
    if (typeof input === "object" && getRequestCache in input) {
      const hasReplacementBody = options !== undefined && "body" in options && options.body != null;
      if (input[bodyConsumedDirectlyKey] && !hasReplacementBody)
        throw new TypeError("Cannot construct a Request with a Request object that has already been used.");
      input = input[getRequestCache]();
    }
    if (typeof options?.body?.getReader !== "undefined")
      options.duplex ??= "half";
    super(input, options);
  }
};
var wrapBodyStream = Symbol("wrapBodyStream");
var byteExactEncodings = new Set([
  "latin1",
  "binary",
  "hex",
  "base64",
  "base64url"
]);
var isByteExactEncoding = (encoding) => encoding === null || byteExactEncodings.has(encoding);
var bodyBufferedBeforeDisconnectKey = Symbol("bodyBufferedBeforeDisconnect");
var bodyBufferedLengthBeforeDisconnectKey = Symbol("bodyBufferedLengthBeforeDisconnect");
var toBufferChunk = (chunk, encoding) => Buffer.isBuffer(chunk) ? chunk : Buffer.from(chunk, encoding ?? "utf8");
var isRecoverableDisconnectedIncoming = (incoming) => !(incoming instanceof Http2ServerRequest) && !!incoming.complete && !!incoming.readableAborted && typeof incoming.read === "function" && isByteExactEncoding(incoming.readableEncoding);
var recordBodyBufferedBeforeDisconnect = (incoming) => {
  if (incoming.readableDidRead || !isRecoverableDisconnectedIncoming(incoming))
    return;
  const incomingWithRecovery = incoming;
  incomingWithRecovery[bodyBufferedLengthBeforeDisconnectKey] ??= incoming.readableLength;
};
var readBodyBufferedBeforeDisconnect = (incoming, chunks) => {
  if (incoming.readableDidRead && !chunks || !isRecoverableDisconnectedIncoming(incoming))
    return;
  const incomingWithRecovery = incoming;
  if (incomingWithRecovery[bodyBufferedBeforeDisconnectKey] !== undefined)
    return incomingWithRecovery[bodyBufferedBeforeDisconnectKey];
  let result;
  const errored = incoming.errored;
  if (errored && errored.code !== "ECONNRESET")
    result = errored;
  else if (incomingWithRecovery[bodyBufferedLengthBeforeDisconnectKey] !== undefined && incoming.readableLength !== incomingWithRecovery[bodyBufferedLengthBeforeDisconnectKey])
    result = newBodyUnusableError();
  else {
    const bodyChunks = chunks ?? [];
    const chunk = incoming.read();
    if (chunk !== null)
      bodyChunks.push(toBufferChunk(chunk, incoming.readableEncoding));
    const buffer = bodyChunks.length === 1 ? bodyChunks[0] : Buffer.concat(bodyChunks);
    result = buffer;
    const contentLength = incoming.headers["content-length"];
    if (typeof contentLength === "string" && /^\d+$/.test(contentLength)) {
      const expectedLength = Number(contentLength);
      if (Number.isSafeInteger(expectedLength) && buffer.length !== expectedLength)
        result = newBodyUnusableError();
    }
  }
  incomingWithRecovery[bodyBufferedBeforeDisconnectKey] = result;
  return result;
};
var enqueueBufferedBody = (controller, buffered) => {
  if (buffered instanceof Error) {
    controller.error(buffered);
    return;
  }
  if (buffered.length > 0)
    controller.enqueue(buffered);
  controller.close();
};
var newRequestFromIncoming = (method, url, headers, incoming, abortController) => {
  const init = {
    method,
    headers,
    signal: abortController.signal
  };
  if (method === "TRACE") {
    init.method = "GET";
    const req = new Request$1(url, init);
    Object.defineProperty(req, "method", { get() {
      return "TRACE";
    } });
    return req;
  }
  if (!(method === "GET" || method === "HEAD"))
    if ("rawBody" in incoming && incoming.rawBody instanceof Buffer)
      init.body = new ReadableStream({ start(controller) {
        controller.enqueue(incoming.rawBody);
        controller.close();
      } });
    else if (incoming[wrapBodyStream]) {
      let reader;
      init.body = new ReadableStream({ async pull(controller) {
        try {
          if (!reader) {
            const buffered = readBodyBufferedBeforeDisconnect(incoming);
            if (buffered !== undefined) {
              enqueueBufferedBody(controller, buffered);
              return;
            }
          }
          reader ||= Readable.toWeb(incoming).getReader();
          const { done, value } = await reader.read();
          if (done)
            controller.close();
          else
            controller.enqueue(value);
        } catch (error) {
          controller.error(error);
        }
      } });
    } else {
      const buffered = readBodyBufferedBeforeDisconnect(incoming);
      if (buffered !== undefined)
        init.body = new ReadableStream({ start(controller) {
          enqueueBufferedBody(controller, buffered);
        } });
      else
        init.body = Readable.toWeb(incoming);
    }
  return new Request$1(url, init);
};
var getRequestCache = Symbol("getRequestCache");
var requestCache = Symbol("requestCache");
var incomingKey = Symbol("incomingKey");
var urlKey = Symbol("urlKey");
var methodKey = Symbol("methodKey");
var headersKey = Symbol("headersKey");
var abortControllerKey = Symbol("abortControllerKey");
var getAbortController = Symbol("getAbortController");
var abortRequest = Symbol("abortRequest");
var bodyBufferKey = Symbol("bodyBuffer");
var bodyReadPromiseKey = Symbol("bodyReadPromise");
var bodyConsumedDirectlyKey = Symbol("bodyConsumedDirectly");
var bodyLockReaderKey = Symbol("bodyLockReader");
var abortReasonKey = Symbol("abortReason");
var newBodyUnusableError = () => {
  return /* @__PURE__ */ new TypeError("Body is unusable");
};
var rejectBodyUnusable = () => {
  return Promise.reject(newBodyUnusableError());
};
var textDecoder = new TextDecoder;
var consumeBodyDirectOnce = (request) => {
  if (request[bodyConsumedDirectlyKey])
    return rejectBodyUnusable();
  request[bodyConsumedDirectlyKey] = true;
};
var toArrayBuffer = (buf) => {
  return buf.buffer.slice(buf.byteOffset, buf.byteOffset + buf.byteLength);
};
var contentType = (request) => {
  return (request[headersKey] ||= newHeadersFromIncoming(request[incomingKey])).get("content-type") || "";
};
var methodTokenRegExp = /^[!#$%&'*+\-.^_`|~0-9A-Za-z]+$/;
var normalizeIncomingMethod = (method) => {
  if (typeof method !== "string" || method.length === 0)
    return "GET";
  switch (method) {
    case "DELETE":
    case "GET":
    case "HEAD":
    case "OPTIONS":
    case "PATCH":
    case "POST":
    case "PUT":
    case "QUERY":
      return method;
  }
  const upper = method.toUpperCase();
  switch (upper) {
    case "DELETE":
    case "GET":
    case "HEAD":
    case "OPTIONS":
    case "POST":
    case "PUT":
      return upper;
    default:
      return method;
  }
};
var validateDirectReadMethod = (method) => {
  if (!methodTokenRegExp.test(method))
    return /* @__PURE__ */ new TypeError(`'${method}' is not a valid HTTP method.`);
  const normalized = method.toUpperCase();
  if (normalized === "CONNECT" || normalized === "TRACK" || normalized === "TRACE" && method !== "TRACE")
    return /* @__PURE__ */ new TypeError(`'${method}' HTTP method is unsupported.`);
};
var readBodyWithFastPath = (request, method, fromBuffer) => {
  if (request[bodyConsumedDirectlyKey])
    return rejectBodyUnusable();
  const methodName = request.method;
  if (methodName === "GET" || methodName === "HEAD")
    return request[getRequestCache]()[method]();
  const methodValidationError = validateDirectReadMethod(methodName);
  if (methodValidationError)
    return Promise.reject(methodValidationError);
  if (request[requestCache]) {
    if (methodName !== "TRACE")
      return request[requestCache][method]();
  }
  const alreadyUsedError = consumeBodyDirectOnce(request);
  if (alreadyUsedError)
    return alreadyUsedError;
  const raw = readRawBodyIfAvailable(request);
  if (raw) {
    const result = Promise.resolve(fromBuffer(raw, request));
    request[bodyBufferKey] = undefined;
    return result;
  }
  return readBodyDirect(request).then((buf) => {
    const result = fromBuffer(buf, request);
    request[bodyBufferKey] = undefined;
    return result;
  });
};
var readRawBodyIfAvailable = (request) => {
  const incoming = request[incomingKey];
  if ("rawBody" in incoming && incoming.rawBody instanceof Buffer)
    return incoming.rawBody;
};
var normalizeAbortError = (request, incoming) => {
  if (incoming.errored)
    return incoming.errored;
  const reason = request[abortReasonKey];
  if (reason !== undefined)
    return reason instanceof Error ? reason : new Error(String(reason));
  return /* @__PURE__ */ new Error("Client connection prematurely closed.");
};
var readBodyDirect = (request) => {
  if (request[bodyBufferKey])
    return Promise.resolve(request[bodyBufferKey]);
  if (request[bodyReadPromiseKey])
    return request[bodyReadPromiseKey];
  const incoming = request[incomingKey];
  if (incoming.readableDidRead)
    return rejectBodyUnusable();
  const buffered = readBodyBufferedBeforeDisconnect(incoming);
  if (buffered !== undefined) {
    if (buffered instanceof Error)
      return Promise.reject(buffered);
    request[bodyBufferKey] = buffered;
    return Promise.resolve(buffered);
  }
  const promise = new Promise((resolve, reject) => {
    const chunks = [];
    let settled = false;
    const finish = (callback) => {
      if (settled)
        return;
      settled = true;
      cleanup();
      callback();
    };
    const recoverCompleteBodyAfterDisconnect = (error) => {
      const streamError = incoming.errored ?? error;
      if (!isRecoverableDisconnectedIncoming(incoming) || streamError && streamError.code !== "ECONNRESET")
        return false;
      finish(() => {
        const recovered = readBodyBufferedBeforeDisconnect(incoming, chunks);
        if (recovered instanceof Error)
          reject(recovered);
        else if (recovered === undefined)
          reject(error ?? normalizeAbortError(request, incoming));
        else {
          request[bodyBufferKey] = recovered;
          resolve(recovered);
        }
      });
      return true;
    };
    const onData = (chunk) => {
      chunks.push(toBufferChunk(chunk, incoming.readableEncoding));
    };
    const onEnd = () => {
      finish(() => {
        const buffer = chunks.length === 1 ? chunks[0] : Buffer.concat(chunks);
        request[bodyBufferKey] = buffer;
        resolve(buffer);
      });
    };
    const onError = (error) => {
      if (recoverCompleteBodyAfterDisconnect(error))
        return;
      finish(() => {
        reject(error);
      });
    };
    const onClose = () => {
      if (incoming.readableEnded) {
        onEnd();
        return;
      }
      if (recoverCompleteBodyAfterDisconnect())
        return;
      finish(() => {
        reject(normalizeAbortError(request, incoming));
      });
    };
    const cleanup = () => {
      incoming.off("data", onData);
      incoming.off("end", onEnd);
      incoming.off("error", onError);
      incoming.off("close", onClose);
      request[bodyReadPromiseKey] = undefined;
    };
    incoming.on("data", onData);
    incoming.on("end", onEnd);
    incoming.on("error", onError);
    incoming.on("close", onClose);
    queueMicrotask(() => {
      if (settled)
        return;
      if (incoming.readableEnded)
        onEnd();
      else if (incoming.errored)
        onError(incoming.errored);
      else if (incoming.destroyed)
        onClose();
    });
  });
  request[bodyReadPromiseKey] = promise;
  return promise;
};
var requestPrototype = {
  get method() {
    return this[methodKey];
  },
  get url() {
    return this[urlKey];
  },
  get headers() {
    return this[headersKey] ||= newHeadersFromIncoming(this[incomingKey]);
  },
  [abortRequest](reason) {
    if (this[abortReasonKey] === undefined)
      this[abortReasonKey] = reason;
    const abortController = this[abortControllerKey];
    if (abortController && !abortController.signal.aborted)
      abortController.abort(reason);
  },
  [getAbortController]() {
    this[abortControllerKey] ||= new AbortController;
    if (this[abortReasonKey] !== undefined && !this[abortControllerKey].signal.aborted)
      this[abortControllerKey].abort(this[abortReasonKey]);
    return this[abortControllerKey];
  },
  [getRequestCache]() {
    const abortController = this[getAbortController]();
    if (this[requestCache])
      return this[requestCache];
    const method = this.method;
    if (this[bodyConsumedDirectlyKey] && !(method === "GET" || method === "HEAD")) {
      this[bodyBufferKey] = undefined;
      const init = {
        method: method === "TRACE" ? "GET" : method,
        headers: this.headers,
        signal: abortController.signal
      };
      if (method !== "TRACE") {
        init.body = new ReadableStream({ start(c) {
          c.close();
        } });
        init.duplex = "half";
      }
      const req = new Request$1(this[urlKey], init);
      if (method === "TRACE")
        Object.defineProperty(req, "method", { get() {
          return "TRACE";
        } });
      return this[requestCache] = req;
    }
    return this[requestCache] = newRequestFromIncoming(this.method, this[urlKey], this.headers, this[incomingKey], abortController);
  },
  get body() {
    if (!this[bodyConsumedDirectlyKey])
      return this[getRequestCache]().body;
    const request = this[getRequestCache]();
    if (!this[bodyLockReaderKey] && request.body)
      this[bodyLockReaderKey] = request.body.getReader();
    return request.body;
  },
  get bodyUsed() {
    if (this[bodyConsumedDirectlyKey])
      return true;
    if (this[requestCache])
      return this[requestCache].bodyUsed;
    return false;
  }
};
Object.defineProperty(requestPrototype, "signal", { get() {
  return this[getAbortController]().signal;
} });
[
  "cache",
  "credentials",
  "destination",
  "integrity",
  "mode",
  "redirect",
  "referrer",
  "referrerPolicy",
  "keepalive"
].forEach((k) => {
  Object.defineProperty(requestPrototype, k, { get() {
    return this[getRequestCache]()[k];
  } });
});
["clone", "formData"].forEach((k) => {
  Object.defineProperty(requestPrototype, k, { value: function() {
    if (this[bodyConsumedDirectlyKey]) {
      if (k === "clone")
        throw newBodyUnusableError();
      return rejectBodyUnusable();
    }
    return this[getRequestCache]()[k]();
  } });
});
Object.defineProperty(requestPrototype, "text", { value: function() {
  return readBodyWithFastPath(this, "text", (buf) => textDecoder.decode(buf));
} });
Object.defineProperty(requestPrototype, "arrayBuffer", { value: function() {
  return readBodyWithFastPath(this, "arrayBuffer", (buf) => toArrayBuffer(buf));
} });
Object.defineProperty(requestPrototype, "blob", { value: function() {
  return readBodyWithFastPath(this, "blob", (buf, request) => {
    const type = contentType(request);
    const init = type ? { headers: { "content-type": type } } : undefined;
    return new Response(buf, init).blob();
  });
} });
Object.defineProperty(requestPrototype, "json", { value: function() {
  if (this[bodyConsumedDirectlyKey])
    return rejectBodyUnusable();
  return this.text().then(JSON.parse);
} });
Object.defineProperty(requestPrototype, Symbol.for("nodejs.util.inspect.custom"), { value: function(depth, options, inspectFn) {
  return `Request (lightweight) ${inspectFn({
    method: this.method,
    url: this.url,
    headers: this.headers,
    nativeRequest: this[requestCache]
  }, {
    ...options,
    depth: depth == null ? null : depth - 1
  })}`;
} });
Object.setPrototypeOf(requestPrototype, Request$1.prototype);
var newRequest = (incoming, defaultHostname) => {
  const req = Object.create(requestPrototype);
  req[incomingKey] = incoming;
  req[methodKey] = normalizeIncomingMethod(incoming.method);
  const incomingUrl = incoming.url || "";
  if (incomingUrl[0] !== "/" && (incomingUrl.startsWith("http://") || incomingUrl.startsWith("https://"))) {
    if (incoming instanceof Http2ServerRequest)
      throw new RequestError("Absolute URL for :path is not allowed in HTTP/2");
    try {
      req[urlKey] = new URL(incomingUrl).href;
    } catch (e) {
      throw new RequestError("Invalid absolute URL", { cause: e });
    }
    return req;
  }
  const host = (incoming instanceof Http2ServerRequest ? incoming.authority : incoming.headers.host) || defaultHostname;
  if (!host)
    throw new RequestError("Missing host header");
  let scheme;
  if (incoming instanceof Http2ServerRequest) {
    scheme = incoming.scheme;
    if (!(scheme === "http" || scheme === "https"))
      throw new RequestError("Unsupported scheme");
  } else
    scheme = incoming.socket && incoming.socket.encrypted ? "https" : "http";
  try {
    req[urlKey] = buildUrl(scheme, host, incomingUrl);
  } catch (e) {
    if (e instanceof RequestError)
      throw e;
    else
      throw new RequestError("Invalid URL", { cause: e });
  }
  return req;
};
var defaultContentType = "text/plain; charset=UTF-8";
var responseCache = Symbol("responseCache");
var getResponseCache = Symbol("getResponseCache");
var cacheKey = Symbol("cache");
var GlobalResponse = global.Response;
var Response$1 = class Response$1 {
  #body;
  #init;
  [getResponseCache]() {
    const cache = this[cacheKey];
    const liveHeaders = cache && cache[2] instanceof Headers ? cache[2] : undefined;
    delete this[cacheKey];
    return this[responseCache] ||= new GlobalResponse(this.#body, liveHeaders ? {
      status: this.#init?.status,
      statusText: this.#init?.statusText,
      headers: liveHeaders
    } : this.#init);
  }
  constructor(body, init) {
    let headers;
    this.#body = body;
    if (init instanceof GlobalResponse) {
      const cachedGlobalResponse = init[responseCache];
      if (cachedGlobalResponse) {
        this.#init = cachedGlobalResponse;
        this[getResponseCache]();
        return;
      }
      this.#init = init instanceof Response$1 ? init.#init : init;
      headers = new Headers(init.headers);
    } else
      this.#init = init;
    if (body == null || typeof body === "string" || typeof body?.getReader !== "undefined" || body instanceof Blob || body instanceof Uint8Array)
      this[cacheKey] = [
        init?.status || 200,
        body ?? null,
        headers || init?.headers
      ];
  }
  get headers() {
    const cache = this[cacheKey];
    if (cache) {
      if (!(cache[2] instanceof Headers))
        cache[2] = new Headers(cache[2] || (cache[1] === null ? undefined : { "content-type": defaultContentType }));
      return cache[2];
    }
    return this[getResponseCache]().headers;
  }
  get status() {
    return this[cacheKey]?.[0] ?? this[getResponseCache]().status;
  }
  get ok() {
    const status = this.status;
    return status >= 200 && status < 300;
  }
};
[
  "body",
  "bodyUsed",
  "redirected",
  "statusText",
  "trailers",
  "type",
  "url"
].forEach((k) => {
  Object.defineProperty(Response$1.prototype, k, { get() {
    return this[getResponseCache]()[k];
  } });
});
[
  "arrayBuffer",
  "blob",
  "clone",
  "formData",
  "json",
  "text"
].forEach((k) => {
  Object.defineProperty(Response$1.prototype, k, { value: function() {
    return this[getResponseCache]()[k]();
  } });
});
Object.defineProperty(Response$1.prototype, Symbol.for("nodejs.util.inspect.custom"), { value: function(depth, options, inspectFn) {
  return `Response (lightweight) ${inspectFn({
    status: this.status,
    headers: this.headers,
    ok: this.ok,
    nativeResponse: this[responseCache]
  }, {
    ...options,
    depth: depth == null ? null : depth - 1
  })}`;
} });
Object.setPrototypeOf(Response$1, GlobalResponse);
Object.setPrototypeOf(Response$1.prototype, GlobalResponse.prototype);
var validRedirectUrl = /^https?:\/\/[!#-;=?-[\]_a-z~A-Z]+$/;
var parseRedirectUrl = (url) => {
  if (url instanceof URL)
    return url.href;
  if (validRedirectUrl.test(url))
    return url;
  return new URL(url).href;
};
var validRedirectStatuses = new Set([
  301,
  302,
  303,
  307,
  308
]);
Object.defineProperty(Response$1, "redirect", {
  value: function redirect(url, status = 302) {
    if (!validRedirectStatuses.has(status))
      throw new RangeError("Invalid status code");
    return new Response$1(null, {
      status,
      headers: { location: parseRedirectUrl(url) }
    });
  },
  writable: true,
  configurable: true
});
Object.defineProperty(Response$1, "json", {
  value: function json(data, init) {
    const body = JSON.stringify(data);
    if (body === undefined)
      throw new TypeError("The data is not JSON serializable");
    const initHeaders = init?.headers;
    let headers;
    if (initHeaders) {
      headers = new Headers(initHeaders);
      if (!headers.has("content-type"))
        headers.set("content-type", "application/json");
    } else
      headers = { "content-type": "application/json" };
    return new Response$1(body, {
      status: init?.status ?? 200,
      statusText: init?.statusText,
      headers
    });
  },
  writable: true,
  configurable: true
});
async function readWithoutBlocking(readPromise) {
  return Promise.race([readPromise, Promise.resolve().then(() => Promise.resolve(undefined))]);
}
function writeFromReadableStreamDefaultReader(reader, writable, currentReadPromise) {
  const cancel = (error) => {
    reader.cancel(error).catch(() => {});
  };
  writable.on("close", cancel);
  writable.on("error", cancel);
  (currentReadPromise ?? reader.read()).then(flow, handleStreamError);
  return reader.closed.finally(() => {
    writable.off("close", cancel);
    writable.off("error", cancel);
  });
  function handleStreamError(error) {
    if (error)
      writable.destroy(error);
  }
  function onDrain() {
    reader.read().then(flow, handleStreamError);
  }
  function flow({ done, value }) {
    try {
      if (done)
        writable.end();
      else if (!writable.write(value))
        writable.once("drain", onDrain);
      else
        return reader.read().then(flow, handleStreamError);
    } catch (e) {
      handleStreamError(e);
    }
  }
}
function writeFromReadableStream(stream, writable) {
  if (stream.locked)
    throw new TypeError("ReadableStream is locked.");
  else if (writable.destroyed)
    return;
  return writeFromReadableStreamDefaultReader(stream.getReader(), writable);
}
var buildOutgoingHttpHeaders = (headers, defaultContentType) => {
  const res = {};
  if (!(headers instanceof Headers))
    headers = new Headers(headers ?? undefined);
  if (headers.has("set-cookie")) {
    const cookies = [];
    for (const [k, v] of headers)
      if (k === "set-cookie")
        cookies.push(v);
      else
        res[k] = v;
    if (cookies.length > 0)
      res["set-cookie"] = cookies;
  } else
    for (const [k, v] of headers)
      res[k] = v;
  if (defaultContentType)
    res["content-type"] ??= defaultContentType;
  return res;
};
var outgoingEnded = Symbol("outgoingEnded");
var incomingDraining = Symbol("incomingDraining");
var DRAIN_TIMEOUT_MS = 500;
var MAX_DRAIN_BYTES = 64 * 1024 * 1024;
var drainIncoming = (incoming) => {
  const incomingWithDrainState = incoming;
  if (incoming.destroyed || incomingWithDrainState[incomingDraining])
    return;
  incomingWithDrainState[incomingDraining] = true;
  if (incoming instanceof Http2ServerRequest) {
    try {
      incoming.stream?.close?.(constants.NGHTTP2_NO_ERROR);
    } catch {}
    return;
  }
  let bytesRead = 0;
  const cleanup = () => {
    clearTimeout(timer);
    incoming.off("data", onData);
    incoming.off("end", cleanup);
    incoming.off("error", cleanup);
  };
  const forceClose = () => {
    cleanup();
    const socket = incoming.socket;
    if (socket && !socket.destroyed) {
      if (typeof socket.destroySoon === "function")
        socket.destroySoon();
      else if (typeof socket.destroy === "function")
        socket.destroy();
    }
  };
  const timer = setTimeout(forceClose, DRAIN_TIMEOUT_MS);
  timer.unref?.();
  const onData = (chunk) => {
    bytesRead += chunk.length;
    if (bytesRead > MAX_DRAIN_BYTES)
      forceClose();
  };
  incoming.on("data", onData);
  incoming.on("end", cleanup);
  incoming.on("error", cleanup);
  incoming.resume();
};
var makeCloseHandler = (req, incoming, outgoing, needsBodyCleanup) => () => {
  if (incoming.errored) {
    recordBodyBufferedBeforeDisconnect(incoming);
    req[abortRequest](incoming.errored.toString());
  } else if (!outgoing.writableFinished) {
    recordBodyBufferedBeforeDisconnect(incoming);
    req[abortRequest]("Client connection prematurely closed.");
  }
  if (needsBodyCleanup && !incoming.readableEnded)
    setTimeout(() => {
      if (!incoming.readableEnded)
        setTimeout(() => {
          drainIncoming(incoming);
        });
    });
};
var isImmediateCacheableResponse = (res) => {
  if (!(cacheKey in res))
    return false;
  const body = res[cacheKey][1];
  return body === null || typeof body === "string" || body instanceof Uint8Array;
};
var handleRequestError = () => new Response(null, { status: 400 });
var handleFetchError = (e) => new Response(null, { status: e instanceof Error && (e.name === "TimeoutError" || e.constructor.name === "TimeoutError") ? 504 : 500 });
var handleResponseError = (e, outgoing) => {
  const err = e instanceof Error ? e : new Error("unknown error", { cause: e });
  if (err.code === "ERR_STREAM_PREMATURE_CLOSE")
    console.info("The user aborted a request.");
  else {
    console.error(e);
    if (!outgoing.headersSent)
      outgoing.writeHead(500, { "Content-Type": "text/plain" });
    outgoing.end(`Error: ${err.message}`);
    outgoing.destroy(err);
  }
};
var flushHeaders = (outgoing) => {
  if ("flushHeaders" in outgoing && outgoing.writable)
    outgoing.flushHeaders();
};
var responseViaCache = async (res, outgoing) => {
  let [status, body, header] = res[cacheKey];
  if (!header) {
    if (body === null) {
      outgoing.writeHead(status);
      outgoing.end();
    } else if (typeof body === "string") {
      outgoing.writeHead(status, {
        "Content-Type": defaultContentType,
        "Content-Length": Buffer.byteLength(body)
      });
      outgoing.end(body);
    } else if (body instanceof Uint8Array) {
      outgoing.writeHead(status, {
        "Content-Type": defaultContentType,
        "Content-Length": body.byteLength
      });
      outgoing.end(body);
    } else if (body instanceof Blob) {
      outgoing.writeHead(status, {
        "Content-Type": defaultContentType,
        "Content-Length": body.size
      });
      outgoing.end(new Uint8Array(await body.arrayBuffer()));
    } else {
      outgoing.writeHead(status, { "Content-Type": defaultContentType });
      flushHeaders(outgoing);
      await writeFromReadableStream(body, outgoing)?.catch((e) => handleResponseError(e, outgoing));
    }
    outgoing[outgoingEnded]?.();
    return;
  }
  let hasContentLength = false;
  if (header instanceof Headers) {
    hasContentLength = header.has("content-length");
    header = buildOutgoingHttpHeaders(header, body === null ? undefined : defaultContentType);
  } else if (Array.isArray(header)) {
    const headerObj = new Headers(header);
    hasContentLength = headerObj.has("content-length");
    header = buildOutgoingHttpHeaders(headerObj, body === null ? undefined : defaultContentType);
  } else
    for (const key in header)
      if (key.length === 14 && key.toLowerCase() === "content-length") {
        hasContentLength = true;
        break;
      }
  if (!hasContentLength) {
    if (typeof body === "string")
      header["Content-Length"] = Buffer.byteLength(body);
    else if (body instanceof Uint8Array)
      header["Content-Length"] = body.byteLength;
    else if (body instanceof Blob)
      header["Content-Length"] = body.size;
  }
  outgoing.writeHead(status, header);
  if (body == null)
    outgoing.end();
  else if (typeof body === "string" || body instanceof Uint8Array)
    outgoing.end(body);
  else if (body instanceof Blob)
    outgoing.end(new Uint8Array(await body.arrayBuffer()));
  else {
    flushHeaders(outgoing);
    await writeFromReadableStream(body, outgoing)?.catch((e) => handleResponseError(e, outgoing));
  }
  outgoing[outgoingEnded]?.();
};
var isPromise = (res) => typeof res.then === "function";
var responseViaResponseObject = async (res, outgoing, options = {}) => {
  if (isPromise(res))
    if (options.errorHandler)
      try {
        res = await res;
      } catch (err) {
        const errRes = await options.errorHandler(err);
        if (!errRes)
          return;
        res = errRes;
      }
    else
      res = await res.catch(handleFetchError);
  if (cacheKey in res)
    return responseViaCache(res, outgoing);
  const resHeaderRecord = buildOutgoingHttpHeaders(res.headers, res.body === null ? undefined : defaultContentType);
  if (res.body) {
    const reader = res.body.getReader();
    const values = [];
    let done = false;
    let currentReadPromise = undefined;
    if (resHeaderRecord["transfer-encoding"] !== "chunked") {
      let maxReadCount = 2;
      for (let i = 0;i < maxReadCount; i++) {
        currentReadPromise ||= reader.read();
        const chunk = await readWithoutBlocking(currentReadPromise).catch((e) => {
          console.error(e);
          done = true;
        });
        if (!chunk) {
          if (i === 1) {
            await new Promise((resolve) => setTimeout(resolve));
            maxReadCount = 3;
            continue;
          }
          break;
        }
        currentReadPromise = undefined;
        if (chunk.value)
          values.push(chunk.value);
        if (chunk.done) {
          done = true;
          break;
        }
      }
      if (done && !("content-length" in resHeaderRecord))
        resHeaderRecord["content-length"] = values.reduce((acc, value) => acc + value.length, 0);
    }
    outgoing.writeHead(res.status, resHeaderRecord);
    values.forEach((value) => {
      outgoing.write(value);
    });
    if (done)
      outgoing.end();
    else {
      if (values.length === 0)
        flushHeaders(outgoing);
      await writeFromReadableStreamDefaultReader(reader, outgoing, currentReadPromise);
    }
  } else if (resHeaderRecord[X_ALREADY_SENT]) {} else {
    outgoing.writeHead(res.status, resHeaderRecord);
    outgoing.end();
  }
  outgoing[outgoingEnded]?.();
};
var getRequestListener = (fetchCallback, options = {}) => {
  const autoCleanupIncoming = options.autoCleanupIncoming ?? true;
  if (options.overrideGlobalObjects !== false && global.Request !== Request$1) {
    Object.defineProperty(global, "Request", { value: Request$1 });
    Object.defineProperty(global, "Response", { value: Response$1 });
  }
  return async (incoming, outgoing) => {
    let res, req;
    let needsBodyCleanup = false;
    let closeHandlerAttached = false;
    const ensureCloseHandler = () => {
      if (!req || closeHandlerAttached)
        return;
      closeHandlerAttached = true;
      outgoing.on("close", makeCloseHandler(req, incoming, outgoing, needsBodyCleanup));
    };
    try {
      req = newRequest(incoming, options.hostname);
      needsBodyCleanup = autoCleanupIncoming && !(incoming.method === "GET" || incoming.method === "HEAD");
      if (needsBodyCleanup) {
        incoming[wrapBodyStream] = true;
        if (incoming instanceof Http2ServerRequest)
          outgoing[outgoingEnded] = () => {
            if (!incoming.readableEnded)
              setTimeout(() => {
                if (!incoming.readableEnded)
                  setTimeout(() => {
                    incoming.destroy();
                    outgoing.destroy();
                  });
              });
          };
      }
      res = fetchCallback(req, {
        incoming,
        outgoing
      });
      if (!isPromise(res) && isImmediateCacheableResponse(res)) {
        if (needsBodyCleanup && !incoming.readableEnded)
          outgoing.once("finish", () => {
            if (!incoming.readableEnded)
              drainIncoming(incoming);
          });
        return responseViaCache(res, outgoing);
      }
      ensureCloseHandler();
    } catch (e) {
      if (!res)
        if (options.errorHandler) {
          ensureCloseHandler();
          res = await options.errorHandler(req ? e : toRequestError(e));
          if (!res)
            return;
        } else if (!req)
          res = handleRequestError();
        else
          res = handleFetchError(e);
      else
        return handleResponseError(e, outgoing);
    }
    try {
      return await responseViaResponseObject(res, outgoing, options);
    } catch (e) {
      return handleResponseError(e, outgoing);
    }
  };
};
var CloseEvent = globalThis.CloseEvent ?? class extends Event {
  #eventInitDict;
  constructor(type, eventInitDict = {}) {
    super(type, eventInitDict);
    this.#eventInitDict = eventInitDict;
  }
  get wasClean() {
    return this.#eventInitDict.wasClean ?? false;
  }
  get code() {
    return this.#eventInitDict.code ?? 0;
  }
  get reason() {
    return this.#eventInitDict.reason ?? "";
  }
};
var ErrorEvent = globalThis.ErrorEvent ?? class extends Event {
  #eventInitDict;
  constructor(type, eventInitDict = {}) {
    super(type, eventInitDict);
    this.#eventInitDict = eventInitDict;
  }
  get message() {
    return this.#eventInitDict.message ?? "";
  }
  get filename() {
    return this.#eventInitDict.filename ?? "";
  }
  get lineno() {
    return this.#eventInitDict.lineno ?? 0;
  }
  get colno() {
    return this.#eventInitDict.colno ?? 0;
  }
  get error() {
    return this.#eventInitDict.error ?? null;
  }
};
var generateConnectionSymbol = () => Symbol("connection");
var CONNECTION_SYMBOL_KEY = Symbol("CONNECTION_SYMBOL_KEY");
var WAIT_FOR_WEBSOCKET_SYMBOL = Symbol("WAIT_FOR_WEBSOCKET_SYMBOL");
var responseHeadersToSkip = new Set([
  "connection",
  "content-length",
  "keep-alive",
  "proxy-authenticate",
  "proxy-authorization",
  "te",
  "trailer",
  "transfer-encoding",
  "upgrade",
  "sec-websocket-accept",
  "sec-websocket-extensions",
  "sec-websocket-protocol"
]);
var appendResponseHeaders = (headers, responseHeaders) => {
  if (!responseHeaders)
    return;
  responseHeaders.forEach((value, key) => {
    if (responseHeadersToSkip.has(key.toLowerCase()))
      return;
    headers.push(`${key}: ${value}`);
  });
};
var rejectUpgradeRequest = (socket, status, responseHeaders) => {
  const responseLines = ["Connection: close", "Content-Length: 0"];
  appendResponseHeaders(responseLines, responseHeaders);
  socket.end(`HTTP/1.1 ${status.toString()} ${STATUS_CODES[status] ?? ""}\r
${responseLines.join(`\r
`)}\r
\r
`);
};
var createUpgradeRequest = (request) => {
  const protocol = request.socket.encrypted ? "https" : "http";
  const url = new URL(request.url ?? "/", `${protocol}://${request.headers.host ?? "localhost"}`);
  const headers = new Headers;
  for (const key in request.headers) {
    const value = request.headers[key];
    if (!value)
      continue;
    headers.append(key, Array.isArray(value) ? value[0] : value);
  }
  return new Request(url, { headers });
};
var setupWebSocket = (options) => {
  const { server, fetchCallback, wss } = options;
  const waiterMap = /* @__PURE__ */ new Map;
  wss.on("connection", (ws, request) => {
    const waiter = waiterMap.get(request);
    if (waiter) {
      waiter.resolve(ws);
      waiterMap.delete(request);
    }
  });
  const rejectWaiter = (request) => {
    const waiter = waiterMap.get(request);
    if (waiter) {
      waiterMap.delete(request);
      waiter.reject(/* @__PURE__ */ new Error("WebSocket handshake aborted"));
    }
  };
  const waitForWebSocket = (request, connectionSymbol) => {
    return new Promise((resolve, reject) => {
      waiterMap.set(request, {
        resolve,
        reject,
        connectionSymbol
      });
    });
  };
  server.on("upgrade", async (request, socket, head) => {
    if (request.headers.upgrade?.toLowerCase() !== "websocket")
      return;
    const env = {
      incoming: request,
      outgoing: undefined,
      wss,
      [WAIT_FOR_WEBSOCKET_SYMBOL]: waitForWebSocket
    };
    let status = 400;
    let responseHeaders;
    try {
      const response = await fetchCallback(createUpgradeRequest(request), env);
      if (response instanceof Response) {
        status = response.status;
        responseHeaders = response.headers;
      }
    } catch {
      if (server.listenerCount("upgrade") === 1)
        rejectUpgradeRequest(socket, 500);
      return;
    }
    const waiter = waiterMap.get(request);
    if (!waiter || waiter.connectionSymbol !== env[CONNECTION_SYMBOL_KEY]) {
      rejectWaiter(request);
      if (server.listenerCount("upgrade") === 1)
        rejectUpgradeRequest(socket, status, responseHeaders);
      return;
    }
    const addResponseHeaders = (headers) => {
      appendResponseHeaders(headers, responseHeaders);
    };
    const reclaimWaiterOnClose = () => rejectWaiter(request);
    socket.once("close", reclaimWaiterOnClose);
    wss.on("headers", addResponseHeaders);
    try {
      wss.handleUpgrade(request, socket, head, (ws) => {
        socket.off("close", reclaimWaiterOnClose);
        wss.emit("connection", ws, request);
      });
    } finally {
      wss.off("headers", addResponseHeaders);
    }
  });
  server.on("close", () => {
    wss.close();
  });
};
var upgradeWebSocket = defineWebSocketHelper(async (c, events, options) => {
  if (c.req.header("upgrade")?.toLowerCase() !== "websocket")
    return;
  const env = c.env;
  const waitForWebSocket = env[WAIT_FOR_WEBSOCKET_SYMBOL];
  if (!waitForWebSocket || !env.incoming)
    return new Response(null, { status: 500 });
  const connectionSymbol = generateConnectionSymbol();
  env[CONNECTION_SYMBOL_KEY] = connectionSymbol;
  (async () => {
    let ws;
    try {
      ws = await waitForWebSocket(env.incoming, connectionSymbol);
    } catch {
      return;
    }
    const messagesReceivedInStarting = [];
    const bufferMessage = (data, isBinary) => {
      messagesReceivedInStarting.push([data, isBinary]);
    };
    ws.on("message", bufferMessage);
    const ctx = {
      binaryType: "arraybuffer",
      close(code, reason) {
        ws.close(code, reason);
      },
      protocol: ws.protocol,
      raw: ws,
      get readyState() {
        return ws.readyState;
      },
      send(source, opts) {
        ws.send(source, { compress: opts?.compress });
      },
      url: new URL(c.req.url)
    };
    try {
      events?.onOpen?.(new Event("open"), ctx);
    } catch (e) {
      (options?.onError ?? console.error)(e);
    }
    const handleMessage = (data, isBinary) => {
      const datas = Array.isArray(data) ? data : [data];
      for (const data of datas)
        try {
          events?.onMessage?.(new MessageEvent("message", { data: isBinary ? data instanceof ArrayBuffer ? data : data.buffer.slice(data.byteOffset, data.byteOffset + data.byteLength) : typeof data === "string" ? data : Buffer.from(data).toString("utf-8") }), ctx);
        } catch (e) {
          (options?.onError ?? console.error)(e);
        }
    };
    ws.off("message", bufferMessage);
    for (const message of messagesReceivedInStarting)
      handleMessage(...message);
    ws.on("message", (data, isBinary) => {
      handleMessage(data, isBinary);
    });
    ws.on("close", (code, reason) => {
      try {
        events?.onClose?.(new CloseEvent("close", {
          code,
          reason: reason.toString()
        }), ctx);
      } catch (e) {
        (options?.onError ?? console.error)(e);
      }
    });
    ws.on("error", (error) => {
      try {
        events?.onError?.(new ErrorEvent("error", { error }), ctx);
      } catch (e) {
        (options?.onError ?? console.error)(e);
      }
    });
  })();
  return new Response;
});
var createAdaptorServer = (options) => {
  const fetchCallback = options.fetch;
  const requestListener = getRequestListener(fetchCallback, {
    hostname: options.hostname,
    overrideGlobalObjects: options.overrideGlobalObjects,
    autoCleanupIncoming: options.autoCleanupIncoming
  });
  const server = (options.createServer || createServer)(options.serverOptions || {}, requestListener);
  if (options.websocket && options.websocket.server) {
    if (options.websocket.server.options.noServer !== true)
      throw new Error("WebSocket server must be created with { noServer: true } option");
    setupWebSocket({
      server,
      fetchCallback,
      wss: options.websocket.server
    });
  }
  return server;
};
var serve = (options, listeningListener) => {
  const server = createAdaptorServer(options);
  server.listen(options?.port ?? 3000, options.hostname, () => {
    const serverInfo = server.address();
    listeningListener && listeningListener(serverInfo);
  });
  return server;
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/compose.js
var compose = (middleware, onError, onNotFound) => {
  return (context, next) => {
    let index = -1;
    return dispatch(0);
    async function dispatch(i) {
      if (i <= index) {
        throw new Error("next() called multiple times");
      }
      index = i;
      let res;
      let isError = false;
      let handler;
      if (middleware[i]) {
        handler = middleware[i][0][0];
        context.req.routeIndex = i;
      } else {
        handler = i === middleware.length && next || undefined;
      }
      if (handler) {
        try {
          res = await handler(context, () => dispatch(i + 1));
        } catch (err) {
          if (err instanceof Error && onError) {
            context.error = err;
            res = await onError(err, context);
            isError = true;
          } else {
            throw err;
          }
        }
      } else {
        if (context.finalized === false && onNotFound) {
          res = await onNotFound(context);
        }
      }
      if (res && (context.finalized === false || isError)) {
        context.res = res;
      }
      return context;
    }
  };
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/request/constants.js
var GET_MATCH_RESULT = /* @__PURE__ */ Symbol();

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/utils/body.js
var parseBody = async (request, options = /* @__PURE__ */ Object.create(null)) => {
  const { all = false, dot = false } = options;
  const headers = request instanceof HonoRequest ? request.raw.headers : request.headers;
  const contentType = headers.get("Content-Type");
  if (contentType?.startsWith("multipart/form-data") || contentType?.startsWith("application/x-www-form-urlencoded")) {
    return parseFormData(request, { all, dot });
  }
  return {};
};
async function parseFormData(request, options) {
  const formData = await request.formData();
  if (formData) {
    return convertFormDataToBodyData(formData, options);
  }
  return {};
}
function convertFormDataToBodyData(formData, options) {
  const form = /* @__PURE__ */ Object.create(null);
  formData.forEach((value, key) => {
    const shouldParseAllValues = options.all || key.endsWith("[]");
    if (!shouldParseAllValues) {
      form[key] = value;
    } else {
      handleParsingAllValues(form, key, value);
    }
  });
  if (options.dot) {
    Object.entries(form).forEach(([key, value]) => {
      const shouldParseDotValues = key.includes(".");
      if (shouldParseDotValues) {
        handleParsingNestedValues(form, key, value);
        delete form[key];
      }
    });
  }
  return form;
}
var handleParsingAllValues = (form, key, value) => {
  if (form[key] !== undefined) {
    if (Array.isArray(form[key])) {
      form[key].push(value);
    } else {
      form[key] = [form[key], value];
    }
  } else {
    if (!key.endsWith("[]")) {
      form[key] = value;
    } else {
      form[key] = [value];
    }
  }
};
var handleParsingNestedValues = (form, key, value) => {
  if (/(?:^|\.)__proto__\./.test(key)) {
    return;
  }
  let nestedForm = form;
  const keys = key.split(".");
  keys.forEach((key2, index) => {
    if (index === keys.length - 1) {
      nestedForm[key2] = value;
    } else {
      if (!nestedForm[key2] || typeof nestedForm[key2] !== "object" || Array.isArray(nestedForm[key2]) || nestedForm[key2] instanceof File) {
        nestedForm[key2] = /* @__PURE__ */ Object.create(null);
      }
      nestedForm = nestedForm[key2];
    }
  });
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/utils/url.js
var splitPath = (path) => {
  const paths = path.split("/");
  if (paths[0] === "") {
    paths.shift();
  }
  return paths;
};
var splitRoutingPath = (routePath) => {
  const { groups, path } = extractGroupsFromPath(routePath);
  const paths = splitPath(path);
  return replaceGroupMarks(paths, groups);
};
var extractGroupsFromPath = (path) => {
  const groups = [];
  path = path.replace(/\{[^}]+\}/g, (match, index) => {
    const mark = `@${index}`;
    groups.push([mark, match]);
    return mark;
  });
  return { groups, path };
};
var replaceGroupMarks = (paths, groups) => {
  for (let i = groups.length - 1;i >= 0; i--) {
    const [mark] = groups[i];
    for (let j = paths.length - 1;j >= 0; j--) {
      if (paths[j].includes(mark)) {
        paths[j] = paths[j].replace(mark, groups[i][1]);
        break;
      }
    }
  }
  return paths;
};
var patternCache = {};
var getPattern = (label, next) => {
  if (label === "*") {
    return "*";
  }
  const match = label.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
  if (match) {
    const cacheKey = `${label}#${next}`;
    if (!patternCache[cacheKey]) {
      if (match[2]) {
        patternCache[cacheKey] = next && next[0] !== ":" && next[0] !== "*" ? [cacheKey, match[1], new RegExp(`^${match[2]}(?=/${next})`)] : [label, match[1], new RegExp(`^${match[2]}$`)];
      } else {
        patternCache[cacheKey] = [label, match[1], true];
      }
    }
    return patternCache[cacheKey];
  }
  return null;
};
var tryDecode = (str, decoder) => {
  try {
    return decoder(str);
  } catch {
    return str.replace(/(?:%[0-9A-Fa-f]{2})+/g, (match) => {
      try {
        return decoder(match);
      } catch {
        return match;
      }
    });
  }
};
var tryDecodeURI = (str) => tryDecode(str, decodeURI);
var getPath = (request) => {
  const url = request.url;
  const start = url.indexOf("/", url.indexOf(":") + 4);
  let i = start;
  for (;i < url.length; i++) {
    const charCode = url.charCodeAt(i);
    if (charCode === 37) {
      const queryIndex = url.indexOf("?", i);
      const hashIndex = url.indexOf("#", i);
      const end = queryIndex === -1 ? hashIndex === -1 ? undefined : hashIndex : hashIndex === -1 ? queryIndex : Math.min(queryIndex, hashIndex);
      const path = url.slice(start, end);
      return tryDecodeURI(path.includes("%25") ? path.replace(/%25/g, "%2525") : path);
    } else if (charCode === 63 || charCode === 35) {
      break;
    }
  }
  return url.slice(start, i);
};
var getPathNoStrict = (request) => {
  const result = getPath(request);
  return result.length > 1 && result.at(-1) === "/" ? result.slice(0, -1) : result;
};
var mergePath = (base, sub, ...rest) => {
  if (rest.length) {
    sub = mergePath(sub, ...rest);
  }
  return `${base?.[0] === "/" ? "" : "/"}${base}${sub === "/" ? "" : `${base?.at(-1) === "/" ? "" : "/"}${sub?.[0] === "/" ? sub.slice(1) : sub}`}`;
};
var checkOptionalParameter = (path) => {
  if (path.charCodeAt(path.length - 1) !== 63 || !path.includes(":")) {
    return null;
  }
  const segments = path.split("/");
  const results = [];
  let basePath = "";
  segments.forEach((segment) => {
    if (segment !== "" && !/\:/.test(segment)) {
      basePath += "/" + segment;
    } else if (/\:/.test(segment)) {
      if (/\?/.test(segment)) {
        if (results.length === 0 && basePath === "") {
          results.push("/");
        } else {
          results.push(basePath);
        }
        const optionalSegment = segment.replace("?", "");
        basePath += "/" + optionalSegment;
        results.push(basePath);
      } else {
        basePath += "/" + segment;
      }
    }
  });
  return results.filter((v, i, a) => a.indexOf(v) === i);
};
var _decodeURI = (value) => {
  if (!/[%+]/.test(value)) {
    return value;
  }
  if (value.indexOf("+") !== -1) {
    value = value.replace(/\+/g, " ");
  }
  return value.indexOf("%") !== -1 ? tryDecode(value, decodeURIComponent_) : value;
};
var _getQueryParam = (url, key, multiple) => {
  let encoded;
  if (!multiple && key && !/[%+]/.test(key)) {
    let keyIndex2 = url.indexOf("?", 8);
    if (keyIndex2 === -1) {
      return;
    }
    if (!url.startsWith(key, keyIndex2 + 1)) {
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    while (keyIndex2 !== -1) {
      const trailingKeyCode = url.charCodeAt(keyIndex2 + key.length + 1);
      if (trailingKeyCode === 61) {
        const valueIndex = keyIndex2 + key.length + 2;
        const endIndex = url.indexOf("&", valueIndex);
        return _decodeURI(url.slice(valueIndex, endIndex === -1 ? undefined : endIndex));
      } else if (trailingKeyCode == 38 || isNaN(trailingKeyCode)) {
        return "";
      }
      keyIndex2 = url.indexOf(`&${key}`, keyIndex2 + 1);
    }
    encoded = /[%+]/.test(url);
    if (!encoded) {
      return;
    }
  }
  const results = {};
  encoded ??= /[%+]/.test(url);
  let keyIndex = url.indexOf("?", 8);
  while (keyIndex !== -1) {
    const nextKeyIndex = url.indexOf("&", keyIndex + 1);
    let valueIndex = url.indexOf("=", keyIndex);
    if (valueIndex > nextKeyIndex && nextKeyIndex !== -1) {
      valueIndex = -1;
    }
    let name = url.slice(keyIndex + 1, valueIndex === -1 ? nextKeyIndex === -1 ? undefined : nextKeyIndex : valueIndex);
    if (encoded) {
      name = _decodeURI(name);
    }
    keyIndex = nextKeyIndex;
    if (name === "") {
      continue;
    }
    let value;
    if (valueIndex === -1) {
      value = "";
    } else {
      value = url.slice(valueIndex + 1, nextKeyIndex === -1 ? undefined : nextKeyIndex);
      if (encoded) {
        value = _decodeURI(value);
      }
    }
    if (multiple) {
      if (!(results[name] && Array.isArray(results[name]))) {
        results[name] = [];
      }
      results[name].push(value);
    } else {
      results[name] ??= value;
    }
  }
  return key ? results[key] : results;
};
var getQueryParam = _getQueryParam;
var getQueryParams = (url, key) => {
  return _getQueryParam(url, key, true);
};
var decodeURIComponent_ = decodeURIComponent;

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/request.js
var tryDecodeURIComponent = (str) => tryDecode(str, decodeURIComponent_);
var HonoRequest = class {
  raw;
  #validatedData;
  #matchResult;
  routeIndex = 0;
  path;
  bodyCache = {};
  constructor(request, path = "/", matchResult = [[]]) {
    this.raw = request;
    this.path = path;
    this.#matchResult = matchResult;
    this.#validatedData = {};
  }
  param(key) {
    return key ? this.#getDecodedParam(key) : this.#getAllDecodedParams();
  }
  #getDecodedParam(key) {
    const paramKey = this.#matchResult[0][this.routeIndex][1][key];
    const param = this.#getParamValue(paramKey);
    return param && /\%/.test(param) ? tryDecodeURIComponent(param) : param;
  }
  #getAllDecodedParams() {
    const decoded = {};
    const keys = Object.keys(this.#matchResult[0][this.routeIndex][1]);
    for (const key of keys) {
      const value = this.#getParamValue(this.#matchResult[0][this.routeIndex][1][key]);
      if (value !== undefined) {
        decoded[key] = /\%/.test(value) ? tryDecodeURIComponent(value) : value;
      }
    }
    return decoded;
  }
  #getParamValue(paramKey) {
    return this.#matchResult[1] ? this.#matchResult[1][paramKey] : paramKey;
  }
  query(key) {
    return getQueryParam(this.url, key);
  }
  queries(key) {
    return getQueryParams(this.url, key);
  }
  header(name) {
    if (name) {
      return this.raw.headers.get(name) ?? undefined;
    }
    const headerData = {};
    this.raw.headers.forEach((value, key) => {
      headerData[key] = value;
    });
    return headerData;
  }
  async parseBody(options) {
    return parseBody(this, options);
  }
  #cachedBody = (key) => {
    const { bodyCache, raw } = this;
    const cachedBody = bodyCache[key];
    if (cachedBody) {
      return cachedBody;
    }
    const anyCachedKey = Object.keys(bodyCache)[0];
    if (anyCachedKey) {
      return bodyCache[anyCachedKey].then((body) => {
        if (anyCachedKey === "json") {
          body = JSON.stringify(body);
        }
        return new Response(body)[key]();
      });
    }
    return bodyCache[key] = raw[key]();
  };
  json() {
    return this.#cachedBody("text").then((text) => JSON.parse(text));
  }
  text() {
    return this.#cachedBody("text");
  }
  arrayBuffer() {
    return this.#cachedBody("arrayBuffer");
  }
  blob() {
    return this.#cachedBody("blob");
  }
  formData() {
    return this.#cachedBody("formData");
  }
  addValidatedData(target, data) {
    this.#validatedData[target] = data;
  }
  valid(target) {
    return this.#validatedData[target];
  }
  get url() {
    return this.raw.url;
  }
  get method() {
    return this.raw.method;
  }
  get [GET_MATCH_RESULT]() {
    return this.#matchResult;
  }
  get matchedRoutes() {
    return this.#matchResult[0].map(([[, route]]) => route);
  }
  get routePath() {
    return this.#matchResult[0].map(([[, route]]) => route)[this.routeIndex].path;
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/utils/html.js
var HtmlEscapedCallbackPhase = {
  Stringify: 1,
  BeforeStream: 2,
  Stream: 3
};
var raw = (value, callbacks) => {
  const escapedString = new String(value);
  escapedString.isEscaped = true;
  escapedString.callbacks = callbacks;
  return escapedString;
};
var resolveCallback = async (str, phase, preserveCallbacks, context, buffer) => {
  if (typeof str === "object" && !(str instanceof String)) {
    if (!(str instanceof Promise)) {
      str = str.toString();
    }
    if (str instanceof Promise) {
      str = await str;
    }
  }
  const callbacks = str.callbacks;
  if (!callbacks?.length) {
    return Promise.resolve(str);
  }
  if (buffer) {
    buffer[0] += str;
  } else {
    buffer = [str];
  }
  const resStr = Promise.all(callbacks.map((c) => c({ phase, buffer, context }))).then((res) => Promise.all(res.filter(Boolean).map((str2) => resolveCallback(str2, phase, false, context, buffer))).then(() => buffer[0]));
  if (preserveCallbacks) {
    return raw(await resStr, callbacks);
  } else {
    return resStr;
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/context.js
var TEXT_PLAIN = "text/plain; charset=UTF-8";
var setDefaultContentType = (contentType, headers) => {
  return {
    "Content-Type": contentType,
    ...headers
  };
};
var createResponseInstance = (body, init) => new Response(body, init);
var Context = class {
  #rawRequest;
  #req;
  env = {};
  #var;
  finalized = false;
  error;
  #status;
  #executionCtx;
  #res;
  #layout;
  #renderer;
  #notFoundHandler;
  #preparedHeaders;
  #matchResult;
  #path;
  constructor(req, options) {
    this.#rawRequest = req;
    if (options) {
      this.#executionCtx = options.executionCtx;
      this.env = options.env;
      this.#notFoundHandler = options.notFoundHandler;
      this.#path = options.path;
      this.#matchResult = options.matchResult;
    }
  }
  get req() {
    this.#req ??= new HonoRequest(this.#rawRequest, this.#path, this.#matchResult);
    return this.#req;
  }
  get event() {
    if (this.#executionCtx && "respondWith" in this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no FetchEvent");
    }
  }
  get executionCtx() {
    if (this.#executionCtx) {
      return this.#executionCtx;
    } else {
      throw Error("This context has no ExecutionContext");
    }
  }
  get res() {
    return this.#res ||= createResponseInstance(null, {
      headers: this.#preparedHeaders ??= new Headers
    });
  }
  set res(_res) {
    if (this.#res && _res) {
      _res = createResponseInstance(_res.body, _res);
      for (const [k, v] of this.#res.headers.entries()) {
        if (k === "content-type") {
          continue;
        }
        if (k === "set-cookie") {
          const cookies = this.#res.headers.getSetCookie();
          _res.headers.delete("set-cookie");
          for (const cookie of cookies) {
            _res.headers.append("set-cookie", cookie);
          }
        } else {
          _res.headers.set(k, v);
        }
      }
    }
    this.#res = _res;
    this.finalized = true;
  }
  render = (...args) => {
    this.#renderer ??= (content) => this.html(content);
    return this.#renderer(...args);
  };
  setLayout = (layout) => this.#layout = layout;
  getLayout = () => this.#layout;
  setRenderer = (renderer) => {
    this.#renderer = renderer;
  };
  header = (name, value, options) => {
    if (this.finalized) {
      this.#res = createResponseInstance(this.#res.body, this.#res);
    }
    const headers = this.#res ? this.#res.headers : this.#preparedHeaders ??= new Headers;
    if (value === undefined) {
      headers.delete(name);
    } else if (options?.append) {
      headers.append(name, value);
    } else {
      headers.set(name, value);
    }
  };
  status = (status) => {
    this.#status = status;
  };
  set = (key, value) => {
    this.#var ??= /* @__PURE__ */ new Map;
    this.#var.set(key, value);
  };
  get = (key) => {
    return this.#var ? this.#var.get(key) : undefined;
  };
  get var() {
    if (!this.#var) {
      return {};
    }
    return Object.fromEntries(this.#var);
  }
  #newResponse(data, arg, headers) {
    const responseHeaders = this.#res ? new Headers(this.#res.headers) : this.#preparedHeaders ?? new Headers;
    if (typeof arg === "object" && "headers" in arg) {
      const argHeaders = arg.headers instanceof Headers ? arg.headers : new Headers(arg.headers);
      for (const [key, value] of argHeaders) {
        if (key.toLowerCase() === "set-cookie") {
          responseHeaders.append(key, value);
        } else {
          responseHeaders.set(key, value);
        }
      }
    }
    if (headers) {
      for (const [k, v] of Object.entries(headers)) {
        if (typeof v === "string") {
          responseHeaders.set(k, v);
        } else {
          responseHeaders.delete(k);
          for (const v2 of v) {
            responseHeaders.append(k, v2);
          }
        }
      }
    }
    const status = typeof arg === "number" ? arg : arg?.status ?? this.#status;
    return createResponseInstance(data, { status, headers: responseHeaders });
  }
  newResponse = (...args) => this.#newResponse(...args);
  body = (data, arg, headers) => this.#newResponse(data, arg, headers);
  text = (text, arg, headers) => {
    return !this.#preparedHeaders && !this.#status && !arg && !headers && !this.finalized ? new Response(text) : this.#newResponse(text, arg, setDefaultContentType(TEXT_PLAIN, headers));
  };
  json = (object, arg, headers) => {
    return this.#newResponse(JSON.stringify(object), arg, setDefaultContentType("application/json", headers));
  };
  html = (html, arg, headers) => {
    const res = (html2) => this.#newResponse(html2, arg, setDefaultContentType("text/html; charset=UTF-8", headers));
    return typeof html === "object" ? resolveCallback(html, HtmlEscapedCallbackPhase.Stringify, false, {}).then(res) : res(html);
  };
  redirect = (location, status) => {
    const locationString = String(location);
    this.header("Location", !/[^\x00-\xFF]/.test(locationString) ? locationString : encodeURI(locationString));
    return this.newResponse(null, status ?? 302);
  };
  notFound = () => {
    this.#notFoundHandler ??= () => createResponseInstance();
    return this.#notFoundHandler(this);
  };
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router.js
var METHOD_NAME_ALL = "ALL";
var METHOD_NAME_ALL_LOWERCASE = "all";
var METHODS = ["get", "post", "put", "delete", "options", "patch"];
var MESSAGE_MATCHER_IS_ALREADY_BUILT = "Can not add a route since the matcher is already built.";
var UnsupportedPathError = class extends Error {
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/utils/constants.js
var COMPOSED_HANDLER = "__COMPOSED_HANDLER";

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/hono-base.js
var notFoundHandler = (c) => {
  return c.text("404 Not Found", 404);
};
var errorHandler = (err, c) => {
  if ("getResponse" in err) {
    const res = err.getResponse();
    return c.newResponse(res.body, res);
  }
  console.error(err);
  return c.text("Internal Server Error", 500);
};
var Hono = class _Hono {
  get;
  post;
  put;
  delete;
  options;
  patch;
  all;
  on;
  use;
  router;
  getPath;
  _basePath = "/";
  #path = "/";
  routes = [];
  constructor(options = {}) {
    const allMethods = [...METHODS, METHOD_NAME_ALL_LOWERCASE];
    allMethods.forEach((method) => {
      this[method] = (args1, ...args) => {
        if (typeof args1 === "string") {
          this.#path = args1;
        } else {
          this.#addRoute(method, this.#path, args1);
        }
        args.forEach((handler) => {
          this.#addRoute(method, this.#path, handler);
        });
        return this;
      };
    });
    this.on = (method, path, ...handlers) => {
      for (const p of [path].flat()) {
        this.#path = p;
        for (const m of [method].flat()) {
          handlers.map((handler) => {
            this.#addRoute(m.toUpperCase(), this.#path, handler);
          });
        }
      }
      return this;
    };
    this.use = (arg1, ...handlers) => {
      if (typeof arg1 === "string") {
        this.#path = arg1;
      } else {
        this.#path = "*";
        handlers.unshift(arg1);
      }
      handlers.forEach((handler) => {
        this.#addRoute(METHOD_NAME_ALL, this.#path, handler);
      });
      return this;
    };
    const { strict, ...optionsWithoutStrict } = options;
    Object.assign(this, optionsWithoutStrict);
    this.getPath = strict ?? true ? options.getPath ?? getPath : getPathNoStrict;
  }
  #clone() {
    const clone = new _Hono({
      router: this.router,
      getPath: this.getPath
    });
    clone.errorHandler = this.errorHandler;
    clone.#notFoundHandler = this.#notFoundHandler;
    clone.routes = this.routes;
    return clone;
  }
  #notFoundHandler = notFoundHandler;
  errorHandler = errorHandler;
  route(path, app) {
    const subApp = this.basePath(path);
    app.routes.map((r) => {
      let handler;
      if (app.errorHandler === errorHandler) {
        handler = r.handler;
      } else {
        handler = async (c, next) => (await compose([], app.errorHandler)(c, () => r.handler(c, next))).res;
        handler[COMPOSED_HANDLER] = r.handler;
      }
      subApp.#addRoute(r.method, r.path, handler);
    });
    return this;
  }
  basePath(path) {
    const subApp = this.#clone();
    subApp._basePath = mergePath(this._basePath, path);
    return subApp;
  }
  onError = (handler) => {
    this.errorHandler = handler;
    return this;
  };
  notFound = (handler) => {
    this.#notFoundHandler = handler;
    return this;
  };
  mount(path, applicationHandler, options) {
    let replaceRequest;
    let optionHandler;
    if (options) {
      if (typeof options === "function") {
        optionHandler = options;
      } else {
        optionHandler = options.optionHandler;
        if (options.replaceRequest === false) {
          replaceRequest = (request) => request;
        } else {
          replaceRequest = options.replaceRequest;
        }
      }
    }
    const getOptions = optionHandler ? (c) => {
      const options2 = optionHandler(c);
      return Array.isArray(options2) ? options2 : [options2];
    } : (c) => {
      let executionContext = undefined;
      try {
        executionContext = c.executionCtx;
      } catch {}
      return [c.env, executionContext];
    };
    replaceRequest ||= (() => {
      const mergedPath = mergePath(this._basePath, path);
      const pathPrefixLength = mergedPath === "/" ? 0 : mergedPath.length;
      return (request) => {
        const url = new URL(request.url);
        url.pathname = url.pathname.slice(pathPrefixLength) || "/";
        return new Request(url, request);
      };
    })();
    const handler = async (c, next) => {
      const res = await applicationHandler(replaceRequest(c.req.raw), ...getOptions(c));
      if (res) {
        return res;
      }
      await next();
    };
    this.#addRoute(METHOD_NAME_ALL, mergePath(path, "*"), handler);
    return this;
  }
  #addRoute(method, path, handler) {
    method = method.toUpperCase();
    path = mergePath(this._basePath, path);
    const r = { basePath: this._basePath, path, method, handler };
    this.router.add(method, path, [handler, r]);
    this.routes.push(r);
  }
  #handleError(err, c) {
    if (err instanceof Error) {
      return this.errorHandler(err, c);
    }
    throw err;
  }
  #dispatch(request, executionCtx, env, method) {
    if (method === "HEAD") {
      return (async () => new Response(null, await this.#dispatch(request, executionCtx, env, "GET")))();
    }
    const path = this.getPath(request, { env });
    const matchResult = this.router.match(method, path);
    const c = new Context(request, {
      path,
      matchResult,
      env,
      executionCtx,
      notFoundHandler: this.#notFoundHandler
    });
    if (matchResult[0].length === 1) {
      let res;
      try {
        res = matchResult[0][0][0][0](c, async () => {
          c.res = await this.#notFoundHandler(c);
        });
      } catch (err) {
        return this.#handleError(err, c);
      }
      return res instanceof Promise ? res.then((resolved) => resolved || (c.finalized ? c.res : this.#notFoundHandler(c))).catch((err) => this.#handleError(err, c)) : res ?? this.#notFoundHandler(c);
    }
    const composed = compose(matchResult[0], this.errorHandler, this.#notFoundHandler);
    return (async () => {
      try {
        const context = await composed(c);
        if (!context.finalized) {
          throw new Error("Context is not finalized. Did you forget to return a Response object or `await next()`?");
        }
        return context.res;
      } catch (err) {
        return this.#handleError(err, c);
      }
    })();
  }
  fetch = (request, ...rest) => {
    return this.#dispatch(request, rest[1], rest[0], request.method);
  };
  request = (input, requestInit, Env, executionCtx) => {
    if (input instanceof Request) {
      return this.fetch(requestInit ? new Request(input, requestInit) : input, Env, executionCtx);
    }
    input = input.toString();
    return this.fetch(new Request(/^https?:\/\//.test(input) ? input : `http://localhost${mergePath("/", input)}`, requestInit), Env, executionCtx);
  };
  fire = () => {
    addEventListener("fetch", (event) => {
      event.respondWith(this.#dispatch(event.request, event, undefined, event.request.method));
    });
  };
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router/reg-exp-router/matcher.js
var emptyParam = [];
function match(method, path) {
  const matchers = this.buildAllMatchers();
  const match2 = (method2, path2) => {
    const matcher = matchers[method2] || matchers[METHOD_NAME_ALL];
    const staticMatch = matcher[2][path2];
    if (staticMatch) {
      return staticMatch;
    }
    const match3 = path2.match(matcher[0]);
    if (!match3) {
      return [[], emptyParam];
    }
    const index = match3.indexOf("", 1);
    return [matcher[1][index], match3];
  };
  this.match = match2;
  return match2(method, path);
}

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router/reg-exp-router/node.js
var LABEL_REG_EXP_STR = "[^/]+";
var ONLY_WILDCARD_REG_EXP_STR = ".*";
var TAIL_WILDCARD_REG_EXP_STR = "(?:|/.*)";
var PATH_ERROR = /* @__PURE__ */ Symbol();
var regExpMetaChars = new Set(".\\+*[^]$()");
function compareKey(a, b) {
  if (a.length === 1) {
    return b.length === 1 ? a < b ? -1 : 1 : -1;
  }
  if (b.length === 1) {
    return 1;
  }
  if (a === ONLY_WILDCARD_REG_EXP_STR || a === TAIL_WILDCARD_REG_EXP_STR) {
    return 1;
  } else if (b === ONLY_WILDCARD_REG_EXP_STR || b === TAIL_WILDCARD_REG_EXP_STR) {
    return -1;
  }
  if (a === LABEL_REG_EXP_STR) {
    return 1;
  } else if (b === LABEL_REG_EXP_STR) {
    return -1;
  }
  return a.length === b.length ? a < b ? -1 : 1 : b.length - a.length;
}
var Node = class _Node {
  #index;
  #varIndex;
  #children = /* @__PURE__ */ Object.create(null);
  insert(tokens, index, paramMap, context, pathErrorCheckOnly) {
    if (tokens.length === 0) {
      if (this.#index !== undefined) {
        throw PATH_ERROR;
      }
      if (pathErrorCheckOnly) {
        return;
      }
      this.#index = index;
      return;
    }
    const [token, ...restTokens] = tokens;
    const pattern = token === "*" ? restTokens.length === 0 ? ["", "", ONLY_WILDCARD_REG_EXP_STR] : ["", "", LABEL_REG_EXP_STR] : token === "/*" ? ["", "", TAIL_WILDCARD_REG_EXP_STR] : token.match(/^\:([^\{\}]+)(?:\{(.+)\})?$/);
    let node;
    if (pattern) {
      const name = pattern[1];
      let regexpStr = pattern[2] || LABEL_REG_EXP_STR;
      if (name && pattern[2]) {
        if (regexpStr === ".*") {
          throw PATH_ERROR;
        }
        regexpStr = regexpStr.replace(/^\((?!\?:)(?=[^)]+\)$)/, "(?:");
        if (/\((?!\?:)/.test(regexpStr)) {
          throw PATH_ERROR;
        }
      }
      node = this.#children[regexpStr];
      if (!node) {
        if (Object.keys(this.#children).some((k) => k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR)) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[regexpStr] = new _Node;
        if (name !== "") {
          node.#varIndex = context.varIndex++;
        }
      }
      if (!pathErrorCheckOnly && name !== "") {
        paramMap.push([name, node.#varIndex]);
      }
    } else {
      node = this.#children[token];
      if (!node) {
        if (Object.keys(this.#children).some((k) => k.length > 1 && k !== ONLY_WILDCARD_REG_EXP_STR && k !== TAIL_WILDCARD_REG_EXP_STR)) {
          throw PATH_ERROR;
        }
        if (pathErrorCheckOnly) {
          return;
        }
        node = this.#children[token] = new _Node;
      }
    }
    node.insert(restTokens, index, paramMap, context, pathErrorCheckOnly);
  }
  buildRegExpStr() {
    const childKeys = Object.keys(this.#children).sort(compareKey);
    const strList = childKeys.map((k) => {
      const c = this.#children[k];
      return (typeof c.#varIndex === "number" ? `(${k})@${c.#varIndex}` : regExpMetaChars.has(k) ? `\\${k}` : k) + c.buildRegExpStr();
    });
    if (typeof this.#index === "number") {
      strList.unshift(`#${this.#index}`);
    }
    if (strList.length === 0) {
      return "";
    }
    if (strList.length === 1) {
      return strList[0];
    }
    return "(?:" + strList.join("|") + ")";
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router/reg-exp-router/trie.js
var Trie = class {
  #context = { varIndex: 0 };
  #root = new Node;
  insert(path, index, pathErrorCheckOnly) {
    const paramAssoc = [];
    const groups = [];
    for (let i = 0;; ) {
      let replaced = false;
      path = path.replace(/\{[^}]+\}/g, (m) => {
        const mark = `@\\${i}`;
        groups[i] = [mark, m];
        i++;
        replaced = true;
        return mark;
      });
      if (!replaced) {
        break;
      }
    }
    const tokens = path.match(/(?::[^\/]+)|(?:\/\*$)|./g) || [];
    for (let i = groups.length - 1;i >= 0; i--) {
      const [mark] = groups[i];
      for (let j = tokens.length - 1;j >= 0; j--) {
        if (tokens[j].indexOf(mark) !== -1) {
          tokens[j] = tokens[j].replace(mark, groups[i][1]);
          break;
        }
      }
    }
    this.#root.insert(tokens, index, paramAssoc, this.#context, pathErrorCheckOnly);
    return paramAssoc;
  }
  buildRegExp() {
    let regexp = this.#root.buildRegExpStr();
    if (regexp === "") {
      return [/^$/, [], []];
    }
    let captureIndex = 0;
    const indexReplacementMap = [];
    const paramReplacementMap = [];
    regexp = regexp.replace(/#(\d+)|@(\d+)|\.\*\$/g, (_, handlerIndex, paramIndex) => {
      if (handlerIndex !== undefined) {
        indexReplacementMap[++captureIndex] = Number(handlerIndex);
        return "$()";
      }
      if (paramIndex !== undefined) {
        paramReplacementMap[Number(paramIndex)] = ++captureIndex;
        return "";
      }
      return "";
    });
    return [new RegExp(`^${regexp}`), indexReplacementMap, paramReplacementMap];
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router/reg-exp-router/router.js
var nullMatcher = [/^$/, [], /* @__PURE__ */ Object.create(null)];
var wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
function buildWildcardRegExp(path) {
  return wildcardRegExpCache[path] ??= new RegExp(path === "*" ? "" : `^${path.replace(/\/\*$|([.\\+*[^\]$()])/g, (_, metaChar) => metaChar ? `\\${metaChar}` : "(?:|/.*)")}$`);
}
function clearWildcardRegExpCache() {
  wildcardRegExpCache = /* @__PURE__ */ Object.create(null);
}
function buildMatcherFromPreprocessedRoutes(routes) {
  const trie = new Trie;
  const handlerData = [];
  if (routes.length === 0) {
    return nullMatcher;
  }
  const routesWithStaticPathFlag = routes.map((route) => [!/\*|\/:/.test(route[0]), ...route]).sort(([isStaticA, pathA], [isStaticB, pathB]) => isStaticA ? 1 : isStaticB ? -1 : pathA.length - pathB.length);
  const staticMap = /* @__PURE__ */ Object.create(null);
  for (let i = 0, j = -1, len = routesWithStaticPathFlag.length;i < len; i++) {
    const [pathErrorCheckOnly, path, handlers] = routesWithStaticPathFlag[i];
    if (pathErrorCheckOnly) {
      staticMap[path] = [handlers.map(([h]) => [h, /* @__PURE__ */ Object.create(null)]), emptyParam];
    } else {
      j++;
    }
    let paramAssoc;
    try {
      paramAssoc = trie.insert(path, j, pathErrorCheckOnly);
    } catch (e) {
      throw e === PATH_ERROR ? new UnsupportedPathError(path) : e;
    }
    if (pathErrorCheckOnly) {
      continue;
    }
    handlerData[j] = handlers.map(([h, paramCount]) => {
      const paramIndexMap = /* @__PURE__ */ Object.create(null);
      paramCount -= 1;
      for (;paramCount >= 0; paramCount--) {
        const [key, value] = paramAssoc[paramCount];
        paramIndexMap[key] = value;
      }
      return [h, paramIndexMap];
    });
  }
  const [regexp, indexReplacementMap, paramReplacementMap] = trie.buildRegExp();
  for (let i = 0, len = handlerData.length;i < len; i++) {
    for (let j = 0, len2 = handlerData[i].length;j < len2; j++) {
      const map = handlerData[i][j]?.[1];
      if (!map) {
        continue;
      }
      const keys = Object.keys(map);
      for (let k = 0, len3 = keys.length;k < len3; k++) {
        map[keys[k]] = paramReplacementMap[map[keys[k]]];
      }
    }
  }
  const handlerMap = [];
  for (const i in indexReplacementMap) {
    handlerMap[i] = handlerData[indexReplacementMap[i]];
  }
  return [regexp, handlerMap, staticMap];
}
function findMiddleware(middleware, path) {
  if (!middleware) {
    return;
  }
  for (const k of Object.keys(middleware).sort((a, b) => b.length - a.length)) {
    if (buildWildcardRegExp(k).test(path)) {
      return [...middleware[k]];
    }
  }
  return;
}
var RegExpRouter = class {
  name = "RegExpRouter";
  #middleware;
  #routes;
  constructor() {
    this.#middleware = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
    this.#routes = { [METHOD_NAME_ALL]: /* @__PURE__ */ Object.create(null) };
  }
  add(method, path, handler) {
    const middleware = this.#middleware;
    const routes = this.#routes;
    if (!middleware || !routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    if (!middleware[method]) {
      [middleware, routes].forEach((handlerMap) => {
        handlerMap[method] = /* @__PURE__ */ Object.create(null);
        Object.keys(handlerMap[METHOD_NAME_ALL]).forEach((p) => {
          handlerMap[method][p] = [...handlerMap[METHOD_NAME_ALL][p]];
        });
      });
    }
    if (path === "/*") {
      path = "*";
    }
    const paramCount = (path.match(/\/:/g) || []).length;
    if (/\*$/.test(path)) {
      const re = buildWildcardRegExp(path);
      if (method === METHOD_NAME_ALL) {
        Object.keys(middleware).forEach((m) => {
          middleware[m][path] ||= findMiddleware(middleware[m], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
        });
      } else {
        middleware[method][path] ||= findMiddleware(middleware[method], path) || findMiddleware(middleware[METHOD_NAME_ALL], path) || [];
      }
      Object.keys(middleware).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(middleware[m]).forEach((p) => {
            re.test(p) && middleware[m][p].push([handler, paramCount]);
          });
        }
      });
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          Object.keys(routes[m]).forEach((p) => re.test(p) && routes[m][p].push([handler, paramCount]));
        }
      });
      return;
    }
    const paths = checkOptionalParameter(path) || [path];
    for (let i = 0, len = paths.length;i < len; i++) {
      const path2 = paths[i];
      Object.keys(routes).forEach((m) => {
        if (method === METHOD_NAME_ALL || method === m) {
          routes[m][path2] ||= [
            ...findMiddleware(middleware[m], path2) || findMiddleware(middleware[METHOD_NAME_ALL], path2) || []
          ];
          routes[m][path2].push([handler, paramCount - len + i + 1]);
        }
      });
    }
  }
  match = match;
  buildAllMatchers() {
    const matchers = /* @__PURE__ */ Object.create(null);
    Object.keys(this.#routes).concat(Object.keys(this.#middleware)).forEach((method) => {
      matchers[method] ||= this.#buildMatcher(method);
    });
    this.#middleware = this.#routes = undefined;
    clearWildcardRegExpCache();
    return matchers;
  }
  #buildMatcher(method) {
    const routes = [];
    let hasOwnRoute = method === METHOD_NAME_ALL;
    [this.#middleware, this.#routes].forEach((r) => {
      const ownRoute = r[method] ? Object.keys(r[method]).map((path) => [path, r[method][path]]) : [];
      if (ownRoute.length !== 0) {
        hasOwnRoute ||= true;
        routes.push(...ownRoute);
      } else if (method !== METHOD_NAME_ALL) {
        routes.push(...Object.keys(r[METHOD_NAME_ALL]).map((path) => [path, r[METHOD_NAME_ALL][path]]));
      }
    });
    if (!hasOwnRoute) {
      return null;
    } else {
      return buildMatcherFromPreprocessedRoutes(routes);
    }
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router/smart-router/router.js
var SmartRouter = class {
  name = "SmartRouter";
  #routers = [];
  #routes = [];
  constructor(init) {
    this.#routers = init.routers;
  }
  add(method, path, handler) {
    if (!this.#routes) {
      throw new Error(MESSAGE_MATCHER_IS_ALREADY_BUILT);
    }
    this.#routes.push([method, path, handler]);
  }
  match(method, path) {
    if (!this.#routes) {
      throw new Error("Fatal error");
    }
    const routers = this.#routers;
    const routes = this.#routes;
    const len = routers.length;
    let i = 0;
    let res;
    for (;i < len; i++) {
      const router = routers[i];
      try {
        for (let i2 = 0, len2 = routes.length;i2 < len2; i2++) {
          router.add(...routes[i2]);
        }
        res = router.match(method, path);
      } catch (e) {
        if (e instanceof UnsupportedPathError) {
          continue;
        }
        throw e;
      }
      this.match = router.match.bind(router);
      this.#routers = [router];
      this.#routes = undefined;
      break;
    }
    if (i === len) {
      throw new Error("Fatal error");
    }
    this.name = `SmartRouter + ${this.activeRouter.name}`;
    return res;
  }
  get activeRouter() {
    if (this.#routes || this.#routers.length !== 1) {
      throw new Error("No active router has been determined yet.");
    }
    return this.#routers[0];
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router/trie-router/node.js
var emptyParams = /* @__PURE__ */ Object.create(null);
var hasChildren = (children) => {
  for (const _ in children) {
    return true;
  }
  return false;
};
var Node2 = class _Node {
  #methods;
  #children;
  #patterns;
  #order = 0;
  #params = emptyParams;
  constructor(method, handler, children) {
    this.#children = children || /* @__PURE__ */ Object.create(null);
    this.#methods = [];
    if (method && handler) {
      const m = /* @__PURE__ */ Object.create(null);
      m[method] = { handler, possibleKeys: [], score: 0 };
      this.#methods = [m];
    }
    this.#patterns = [];
  }
  insert(method, path, handler) {
    this.#order = ++this.#order;
    let curNode = this;
    const parts = splitRoutingPath(path);
    const possibleKeys = [];
    for (let i = 0, len = parts.length;i < len; i++) {
      const p = parts[i];
      const nextP = parts[i + 1];
      const pattern = getPattern(p, nextP);
      const key = Array.isArray(pattern) ? pattern[0] : p;
      if (key in curNode.#children) {
        curNode = curNode.#children[key];
        if (pattern) {
          possibleKeys.push(pattern[1]);
        }
        continue;
      }
      curNode.#children[key] = new _Node;
      if (pattern) {
        curNode.#patterns.push(pattern);
        possibleKeys.push(pattern[1]);
      }
      curNode = curNode.#children[key];
    }
    curNode.#methods.push({
      [method]: {
        handler,
        possibleKeys: possibleKeys.filter((v, i, a) => a.indexOf(v) === i),
        score: this.#order
      }
    });
    return curNode;
  }
  #pushHandlerSets(handlerSets, node, method, nodeParams, params) {
    for (let i = 0, len = node.#methods.length;i < len; i++) {
      const m = node.#methods[i];
      const handlerSet = m[method] || m[METHOD_NAME_ALL];
      const processedSet = {};
      if (handlerSet !== undefined) {
        handlerSet.params = /* @__PURE__ */ Object.create(null);
        handlerSets.push(handlerSet);
        if (nodeParams !== emptyParams || params && params !== emptyParams) {
          for (let i2 = 0, len2 = handlerSet.possibleKeys.length;i2 < len2; i2++) {
            const key = handlerSet.possibleKeys[i2];
            const processed = processedSet[handlerSet.score];
            handlerSet.params[key] = params?.[key] && !processed ? params[key] : nodeParams[key] ?? params?.[key];
            processedSet[handlerSet.score] = true;
          }
        }
      }
    }
  }
  search(method, path) {
    const handlerSets = [];
    this.#params = emptyParams;
    const curNode = this;
    let curNodes = [curNode];
    const parts = splitPath(path);
    const curNodesQueue = [];
    const len = parts.length;
    let partOffsets = null;
    for (let i = 0;i < len; i++) {
      const part = parts[i];
      const isLast = i === len - 1;
      const tempNodes = [];
      for (let j = 0, len2 = curNodes.length;j < len2; j++) {
        const node = curNodes[j];
        const nextNode = node.#children[part];
        if (nextNode) {
          nextNode.#params = node.#params;
          if (isLast) {
            if (nextNode.#children["*"]) {
              this.#pushHandlerSets(handlerSets, nextNode.#children["*"], method, node.#params);
            }
            this.#pushHandlerSets(handlerSets, nextNode, method, node.#params);
          } else {
            tempNodes.push(nextNode);
          }
        }
        for (let k = 0, len3 = node.#patterns.length;k < len3; k++) {
          const pattern = node.#patterns[k];
          const params = node.#params === emptyParams ? {} : { ...node.#params };
          if (pattern === "*") {
            const astNode = node.#children["*"];
            if (astNode) {
              this.#pushHandlerSets(handlerSets, astNode, method, node.#params);
              astNode.#params = params;
              tempNodes.push(astNode);
            }
            continue;
          }
          const [key, name, matcher] = pattern;
          if (!part && !(matcher instanceof RegExp)) {
            continue;
          }
          const child = node.#children[key];
          if (matcher instanceof RegExp) {
            if (partOffsets === null) {
              partOffsets = new Array(len);
              let offset = path[0] === "/" ? 1 : 0;
              for (let p = 0;p < len; p++) {
                partOffsets[p] = offset;
                offset += parts[p].length + 1;
              }
            }
            const restPathString = path.substring(partOffsets[i]);
            const m = matcher.exec(restPathString);
            if (m) {
              params[name] = m[0];
              this.#pushHandlerSets(handlerSets, child, method, node.#params, params);
              if (hasChildren(child.#children)) {
                child.#params = params;
                const componentCount = m[0].match(/\//)?.length ?? 0;
                const targetCurNodes = curNodesQueue[componentCount] ||= [];
                targetCurNodes.push(child);
              }
              continue;
            }
          }
          if (matcher === true || matcher.test(part)) {
            params[name] = part;
            if (isLast) {
              this.#pushHandlerSets(handlerSets, child, method, params, node.#params);
              if (child.#children["*"]) {
                this.#pushHandlerSets(handlerSets, child.#children["*"], method, params, node.#params);
              }
            } else {
              child.#params = params;
              tempNodes.push(child);
            }
          }
        }
      }
      const shifted = curNodesQueue.shift();
      curNodes = shifted ? tempNodes.concat(shifted) : tempNodes;
    }
    if (handlerSets.length > 1) {
      handlerSets.sort((a, b) => {
        return a.score - b.score;
      });
    }
    return [handlerSets.map(({ handler, params }) => [handler, params])];
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/router/trie-router/router.js
var TrieRouter = class {
  name = "TrieRouter";
  #node;
  constructor() {
    this.#node = new Node2;
  }
  add(method, path, handler) {
    const results = checkOptionalParameter(path);
    if (results) {
      for (let i = 0, len = results.length;i < len; i++) {
        this.#node.insert(method, results[i], handler);
      }
      return;
    }
    this.#node.insert(method, path, handler);
  }
  match(method, path) {
    return this.#node.search(method, path);
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/hono.js
var Hono2 = class extends Hono {
  constructor(options = {}) {
    super(options);
    this.router = options.router ?? new SmartRouter({
      routers: [new RegExpRouter, new TrieRouter]
    });
  }
};

// node_modules/.bun/hono@4.12.10/node_modules/hono/dist/middleware/cors/index.js
var cors = (options) => {
  const defaults = {
    origin: "*",
    allowMethods: ["GET", "HEAD", "PUT", "POST", "DELETE", "PATCH"],
    allowHeaders: [],
    exposeHeaders: []
  };
  const opts = {
    ...defaults,
    ...options
  };
  const findAllowOrigin = ((optsOrigin) => {
    if (typeof optsOrigin === "string") {
      if (optsOrigin === "*") {
        if (opts.credentials) {
          return (origin) => origin || null;
        }
        return () => optsOrigin;
      } else {
        return (origin) => optsOrigin === origin ? origin : null;
      }
    } else if (typeof optsOrigin === "function") {
      return optsOrigin;
    } else {
      return (origin) => optsOrigin.includes(origin) ? origin : null;
    }
  })(opts.origin);
  const findAllowMethods = ((optsAllowMethods) => {
    if (typeof optsAllowMethods === "function") {
      return optsAllowMethods;
    } else if (Array.isArray(optsAllowMethods)) {
      return () => optsAllowMethods;
    } else {
      return () => [];
    }
  })(opts.allowMethods);
  return async function cors2(c, next) {
    function set(key, value) {
      c.res.headers.set(key, value);
    }
    const allowOrigin = await findAllowOrigin(c.req.header("origin") || "", c);
    if (allowOrigin) {
      set("Access-Control-Allow-Origin", allowOrigin);
    }
    if (opts.credentials) {
      set("Access-Control-Allow-Credentials", "true");
    }
    if (opts.exposeHeaders?.length) {
      set("Access-Control-Expose-Headers", opts.exposeHeaders.join(","));
    }
    if (c.req.method === "OPTIONS") {
      if (opts.origin !== "*" || opts.credentials) {
        set("Vary", "Origin");
      }
      if (opts.maxAge != null) {
        set("Access-Control-Max-Age", opts.maxAge.toString());
      }
      const allowMethods = await findAllowMethods(c.req.header("origin") || "", c);
      if (allowMethods.length) {
        set("Access-Control-Allow-Methods", allowMethods.join(","));
      }
      let headers = opts.allowHeaders;
      if (!headers?.length) {
        const requestHeaders = c.req.header("Access-Control-Request-Headers");
        if (requestHeaders) {
          headers = requestHeaders.split(/\s*,\s*/);
        }
      }
      if (headers?.length) {
        set("Access-Control-Allow-Headers", headers.join(","));
        c.res.headers.append("Vary", "Access-Control-Request-Headers");
      }
      c.res.headers.delete("Content-Length");
      c.res.headers.delete("Content-Type");
      return new Response(null, {
        headers: c.res.headers,
        status: 204,
        statusText: "No Content"
      });
    }
    await next();
    if (opts.origin !== "*" || opts.credentials) {
      c.header("Vary", "Origin", { append: true });
    }
  };
};

// node_modules/.bun/@orpc+shared@1.14.7/node_modules/@orpc/shared/dist/index.mjs
function resolveMaybeOptionalOptions(rest) {
  return rest[0] ?? {};
}
function toArray(value) {
  return Array.isArray(value) ? value : value === undefined || value === null ? [] : [value];
}
var ORPC_NAME = "orpc";
var ORPC_SHARED_PACKAGE_NAME = "@orpc/shared";
var ORPC_SHARED_PACKAGE_VERSION = "1.14.7";

class AbortError extends Error {
  constructor(...rest) {
    super(...rest);
    this.name = "AbortError";
  }
}
function once(fn) {
  let cached;
  return () => {
    if (cached) {
      return cached.result;
    }
    const result = fn();
    cached = { result };
    return result;
  };
}
function sequential(fn) {
  let lastOperationPromise = Promise.resolve();
  return (...args) => {
    return lastOperationPromise = lastOperationPromise.catch(() => {}).then(() => {
      return fn(...args);
    });
  };
}
var SPAN_ERROR_STATUS = 2;
var GLOBAL_OTEL_CONFIG_KEY = `__${ORPC_SHARED_PACKAGE_NAME}@${ORPC_SHARED_PACKAGE_VERSION}/otel/config__`;
function getGlobalOtelConfig() {
  return globalThis[GLOBAL_OTEL_CONFIG_KEY];
}
function startSpan(name, options = {}, context) {
  const tracer = getGlobalOtelConfig()?.tracer;
  return tracer?.startSpan(name, options, context);
}
function setSpanError(span, error, options = {}) {
  if (!span) {
    return;
  }
  const exception = toOtelException(error);
  span.recordException(exception);
  if (!options.signal?.aborted || options.signal.reason !== error) {
    span.setStatus({
      code: SPAN_ERROR_STATUS,
      message: exception.message
    });
  }
}
function toOtelException(error) {
  if (error instanceof Error) {
    const exception = {
      message: error.message,
      name: error.name,
      stack: error.stack
    };
    if ("code" in error && (typeof error.code === "string" || typeof error.code === "number")) {
      exception.code = error.code;
    }
    return exception;
  }
  return { message: String(error) };
}
async function runWithSpan({ name, context, ...options }, fn) {
  const tracer = getGlobalOtelConfig()?.tracer;
  if (!tracer) {
    return fn();
  }
  const callback = async (span) => {
    try {
      return await fn(span);
    } catch (e) {
      setSpanError(span, e, options);
      throw e;
    } finally {
      span.end();
    }
  };
  if (context) {
    return tracer.startActiveSpan(name, options, context, callback);
  } else {
    return tracer.startActiveSpan(name, options, callback);
  }
}
async function runInSpanContext(span, fn) {
  const otelConfig = getGlobalOtelConfig();
  if (!span || !otelConfig) {
    return fn();
  }
  const ctx = otelConfig.trace.setSpan(otelConfig.context.active(), span);
  return otelConfig.context.with(ctx, fn);
}
function isAsyncIteratorObject(maybe) {
  if (!maybe || typeof maybe !== "object") {
    return false;
  }
  return "next" in maybe && typeof maybe.next === "function" && Symbol.asyncIterator in maybe && typeof maybe[Symbol.asyncIterator] === "function";
}
var fallbackAsyncDisposeSymbol = Symbol.for("asyncDispose");
var asyncDisposeSymbol = Symbol.asyncDispose ?? fallbackAsyncDisposeSymbol;

class AsyncIteratorClass {
  #isDone = false;
  #isExecuteComplete = false;
  #cleanup;
  #next;
  constructor(next, cleanup) {
    this.#cleanup = cleanup;
    this.#next = sequential(async () => {
      if (this.#isDone) {
        return { done: true, value: undefined };
      }
      try {
        const result = await next();
        if (result.done) {
          this.#isDone = true;
        }
        return result;
      } catch (err) {
        this.#isDone = true;
        throw err;
      } finally {
        if (this.#isDone && !this.#isExecuteComplete) {
          this.#isExecuteComplete = true;
          await this.#cleanup("next");
        }
      }
    });
  }
  next() {
    return this.#next();
  }
  async return(value) {
    this.#isDone = true;
    if (!this.#isExecuteComplete) {
      this.#isExecuteComplete = true;
      await this.#cleanup("return");
    }
    return { done: true, value };
  }
  async throw(err) {
    this.#isDone = true;
    if (!this.#isExecuteComplete) {
      this.#isExecuteComplete = true;
      await this.#cleanup("throw");
    }
    throw err;
  }
  async[asyncDisposeSymbol]() {
    this.#isDone = true;
    if (!this.#isExecuteComplete) {
      this.#isExecuteComplete = true;
      await this.#cleanup("dispose");
    }
  }
  [Symbol.asyncIterator]() {
    return this;
  }
}
function asyncIteratorWithSpan({ name, ...options }, iterator) {
  let span;
  return new AsyncIteratorClass(async () => {
    span ??= startSpan(name);
    try {
      const result = await runInSpanContext(span, () => iterator.next());
      span?.addEvent(result.done ? "completed" : "yielded");
      return result;
    } catch (err) {
      setSpanError(span, err, options);
      throw err;
    }
  }, async (reason) => {
    try {
      if (reason !== "next") {
        await runInSpanContext(span, () => iterator.return?.());
      }
    } catch (err) {
      setSpanError(span, err, options);
      throw err;
    } finally {
      span?.end();
    }
  });
}
function intercept(interceptors, options, main) {
  const next = (options2, index) => {
    const interceptor = interceptors[index];
    if (!interceptor) {
      return main(options2);
    }
    return interceptor({
      ...options2,
      next: (newOptions = options2) => next(newOptions, index + 1)
    });
  };
  return next(options, 0);
}
function parseEmptyableJSON(text) {
  if (!text) {
    return;
  }
  return JSON.parse(text);
}
function stringifyJSON(value) {
  return JSON.stringify(value);
}
function getConstructor(value) {
  if (!isTypescriptObject(value)) {
    return null;
  }
  return Object.getPrototypeOf(value)?.constructor;
}
function isObject(value) {
  if (!value || typeof value !== "object") {
    return false;
  }
  const proto = Object.getPrototypeOf(value);
  return proto === Object.prototype || !proto || !proto.constructor;
}
function isTypescriptObject(value) {
  return !!value && (typeof value === "object" || typeof value === "function");
}
var NullProtoObj = /* @__PURE__ */ (() => {
  const e = function() {};
  e.prototype = /* @__PURE__ */ Object.create(null);
  Object.freeze(e.prototype);
  return e;
})();
function value(value2, ...args) {
  if (typeof value2 === "function") {
    return value2(...args);
  }
  return value2;
}
function overlayProxy(target, partial) {
  const proxy = new Proxy(typeof target === "function" ? partial : target, {
    get(_, prop) {
      const targetValue = prop in partial ? partial : value(target);
      const v = Reflect.get(targetValue, prop);
      return typeof v === "function" ? v.bind(targetValue) : v;
    },
    has(_, prop) {
      return Reflect.has(partial, prop) || Reflect.has(value(target), prop);
    }
  });
  return proxy;
}
function tryDecodeURIComponent2(value) {
  try {
    return decodeURIComponent(value);
  } catch {
    return value;
  }
}

// node_modules/.bun/@orpc+client@1.14.7/node_modules/@orpc/client/dist/shared/client.tBERYXHN.mjs
var ORPC_CLIENT_PACKAGE_NAME = "@orpc/client";
var ORPC_CLIENT_PACKAGE_VERSION = "1.14.7";
var COMMON_ORPC_ERROR_DEFS = {
  BAD_REQUEST: {
    status: 400,
    message: "Bad Request"
  },
  UNAUTHORIZED: {
    status: 401,
    message: "Unauthorized"
  },
  FORBIDDEN: {
    status: 403,
    message: "Forbidden"
  },
  NOT_FOUND: {
    status: 404,
    message: "Not Found"
  },
  METHOD_NOT_SUPPORTED: {
    status: 405,
    message: "Method Not Supported"
  },
  NOT_ACCEPTABLE: {
    status: 406,
    message: "Not Acceptable"
  },
  TIMEOUT: {
    status: 408,
    message: "Request Timeout"
  },
  CONFLICT: {
    status: 409,
    message: "Conflict"
  },
  PRECONDITION_FAILED: {
    status: 412,
    message: "Precondition Failed"
  },
  PAYLOAD_TOO_LARGE: {
    status: 413,
    message: "Payload Too Large"
  },
  UNSUPPORTED_MEDIA_TYPE: {
    status: 415,
    message: "Unsupported Media Type"
  },
  UNPROCESSABLE_CONTENT: {
    status: 422,
    message: "Unprocessable Content"
  },
  TOO_MANY_REQUESTS: {
    status: 429,
    message: "Too Many Requests"
  },
  CLIENT_CLOSED_REQUEST: {
    status: 499,
    message: "Client Closed Request"
  },
  INTERNAL_SERVER_ERROR: {
    status: 500,
    message: "Internal Server Error"
  },
  NOT_IMPLEMENTED: {
    status: 501,
    message: "Not Implemented"
  },
  BAD_GATEWAY: {
    status: 502,
    message: "Bad Gateway"
  },
  SERVICE_UNAVAILABLE: {
    status: 503,
    message: "Service Unavailable"
  },
  GATEWAY_TIMEOUT: {
    status: 504,
    message: "Gateway Timeout"
  }
};
function fallbackORPCErrorStatus(code, status) {
  return status ?? COMMON_ORPC_ERROR_DEFS[code]?.status ?? 500;
}
function fallbackORPCErrorMessage(code, message) {
  return message || COMMON_ORPC_ERROR_DEFS[code]?.message || code;
}
var globalORPCErrorConstructors;

class ORPCError extends Error {
  defined;
  code;
  status;
  data;
  static {
    const GLOBAL_ORPC_ERROR_CONSTRUCTORS_SYMBOL = Symbol.for(`__${ORPC_CLIENT_PACKAGE_NAME}@${ORPC_CLIENT_PACKAGE_VERSION}/error/ORPC_ERROR_CONSTRUCTORS__`);
    globalThis[GLOBAL_ORPC_ERROR_CONSTRUCTORS_SYMBOL] ??= /* @__PURE__ */ new WeakSet;
    globalORPCErrorConstructors = globalThis[GLOBAL_ORPC_ERROR_CONSTRUCTORS_SYMBOL];
    globalORPCErrorConstructors.add(ORPCError);
  }
  constructor(code, ...rest) {
    const options = resolveMaybeOptionalOptions(rest);
    if (options.status !== undefined && !isORPCErrorStatus(options.status)) {
      throw new Error("[ORPCError] Invalid error status code.");
    }
    const message = fallbackORPCErrorMessage(code, options.message);
    super(message, options);
    this.code = code;
    this.status = fallbackORPCErrorStatus(code, options.status);
    this.defined = options.defined ?? false;
    this.data = options.data;
  }
  toJSON() {
    return {
      defined: this.defined,
      code: this.code,
      status: this.status,
      message: this.message,
      data: this.data
    };
  }
  static [Symbol.hasInstance](instance) {
    if (globalORPCErrorConstructors.has(this)) {
      const constructor = getConstructor(instance);
      if (constructor && globalORPCErrorConstructors.has(constructor)) {
        return true;
      }
    }
    return super[Symbol.hasInstance](instance);
  }
}
function toORPCError(error) {
  return error instanceof ORPCError ? error : new ORPCError("INTERNAL_SERVER_ERROR", {
    message: "Internal server error",
    cause: error
  });
}
function isORPCErrorStatus(status) {
  return status < 200 || status >= 400;
}
function isORPCErrorJson(json) {
  if (!isObject(json)) {
    return false;
  }
  const validKeys = ["defined", "code", "status", "message", "data"];
  if (Object.keys(json).some((k) => !validKeys.includes(k))) {
    return false;
  }
  return "defined" in json && typeof json.defined === "boolean" && "code" in json && typeof json.code === "string" && "status" in json && typeof json.status === "number" && isORPCErrorStatus(json.status) && "message" in json && typeof json.message === "string";
}
function createORPCErrorFromJson(json, options = {}) {
  return new ORPCError(json.code, {
    ...options,
    ...json
  });
}
// node_modules/.bun/@orpc+standard-server@1.14.7/node_modules/@orpc/standard-server/dist/index.mjs
class EventEncoderError extends TypeError {
}

class EventDecoderError extends TypeError {
}

class ErrorEvent2 extends Error {
  data;
  constructor(options) {
    super(options?.message ?? "An error event was received", options);
    this.data = options?.data;
  }
}
function decodeEventMessage(encoded) {
  const lines = encoded.replace(/\n+$/, "").split(/\n/);
  const message = {
    data: undefined,
    event: undefined,
    id: undefined,
    retry: undefined,
    comments: []
  };
  for (const line of lines) {
    const index = line.indexOf(":");
    const key = index === -1 ? line : line.slice(0, index);
    const value = index === -1 ? "" : line.slice(index + 1).replace(/^\s/, "");
    if (index === 0) {
      message.comments.push(value);
    } else if (key === "data") {
      message.data ??= "";
      message.data += `${value}
`;
    } else if (key === "event") {
      message.event = value;
    } else if (key === "id") {
      message.id = value;
    } else if (key === "retry") {
      const maybeInteger = Number.parseInt(value);
      if (Number.isInteger(maybeInteger) && maybeInteger >= 0 && maybeInteger.toString() === value) {
        message.retry = maybeInteger;
      }
    }
  }
  message.data = message.data?.replace(/\n$/, "");
  return message;
}

class EventDecoder {
  constructor(options = {}) {
    this.options = options;
  }
  incomplete = "";
  feed(chunk) {
    this.incomplete += chunk;
    const lastCompleteIndex = this.incomplete.lastIndexOf(`

`);
    if (lastCompleteIndex === -1) {
      return;
    }
    const completes = this.incomplete.slice(0, lastCompleteIndex).split(/\n\n/);
    this.incomplete = this.incomplete.slice(lastCompleteIndex + 2);
    for (const encoded of completes) {
      const message = decodeEventMessage(`${encoded}

`);
      if (this.options.onEvent) {
        this.options.onEvent(message);
      }
    }
  }
  end() {
    if (this.incomplete) {
      throw new EventDecoderError("Event Iterator ended before complete");
    }
  }
}

class EventDecoderStream extends TransformStream {
  constructor() {
    let decoder;
    super({
      start(controller) {
        decoder = new EventDecoder({
          onEvent: (event) => {
            controller.enqueue(event);
          }
        });
      },
      transform(chunk) {
        decoder.feed(chunk);
      },
      flush() {
        decoder.end();
      }
    });
  }
}
function assertEventId(id) {
  if (id.includes(`
`)) {
    throw new EventEncoderError("Event's id must not contain a newline character");
  }
}
function assertEventName(event) {
  if (event.includes(`
`)) {
    throw new EventEncoderError("Event's event must not contain a newline character");
  }
}
function assertEventRetry(retry) {
  if (!Number.isInteger(retry) || retry < 0) {
    throw new EventEncoderError("Event's retry must be a integer and >= 0");
  }
}
function assertEventComment(comment) {
  if (comment.includes(`
`)) {
    throw new EventEncoderError("Event's comment must not contain a newline character");
  }
}
function encodeEventData(data) {
  const lines = data?.split(/\n/) ?? [];
  let output = "";
  for (const line of lines) {
    output += `data: ${line}
`;
  }
  return output;
}
function encodeEventComments(comments) {
  let output = "";
  for (const comment of comments ?? []) {
    assertEventComment(comment);
    output += `: ${comment}
`;
  }
  return output;
}
function encodeEventMessage(message) {
  let output = "";
  output += encodeEventComments(message.comments);
  if (message.event !== undefined) {
    assertEventName(message.event);
    output += `event: ${message.event}
`;
  }
  if (message.retry !== undefined) {
    assertEventRetry(message.retry);
    output += `retry: ${message.retry}
`;
  }
  if (message.id !== undefined) {
    assertEventId(message.id);
    output += `id: ${message.id}
`;
  }
  output += encodeEventData(message.data);
  output += `
`;
  return output;
}
var EVENT_SOURCE_META_SYMBOL = Symbol("ORPC_EVENT_SOURCE_META");
function withEventMeta(container, meta) {
  if (meta.id === undefined && meta.retry === undefined && !meta.comments?.length) {
    return container;
  }
  if (meta.id !== undefined) {
    assertEventId(meta.id);
  }
  if (meta.retry !== undefined) {
    assertEventRetry(meta.retry);
  }
  if (meta.comments !== undefined) {
    for (const comment of meta.comments) {
      assertEventComment(comment);
    }
  }
  return new Proxy(container, {
    get(target, prop, receiver) {
      if (prop === EVENT_SOURCE_META_SYMBOL) {
        return meta;
      }
      return Reflect.get(target, prop, receiver);
    }
  });
}
function getEventMeta(container) {
  return isTypescriptObject(container) ? Reflect.get(container, EVENT_SOURCE_META_SYMBOL) : undefined;
}

class HibernationEventIterator extends AsyncIteratorClass {
  hibernationCallback;
  constructor(hibernationCallback) {
    super(async () => {
      throw new Error("Cannot iterate over hibernating iterator directly");
    }, async (reason) => {
      if (reason !== "next") {
        throw new Error("Cannot cleanup hibernating iterator directly");
      }
    });
    this.hibernationCallback = hibernationCallback;
  }
}
function generateContentDisposition(filename, disposition = "inline") {
  const encodedFileName = filename.replace(/[^\x20-\x7E]/g, "_").replace(/"/g, "\\\"");
  const encodedFilenameStar = encodeURIComponent(filename).replace(/['()*]/g, (c) => `%${c.charCodeAt(0).toString(16).toUpperCase()}`).replace(/%(7C|60|5E)/g, (str, hex) => String.fromCharCode(Number.parseInt(hex, 16)));
  return `${disposition}; filename="${encodedFileName}"; filename*=utf-8''${encodedFilenameStar}`;
}
function getFilenameFromContentDisposition(contentDisposition) {
  const encodedFilenameStarMatch = contentDisposition.match(/filename\*=(UTF-8'')?([^;]*)/i);
  if (encodedFilenameStarMatch && typeof encodedFilenameStarMatch[2] === "string") {
    return tryDecodeURIComponent2(encodedFilenameStarMatch[2]);
  }
  const encodedFilenameMatch = contentDisposition.match(/filename="((?:\\"|[^"])*)"/i);
  if (encodedFilenameMatch && typeof encodedFilenameMatch[1] === "string") {
    return encodedFilenameMatch[1].replace(/\\"/g, '"');
  }
}
function flattenHeader(header) {
  if (typeof header === "string" || header === undefined) {
    return header;
  }
  if (header.length === 0) {
    return;
  }
  return header.join(", ");
}

// node_modules/.bun/@orpc+client@1.14.7/node_modules/@orpc/client/dist/shared/client.BLtwTQUg.mjs
function mapEventIterator(iterator, maps) {
  const mapError = async (error) => {
    let mappedError = await maps.error(error);
    if (mappedError !== error) {
      const meta = getEventMeta(error);
      if (meta && isTypescriptObject(mappedError)) {
        mappedError = withEventMeta(mappedError, meta);
      }
    }
    return mappedError;
  };
  return new AsyncIteratorClass(async () => {
    const { done, value } = await (async () => {
      try {
        return await iterator.next();
      } catch (error) {
        throw await mapError(error);
      }
    })();
    let mappedValue = await maps.value(value, done);
    if (mappedValue !== value) {
      const meta = getEventMeta(value);
      if (meta && isTypescriptObject(mappedValue)) {
        mappedValue = withEventMeta(mappedValue, meta);
      }
    }
    return { done, value: mappedValue };
  }, async () => {
    try {
      await iterator.return?.();
    } catch (error) {
      throw await mapError(error);
    }
  });
}
// node_modules/.bun/@orpc+contract@1.14.7/node_modules/@orpc/contract/dist/shared/contract.D_dZrO__.mjs
class ValidationError extends Error {
  issues;
  data;
  constructor(options) {
    super(options.message, options);
    this.issues = options.issues;
    this.data = options.data;
  }
}
function mergeErrorMap(errorMap1, errorMap2) {
  return { ...errorMap1, ...errorMap2 };
}
async function validateORPCError(map, error) {
  const { code, status, message, data, cause, defined } = error;
  const config = map?.[error.code];
  if (!config || fallbackORPCErrorStatus(error.code, config.status) !== error.status) {
    return defined ? new ORPCError(code, { defined: false, status, message, data, cause }) : error;
  }
  if (!config.data) {
    return defined ? error : new ORPCError(code, { defined: true, status, message, data, cause });
  }
  const validated = await config.data["~standard"].validate(error.data);
  if (validated.issues) {
    return defined ? new ORPCError(code, { defined: false, status, message, data, cause }) : error;
  }
  return new ORPCError(code, { defined: true, status, message, data: validated.value, cause });
}

class ContractProcedure {
  "~orpc";
  constructor(def) {
    if (def.route?.successStatus && isORPCErrorStatus(def.route.successStatus)) {
      throw new Error("[ContractProcedure] Invalid successStatus.");
    }
    if (Object.values(def.errorMap).some((val) => val && val.status && !isORPCErrorStatus(val.status))) {
      throw new Error("[ContractProcedure] Invalid error status code.");
    }
    this["~orpc"] = def;
  }
}
function isContractProcedure(item) {
  if (item instanceof ContractProcedure) {
    return true;
  }
  return (typeof item === "object" || typeof item === "function") && item !== null && "~orpc" in item && typeof item["~orpc"] === "object" && item["~orpc"] !== null && "errorMap" in item["~orpc"] && "route" in item["~orpc"] && "meta" in item["~orpc"];
}
// node_modules/.bun/@orpc+standard-server-fetch@1.14.7/node_modules/@orpc/standard-server-fetch/dist/index.mjs
function toEventIterator(stream, options = {}) {
  const eventStream = stream?.pipeThrough(new TextDecoderStream).pipeThrough(new EventDecoderStream);
  const reader = eventStream?.getReader();
  let span;
  let isCancelled = false;
  return new AsyncIteratorClass(async () => {
    span ??= startSpan("consume_event_iterator_stream");
    try {
      while (true) {
        if (reader === undefined) {
          return { done: true, value: undefined };
        }
        const { done, value } = await runInSpanContext(span, () => reader.read());
        if (done) {
          if (isCancelled) {
            throw new AbortError("Stream was cancelled");
          }
          return { done: true, value: undefined };
        }
        switch (value.event) {
          case "message": {
            let message = parseEmptyableJSON(value.data);
            if (isTypescriptObject(message)) {
              message = withEventMeta(message, value);
            }
            span?.addEvent("message");
            return { done: false, value: message };
          }
          case "error": {
            let error = new ErrorEvent2({
              data: parseEmptyableJSON(value.data)
            });
            error = withEventMeta(error, value);
            span?.addEvent("error");
            throw error;
          }
          case "done": {
            let done2 = parseEmptyableJSON(value.data);
            if (isTypescriptObject(done2)) {
              done2 = withEventMeta(done2, value);
            }
            span?.addEvent("done");
            return { done: true, value: done2 };
          }
          default: {
            span?.addEvent("maybe_keepalive");
          }
        }
      }
    } catch (e) {
      if (!(e instanceof ErrorEvent2)) {
        setSpanError(span, e, options);
      }
      throw e;
    }
  }, async (reason) => {
    try {
      if (reason !== "next") {
        isCancelled = true;
        span?.addEvent("cancelled");
      }
      await runInSpanContext(span, () => reader?.cancel());
    } catch (e) {
      setSpanError(span, e, options);
      throw e;
    } finally {
      span?.end();
    }
  });
}
function toEventStream(iterator, options = {}) {
  const keepAliveEnabled = options.eventIteratorKeepAliveEnabled ?? true;
  const keepAliveInterval = options.eventIteratorKeepAliveInterval ?? 5000;
  const keepAliveComment = options.eventIteratorKeepAliveComment ?? "";
  const initialCommentEnabled = options.eventIteratorInitialCommentEnabled ?? true;
  const initialComment = options.eventIteratorInitialComment ?? "";
  let cancelled = false;
  let timeout;
  let span;
  const stream = new ReadableStream({
    start(controller) {
      span = startSpan("stream_event_iterator");
      if (initialCommentEnabled) {
        controller.enqueue(encodeEventMessage({
          comments: [initialComment]
        }));
      }
    },
    async pull(controller) {
      try {
        if (keepAliveEnabled) {
          timeout = setInterval(() => {
            controller.enqueue(encodeEventMessage({
              comments: [keepAliveComment]
            }));
            span?.addEvent("keepalive");
          }, keepAliveInterval);
        }
        const value = await runInSpanContext(span, () => iterator.next());
        clearInterval(timeout);
        if (cancelled) {
          return;
        }
        const meta = getEventMeta(value.value);
        if (!value.done || value.value !== undefined || meta !== undefined) {
          const event = value.done ? "done" : "message";
          controller.enqueue(encodeEventMessage({
            ...meta,
            event,
            data: stringifyJSON(value.value)
          }));
          span?.addEvent(event);
        }
        if (value.done) {
          controller.close();
          span?.end();
        }
      } catch (err) {
        clearInterval(timeout);
        if (cancelled) {
          return;
        }
        if (err instanceof ErrorEvent2) {
          controller.enqueue(encodeEventMessage({
            ...getEventMeta(err),
            event: "error",
            data: stringifyJSON(err.data)
          }));
          span?.addEvent("error");
          controller.close();
        } else {
          setSpanError(span, err);
          controller.error(err);
        }
        span?.end();
      }
    },
    async cancel() {
      try {
        cancelled = true;
        clearInterval(timeout);
        span?.addEvent("cancelled");
        await runInSpanContext(span, () => iterator.return?.());
      } catch (e) {
        setSpanError(span, e);
        throw e;
      } finally {
        span?.end();
      }
    }
  }).pipeThrough(new TextEncoderStream);
  return stream;
}
function toStandardBody(re, options = {}) {
  return runWithSpan({ name: "parse_standard_body", signal: options.signal }, async () => {
    const contentDisposition = re.headers.get("content-disposition");
    if (typeof contentDisposition === "string") {
      const fileName = getFilenameFromContentDisposition(contentDisposition) ?? "blob";
      const blob2 = await re.blob();
      return new File([blob2], fileName, {
        type: blob2.type
      });
    }
    const contentType = re.headers.get("content-type");
    if (!contentType || contentType.startsWith("application/json")) {
      const text = await re.text();
      return parseEmptyableJSON(text);
    }
    if (contentType.startsWith("multipart/form-data")) {
      return await re.formData();
    }
    if (contentType.startsWith("application/x-www-form-urlencoded")) {
      const text = await re.text();
      return new URLSearchParams(text);
    }
    if (contentType.startsWith("text/event-stream")) {
      return toEventIterator(re.body, options);
    }
    if (contentType.startsWith("text/plain")) {
      return await re.text();
    }
    const blob = await re.blob();
    return new File([blob], "blob", {
      type: blob.type
    });
  });
}
function toFetchBody(body, headers, options = {}) {
  if (body instanceof ReadableStream) {
    return body;
  }
  const currentContentDisposition = headers.get("content-disposition");
  headers.delete("content-type");
  headers.delete("content-disposition");
  if (body === undefined) {
    return;
  }
  if (body instanceof Blob) {
    headers.set("content-type", body.type);
    headers.set("content-length", body.size.toString());
    headers.set("content-disposition", currentContentDisposition ?? generateContentDisposition(body instanceof File ? body.name : "blob"));
    return body;
  }
  if (body instanceof FormData) {
    return body;
  }
  if (body instanceof URLSearchParams) {
    return body;
  }
  if (isAsyncIteratorObject(body)) {
    headers.set("content-type", "text/event-stream");
    return toEventStream(body, options);
  }
  headers.set("content-type", "application/json");
  return stringifyJSON(body);
}
function toStandardHeaders(headers, standardHeaders = {}) {
  headers.forEach((value, key) => {
    if (Array.isArray(standardHeaders[key])) {
      standardHeaders[key].push(value);
    } else if (standardHeaders[key] !== undefined) {
      standardHeaders[key] = [standardHeaders[key], value];
    } else {
      standardHeaders[key] = value;
    }
  });
  return standardHeaders;
}
function toFetchHeaders(headers, fetchHeaders = new Headers) {
  for (const [key, value] of Object.entries(headers)) {
    if (Array.isArray(value)) {
      for (const v of value) {
        fetchHeaders.append(key, v);
      }
    } else if (value !== undefined) {
      fetchHeaders.append(key, value);
    }
  }
  return fetchHeaders;
}
function toStandardLazyRequest(request) {
  return {
    url: new URL(request.url),
    signal: request.signal,
    method: request.method,
    body: once(() => toStandardBody(request, { signal: request.signal })),
    get headers() {
      const headers = toStandardHeaders(request.headers);
      Object.defineProperty(this, "headers", { value: headers, writable: true });
      return headers;
    },
    set headers(value) {
      Object.defineProperty(this, "headers", { value, writable: true });
    }
  };
}
function toFetchResponse(response, options = {}) {
  const headers = toFetchHeaders(response.headers);
  const body = toFetchBody(response.body, headers, options);
  return new Response(body, { headers, status: response.status });
}

// node_modules/.bun/@orpc+client@1.14.7/node_modules/@orpc/client/dist/shared/client.WEeVKeV_.mjs
var STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES = {
  BIGINT: 0,
  DATE: 1,
  NAN: 2,
  UNDEFINED: 3,
  URL: 4,
  REGEXP: 5,
  SET: 6,
  MAP: 7
};

class StandardRPCJsonSerializer {
  customSerializers;
  constructor(options = {}) {
    this.customSerializers = options.customJsonSerializers ?? [];
    if (this.customSerializers.length !== new Set(this.customSerializers.map((custom) => custom.type)).size) {
      throw new Error("Custom serializer type must be unique.");
    }
  }
  serialize(data, segments = [], meta = [], maps = [], blobs = []) {
    for (const custom of this.customSerializers) {
      if (custom.condition(data)) {
        const result = this.serialize(custom.serialize(data), segments, meta, maps, blobs);
        meta.push([custom.type, ...segments]);
        return result;
      }
    }
    if (data instanceof Blob) {
      maps.push(segments);
      blobs.push(data);
      return [data, meta, maps, blobs];
    }
    if (typeof data === "bigint") {
      meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.BIGINT, ...segments]);
      return [data.toString(), meta, maps, blobs];
    }
    if (data instanceof Date) {
      meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.DATE, ...segments]);
      if (Number.isNaN(data.getTime())) {
        return [null, meta, maps, blobs];
      }
      return [data.toISOString(), meta, maps, blobs];
    }
    if (Number.isNaN(data)) {
      meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.NAN, ...segments]);
      return [null, meta, maps, blobs];
    }
    if (data instanceof URL) {
      meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.URL, ...segments]);
      return [data.toString(), meta, maps, blobs];
    }
    if (data instanceof RegExp) {
      meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.REGEXP, ...segments]);
      return [data.toString(), meta, maps, blobs];
    }
    if (data instanceof Set) {
      const result = this.serialize(Array.from(data), segments, meta, maps, blobs);
      meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.SET, ...segments]);
      return result;
    }
    if (data instanceof Map) {
      const result = this.serialize(Array.from(data.entries()), segments, meta, maps, blobs);
      meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.MAP, ...segments]);
      return result;
    }
    if (Array.isArray(data)) {
      const json = data.map((v, i) => {
        if (v === undefined) {
          meta.push([STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.UNDEFINED, ...segments, i]);
          return null;
        }
        return this.serialize(v, [...segments, i], meta, maps, blobs)[0];
      });
      return [json, meta, maps, blobs];
    }
    if (isObject(data)) {
      const json = {};
      for (const k in data) {
        if (k === "toJSON" && typeof data[k] === "function") {
          continue;
        }
        json[k] = this.serialize(data[k], [...segments, k], meta, maps, blobs)[0];
      }
      return [json, meta, maps, blobs];
    }
    return [data, meta, maps, blobs];
  }
  deserialize(json, meta, maps, getBlob) {
    const ref = { data: json };
    if (maps && getBlob) {
      maps.forEach((segments, i) => {
        let currentRef = ref;
        let preSegment = "data";
        segments.forEach((segment) => {
          currentRef = currentRef[preSegment];
          preSegment = segment;
          if (!Object.hasOwn(currentRef, preSegment)) {
            throw new Error(`Security error: accessing non-existent path during deserialization. Path segment: ${preSegment}`);
          }
        });
        currentRef[preSegment] = getBlob(i);
      });
    }
    for (const item of meta) {
      const type = item[0];
      let currentRef = ref;
      let preSegment = "data";
      for (let i = 1;i < item.length; i++) {
        currentRef = currentRef[preSegment];
        preSegment = item[i];
        if (!Object.hasOwn(currentRef, preSegment)) {
          throw new Error(`Security error: accessing non-existent path during deserialization. Path segment: ${preSegment}`);
        }
      }
      for (const custom of this.customSerializers) {
        if (custom.type === type) {
          currentRef[preSegment] = custom.deserialize(currentRef[preSegment]);
          break;
        }
      }
      switch (type) {
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.BIGINT:
          currentRef[preSegment] = BigInt(currentRef[preSegment]);
          break;
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.DATE:
          currentRef[preSegment] = new Date(currentRef[preSegment] ?? "Invalid Date");
          break;
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.NAN:
          currentRef[preSegment] = Number.NaN;
          break;
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.UNDEFINED:
          currentRef[preSegment] = undefined;
          break;
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.URL:
          currentRef[preSegment] = new URL(currentRef[preSegment]);
          break;
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.REGEXP: {
          const [, pattern, flags] = currentRef[preSegment].match(/^\/(.*)\/([a-z]*)$/);
          currentRef[preSegment] = new RegExp(pattern, flags);
          break;
        }
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.SET:
          currentRef[preSegment] = new Set(currentRef[preSegment]);
          break;
        case STANDARD_RPC_JSON_SERIALIZER_BUILT_IN_TYPES.MAP:
          currentRef[preSegment] = new Map(currentRef[preSegment]);
          break;
      }
    }
    return ref.data;
  }
}
function toHttpPath(path) {
  return `/${path.map(encodeURIComponent).join("/")}`;
}
class StandardRPCSerializer {
  constructor(jsonSerializer) {
    this.jsonSerializer = jsonSerializer;
  }
  serialize(data) {
    if (isAsyncIteratorObject(data)) {
      return mapEventIterator(data, {
        value: async (value) => this.#serialize(value, false),
        error: async (e) => {
          return new ErrorEvent2({
            data: this.#serialize(toORPCError(e).toJSON(), false),
            cause: e
          });
        }
      });
    }
    return this.#serialize(data, true);
  }
  #serialize(data, enableFormData) {
    const [json, meta_, maps, blobs] = this.jsonSerializer.serialize(data);
    const meta = meta_.length === 0 ? undefined : meta_;
    if (!enableFormData || blobs.length === 0) {
      return {
        json,
        meta
      };
    }
    const form = new FormData;
    form.set("data", stringifyJSON({ json, meta, maps }));
    blobs.forEach((blob, i) => {
      form.set(i.toString(), blob);
    });
    return form;
  }
  deserialize(data) {
    if (isAsyncIteratorObject(data)) {
      return mapEventIterator(data, {
        value: async (value) => this.#deserialize(value),
        error: async (e) => {
          if (!(e instanceof ErrorEvent2)) {
            return e;
          }
          const deserialized = this.#deserialize(e.data);
          if (isORPCErrorJson(deserialized)) {
            return createORPCErrorFromJson(deserialized, { cause: e });
          }
          return new ErrorEvent2({
            data: deserialized,
            cause: e
          });
        }
      });
    }
    return this.#deserialize(data);
  }
  #deserialize(data) {
    if (data === undefined) {
      return;
    }
    if (!(data instanceof FormData)) {
      return this.jsonSerializer.deserialize(data.json, data.meta ?? []);
    }
    const serialized = JSON.parse(data.get("data"));
    return this.jsonSerializer.deserialize(serialized.json, serialized.meta ?? [], serialized.maps, (i) => data.get(i.toString()));
  }
}
// node_modules/.bun/@orpc+contract@1.14.7/node_modules/@orpc/contract/dist/index.mjs
function mergeMeta(meta1, meta2) {
  return { ...meta1, ...meta2 };
}
function mergeRoute(a, b) {
  return { ...a, ...b };
}
function prefixRoute(route, prefix) {
  if (!route.path) {
    return route;
  }
  return {
    ...route,
    path: `${prefix}${route.path}`
  };
}
function unshiftTagRoute(route, tags) {
  return {
    ...route,
    tags: [...tags, ...route.tags ?? []]
  };
}
function mergePrefix(a, b) {
  return a ? `${a}${b}` : b;
}
function mergeTags(a, b) {
  return a ? [...a, ...b] : b;
}
function enhanceRoute(route, options) {
  let router = route;
  if (options.prefix) {
    router = prefixRoute(router, options.prefix);
  }
  if (options.tags?.length) {
    router = unshiftTagRoute(router, options.tags);
  }
  return router;
}
function enhanceContractRouter(router, options) {
  if (isContractProcedure(router)) {
    const enhanced2 = new ContractProcedure({
      ...router["~orpc"],
      errorMap: mergeErrorMap(options.errorMap, router["~orpc"].errorMap),
      route: enhanceRoute(router["~orpc"].route, options)
    });
    return enhanced2;
  }
  if (typeof router !== "object" || router === null) {
    return router;
  }
  const enhanced = {};
  for (const key in router) {
    enhanced[key] = enhanceContractRouter(router[key], options);
  }
  return enhanced;
}
class ContractBuilder extends ContractProcedure {
  constructor(def) {
    super(def);
    this["~orpc"].prefix = def.prefix;
    this["~orpc"].tags = def.tags;
  }
  $meta(initialMeta) {
    return new ContractBuilder({
      ...this["~orpc"],
      meta: initialMeta
    });
  }
  $route(initialRoute) {
    return new ContractBuilder({
      ...this["~orpc"],
      route: initialRoute
    });
  }
  $input(initialInputSchema) {
    return new ContractBuilder({
      ...this["~orpc"],
      inputSchema: initialInputSchema
    });
  }
  errors(errors) {
    return new ContractBuilder({
      ...this["~orpc"],
      errorMap: mergeErrorMap(this["~orpc"].errorMap, errors)
    });
  }
  meta(meta) {
    return new ContractBuilder({
      ...this["~orpc"],
      meta: mergeMeta(this["~orpc"].meta, meta)
    });
  }
  route(route) {
    return new ContractBuilder({
      ...this["~orpc"],
      route: mergeRoute(this["~orpc"].route, route)
    });
  }
  input(schema) {
    return new ContractBuilder({
      ...this["~orpc"],
      inputSchema: schema
    });
  }
  output(schema) {
    return new ContractBuilder({
      ...this["~orpc"],
      outputSchema: schema
    });
  }
  prefix(prefix) {
    return new ContractBuilder({
      ...this["~orpc"],
      prefix: mergePrefix(this["~orpc"].prefix, prefix)
    });
  }
  tag(...tags) {
    return new ContractBuilder({
      ...this["~orpc"],
      tags: mergeTags(this["~orpc"].tags, tags)
    });
  }
  router(router) {
    return enhanceContractRouter(router, this["~orpc"]);
  }
}
var oc = new ContractBuilder({
  errorMap: {},
  route: {},
  meta: {}
});
var DEFAULT_CONFIG = {
  defaultMethod: "POST",
  defaultSuccessStatus: 200,
  defaultSuccessDescription: "OK",
  defaultInputStructure: "compact",
  defaultOutputStructure: "compact"
};
function fallbackContractConfig(key, value) {
  if (value === undefined) {
    return DEFAULT_CONFIG[key];
  }
  return value;
}
var EVENT_ITERATOR_DETAILS_SYMBOL = Symbol("ORPC_EVENT_ITERATOR_DETAILS");

// node_modules/.bun/@orpc+server@1.14.7+4d1d9585513888ef/node_modules/@orpc/server/dist/shared/server.DEBcqOjg.mjs
var LAZY_SYMBOL = Symbol("ORPC_LAZY_SYMBOL");
function lazy(loader, meta = {}) {
  return {
    [LAZY_SYMBOL]: {
      loader,
      meta
    }
  };
}
function isLazy(item) {
  return (typeof item === "object" || typeof item === "function") && item !== null && LAZY_SYMBOL in item;
}
function getLazyMeta(lazied) {
  return lazied[LAZY_SYMBOL].meta;
}
function unlazy(lazied) {
  return isLazy(lazied) ? lazied[LAZY_SYMBOL].loader() : Promise.resolve({ default: lazied });
}
function isStartWithMiddlewares(middlewares, compare) {
  if (compare.length > middlewares.length) {
    return false;
  }
  for (let i = 0;i < middlewares.length; i++) {
    if (compare[i] === undefined) {
      return true;
    }
    if (middlewares[i] !== compare[i]) {
      return false;
    }
  }
  return true;
}
function mergeMiddlewares(first, second, options) {
  if (options.dedupeLeading && isStartWithMiddlewares(second, first)) {
    return second;
  }
  return [...first, ...second];
}
function addMiddleware(middlewares, addition) {
  return [...middlewares, addition];
}

class Procedure {
  "~orpc";
  constructor(def) {
    this["~orpc"] = def;
  }
}
function isProcedure(item) {
  if (item instanceof Procedure) {
    return true;
  }
  return isContractProcedure(item) && "middlewares" in item["~orpc"] && "inputValidationIndex" in item["~orpc"] && "outputValidationIndex" in item["~orpc"] && "handler" in item["~orpc"];
}
function mergeCurrentContext(context, other) {
  return { ...context, ...other };
}
function createORPCErrorConstructorMap(errors) {
  const proxy = new Proxy(errors, {
    get(target, code) {
      if (typeof code !== "string") {
        return Reflect.get(target, code);
      }
      const item = (...rest) => {
        const options = resolveMaybeOptionalOptions(rest);
        const config = errors[code];
        return new ORPCError(code, {
          defined: Boolean(config),
          status: config?.status,
          message: options.message ?? config?.message,
          data: options.data,
          cause: options.cause
        });
      };
      return item;
    }
  });
  return proxy;
}
function middlewareOutputFn(output) {
  return { output, context: {} };
}
function createProcedureClient(lazyableProcedure, ...rest) {
  const options = resolveMaybeOptionalOptions(rest);
  return async (...[input, callerOptions]) => {
    const path = toArray(options.path);
    const { default: procedure } = await unlazy(lazyableProcedure);
    const clientContext = callerOptions?.context ?? {};
    const context = await value(options.context ?? {}, clientContext);
    const errors = createORPCErrorConstructorMap(procedure["~orpc"].errorMap);
    const validateError = async (e) => {
      if (e instanceof ORPCError) {
        return await validateORPCError(procedure["~orpc"].errorMap, e);
      }
      return e;
    };
    try {
      const output = await runWithSpan({ name: "call_procedure", signal: callerOptions?.signal }, (span) => {
        span?.setAttribute("procedure.path", [...path]);
        return intercept(toArray(options.interceptors), {
          context,
          input,
          errors,
          path,
          procedure,
          signal: callerOptions?.signal,
          lastEventId: callerOptions?.lastEventId
        }, (interceptorOptions) => executeProcedureInternal(interceptorOptions.procedure, interceptorOptions));
      });
      if (isAsyncIteratorObject(output)) {
        if (output instanceof HibernationEventIterator) {
          return output;
        }
        return overlayProxy(output, mapEventIterator(asyncIteratorWithSpan({ name: "consume_event_iterator_output", signal: callerOptions?.signal }, output), {
          value: (v) => v,
          error: (e) => validateError(e)
        }));
      }
      return output;
    } catch (e) {
      throw await validateError(e);
    }
  };
}
async function validateInput(procedure, input) {
  const schema = procedure["~orpc"].inputSchema;
  if (!schema) {
    return input;
  }
  return runWithSpan({ name: "validate_input" }, async () => {
    const result = await schema["~standard"].validate(input);
    if (result.issues) {
      throw new ORPCError("BAD_REQUEST", {
        message: "Input validation failed",
        data: {
          issues: result.issues
        },
        cause: new ValidationError({
          message: "Input validation failed",
          issues: result.issues,
          data: input
        })
      });
    }
    return result.value;
  });
}
async function validateOutput(procedure, output) {
  const schema = procedure["~orpc"].outputSchema;
  if (!schema) {
    return output;
  }
  return runWithSpan({ name: "validate_output" }, async () => {
    const result = await schema["~standard"].validate(output);
    if (result.issues) {
      throw new ORPCError("INTERNAL_SERVER_ERROR", {
        message: "Output validation failed",
        cause: new ValidationError({
          message: "Output validation failed",
          issues: result.issues,
          data: output
        })
      });
    }
    return result.value;
  });
}
async function executeProcedureInternal(procedure, options) {
  const middlewares = procedure["~orpc"].middlewares;
  const inputValidationIndex = Math.min(Math.max(0, procedure["~orpc"].inputValidationIndex), middlewares.length);
  const outputValidationIndex = Math.min(Math.max(0, procedure["~orpc"].outputValidationIndex), middlewares.length);
  const next = async (index, context, input) => {
    let currentInput = input;
    if (index === inputValidationIndex) {
      currentInput = await validateInput(procedure, currentInput);
    }
    const mid = middlewares[index];
    const output = mid ? await runWithSpan({ name: `middleware.${mid.name}`, signal: options.signal }, async (span) => {
      span?.setAttribute("middleware.index", index);
      span?.setAttribute("middleware.name", mid.name);
      const result = await mid({
        ...options,
        context,
        next: async (...[nextOptions]) => {
          const nextContext = nextOptions?.context ?? {};
          return {
            output: await next(index + 1, mergeCurrentContext(context, nextContext), currentInput),
            context: nextContext
          };
        }
      }, currentInput, middlewareOutputFn);
      return result.output;
    }) : await runWithSpan({ name: "handler", signal: options.signal }, () => procedure["~orpc"].handler({ ...options, context, input: currentInput }));
    if (index === outputValidationIndex) {
      return await validateOutput(procedure, output);
    }
    return output;
  };
  return next(0, options.context, options.input);
}
var HIDDEN_ROUTER_CONTRACT_SYMBOL = Symbol("ORPC_HIDDEN_ROUTER_CONTRACT");
function getHiddenRouterContract(router) {
  return router[HIDDEN_ROUTER_CONTRACT_SYMBOL];
}
function getRouter(router, path) {
  let current = router;
  for (let i = 0;i < path.length; i++) {
    const segment = path[i];
    if (!current) {
      return;
    }
    if (isProcedure(current)) {
      return;
    }
    if (!isTypescriptObject(current)) {
      return;
    }
    if (!isLazy(current)) {
      current = current[segment];
      continue;
    }
    const lazied = current;
    const rest = path.slice(i);
    return lazy(async () => {
      const unwrapped = await unlazy(lazied);
      const next = getRouter(unwrapped.default, rest);
      return unlazy(next);
    }, getLazyMeta(lazied));
  }
  return current;
}
function createAccessibleLazyRouter(lazied) {
  const recursive = new Proxy(lazied, {
    get(target, key) {
      if (typeof key !== "string") {
        return Reflect.get(target, key);
      }
      const next = getRouter(lazied, [key]);
      return createAccessibleLazyRouter(next);
    }
  });
  return recursive;
}
function enhanceRouter(router, options) {
  if (isLazy(router)) {
    const laziedMeta = getLazyMeta(router);
    const enhancedPrefix = laziedMeta?.prefix ? mergePrefix(options.prefix, laziedMeta?.prefix) : options.prefix;
    const enhanced2 = lazy(async () => {
      const { default: unlaziedRouter } = await unlazy(router);
      const enhanced3 = enhanceRouter(unlaziedRouter, options);
      return unlazy(enhanced3);
    }, {
      ...laziedMeta,
      prefix: enhancedPrefix
    });
    const accessible = createAccessibleLazyRouter(enhanced2);
    return accessible;
  }
  if (isProcedure(router)) {
    const newMiddlewares = mergeMiddlewares(options.middlewares, router["~orpc"].middlewares, { dedupeLeading: options.dedupeLeadingMiddlewares });
    const newMiddlewareAdded = newMiddlewares.length - router["~orpc"].middlewares.length;
    const enhanced2 = new Procedure({
      ...router["~orpc"],
      route: enhanceRoute(router["~orpc"].route, options),
      errorMap: mergeErrorMap(options.errorMap, router["~orpc"].errorMap),
      middlewares: newMiddlewares,
      inputValidationIndex: router["~orpc"].inputValidationIndex + newMiddlewareAdded,
      outputValidationIndex: router["~orpc"].outputValidationIndex + newMiddlewareAdded
    });
    return enhanced2;
  }
  if (typeof router !== "object" || router === null) {
    return router;
  }
  const enhanced = {};
  for (const key in router) {
    enhanced[key] = enhanceRouter(router[key], options);
  }
  return enhanced;
}
function traverseContractProcedures(options, callback, lazyOptions = []) {
  let currentRouter = options.router;
  const hiddenContract = isTypescriptObject(options.router) ? getHiddenRouterContract(options.router) : undefined;
  if (hiddenContract !== undefined) {
    currentRouter = hiddenContract;
  }
  if (isLazy(currentRouter)) {
    lazyOptions.push({
      router: currentRouter,
      path: options.path
    });
  } else if (isContractProcedure(currentRouter)) {
    callback({
      contract: currentRouter,
      path: options.path
    });
  } else if (typeof currentRouter === "object" && currentRouter !== null) {
    for (const key in currentRouter) {
      traverseContractProcedures({
        router: currentRouter[key],
        path: [...options.path, key]
      }, callback, lazyOptions);
    }
  }
  return lazyOptions;
}
function createContractedProcedure(procedure, contract) {
  return new Procedure({
    ...procedure["~orpc"],
    errorMap: contract["~orpc"].errorMap,
    route: contract["~orpc"].route,
    meta: contract["~orpc"].meta
  });
}
// node_modules/.bun/@orpc+server@1.14.7+4d1d9585513888ef/node_modules/@orpc/server/dist/index.mjs
var DEFAULT_CONFIG2 = {
  initialInputValidationIndex: 0,
  initialOutputValidationIndex: 0,
  dedupeLeadingMiddlewares: true
};
function fallbackConfig(key, value) {
  if (value === undefined) {
    return DEFAULT_CONFIG2[key];
  }
  return value;
}
function decorateMiddleware(middleware) {
  const decorated = (...args) => middleware(...args);
  decorated.mapInput = (mapInput) => {
    const mapped = decorateMiddleware((options, input, ...rest) => middleware(options, mapInput(input), ...rest));
    return mapped;
  };
  decorated.concat = (concatMiddleware, mapInput) => {
    const mapped = mapInput ? decorateMiddleware(concatMiddleware).mapInput(mapInput) : concatMiddleware;
    const concatted = decorateMiddleware((options, input, output, ...rest) => {
      const merged = middleware({
        ...options,
        next: (...[nextOptions1]) => mapped({
          ...options,
          context: { ...options.context, ...nextOptions1?.context },
          next: (...[nextOptions2]) => options.next({ context: { ...nextOptions1?.context, ...nextOptions2?.context } })
        }, input, output, ...rest)
      }, input, output, ...rest);
      return merged;
    });
    return concatted;
  };
  return decorated;
}
function createActionableClient(client) {
  const action = async (input) => {
    try {
      return [null, await client(input)];
    } catch (error) {
      if (error instanceof Error && "digest" in error && typeof error.digest === "string" && error.digest.startsWith("NEXT_")) {
        throw error;
      }
      if (error instanceof Response && "options" in error && isObject(error.options) || isObject(error) && error.isNotFound === true) {
        throw error;
      }
      return [toORPCError(error).toJSON(), undefined];
    }
  };
  return action;
}

class DecoratedProcedure extends Procedure {
  errors(errors) {
    return new DecoratedProcedure({
      ...this["~orpc"],
      errorMap: mergeErrorMap(this["~orpc"].errorMap, errors)
    });
  }
  meta(meta) {
    return new DecoratedProcedure({
      ...this["~orpc"],
      meta: mergeMeta(this["~orpc"].meta, meta)
    });
  }
  route(route) {
    return new DecoratedProcedure({
      ...this["~orpc"],
      route: mergeRoute(this["~orpc"].route, route)
    });
  }
  use(middleware, mapInput) {
    const mapped = mapInput ? decorateMiddleware(middleware).mapInput(mapInput) : middleware;
    return new DecoratedProcedure({
      ...this["~orpc"],
      middlewares: addMiddleware(this["~orpc"].middlewares, mapped)
    });
  }
  callable(...rest) {
    const client = createProcedureClient(this, ...rest);
    return new Proxy(client, {
      get: (target, key) => {
        return Reflect.has(this, key) ? Reflect.get(this, key) : Reflect.get(target, key);
      },
      has: (target, key) => {
        return Reflect.has(this, key) || Reflect.has(target, key);
      }
    });
  }
  actionable(...rest) {
    const action = createActionableClient(createProcedureClient(this, ...rest));
    return new Proxy(action, {
      get: (target, key) => {
        return Reflect.has(this, key) ? Reflect.get(this, key) : Reflect.get(target, key);
      },
      has: (target, key) => {
        return Reflect.has(this, key) || Reflect.has(target, key);
      }
    });
  }
}

class Builder {
  "~orpc";
  constructor(def) {
    this["~orpc"] = def;
  }
  $config(config) {
    const inputValidationCount = this["~orpc"].inputValidationIndex - fallbackConfig("initialInputValidationIndex", this["~orpc"].config.initialInputValidationIndex);
    const outputValidationCount = this["~orpc"].outputValidationIndex - fallbackConfig("initialOutputValidationIndex", this["~orpc"].config.initialOutputValidationIndex);
    return new Builder({
      ...this["~orpc"],
      config,
      dedupeLeadingMiddlewares: fallbackConfig("dedupeLeadingMiddlewares", config.dedupeLeadingMiddlewares),
      inputValidationIndex: fallbackConfig("initialInputValidationIndex", config.initialInputValidationIndex) + inputValidationCount,
      outputValidationIndex: fallbackConfig("initialOutputValidationIndex", config.initialOutputValidationIndex) + outputValidationCount
    });
  }
  $context() {
    return new Builder({
      ...this["~orpc"],
      middlewares: [],
      inputValidationIndex: fallbackConfig("initialInputValidationIndex", this["~orpc"].config.initialInputValidationIndex),
      outputValidationIndex: fallbackConfig("initialOutputValidationIndex", this["~orpc"].config.initialOutputValidationIndex)
    });
  }
  $meta(initialMeta) {
    return new Builder({
      ...this["~orpc"],
      meta: initialMeta
    });
  }
  $route(initialRoute) {
    return new Builder({
      ...this["~orpc"],
      route: initialRoute
    });
  }
  $input(initialInputSchema) {
    return new Builder({
      ...this["~orpc"],
      inputSchema: initialInputSchema
    });
  }
  middleware(middleware) {
    return decorateMiddleware(middleware);
  }
  errors(errors) {
    return new Builder({
      ...this["~orpc"],
      errorMap: mergeErrorMap(this["~orpc"].errorMap, errors)
    });
  }
  use(middleware, mapInput) {
    const mapped = mapInput ? decorateMiddleware(middleware).mapInput(mapInput) : middleware;
    return new Builder({
      ...this["~orpc"],
      middlewares: addMiddleware(this["~orpc"].middlewares, mapped)
    });
  }
  meta(meta) {
    return new Builder({
      ...this["~orpc"],
      meta: mergeMeta(this["~orpc"].meta, meta)
    });
  }
  route(route) {
    return new Builder({
      ...this["~orpc"],
      route: mergeRoute(this["~orpc"].route, route)
    });
  }
  input(schema) {
    return new Builder({
      ...this["~orpc"],
      inputSchema: schema,
      inputValidationIndex: fallbackConfig("initialInputValidationIndex", this["~orpc"].config.initialInputValidationIndex) + this["~orpc"].middlewares.length
    });
  }
  output(schema) {
    return new Builder({
      ...this["~orpc"],
      outputSchema: schema,
      outputValidationIndex: fallbackConfig("initialOutputValidationIndex", this["~orpc"].config.initialOutputValidationIndex) + this["~orpc"].middlewares.length
    });
  }
  handler(handler) {
    return new DecoratedProcedure({
      ...this["~orpc"],
      handler
    });
  }
  prefix(prefix) {
    return new Builder({
      ...this["~orpc"],
      prefix: mergePrefix(this["~orpc"].prefix, prefix)
    });
  }
  tag(...tags) {
    return new Builder({
      ...this["~orpc"],
      tags: mergeTags(this["~orpc"].tags, tags)
    });
  }
  router(router) {
    return enhanceRouter(router, this["~orpc"]);
  }
  lazy(loader) {
    return enhanceRouter(lazy(loader), this["~orpc"]);
  }
}
var os = new Builder({
  config: {},
  route: {},
  meta: {},
  errorMap: {},
  inputValidationIndex: fallbackConfig("initialInputValidationIndex"),
  outputValidationIndex: fallbackConfig("initialOutputValidationIndex"),
  middlewares: [],
  dedupeLeadingMiddlewares: true
});

// node_modules/.bun/@orpc+server@1.14.7+4d1d9585513888ef/node_modules/@orpc/server/dist/shared/server.DZ5BIITo.mjs
function resolveFriendlyStandardHandleOptions(options) {
  return {
    ...options,
    context: options.context ?? {}
  };
}

// node_modules/.bun/@orpc+server@1.14.7+4d1d9585513888ef/node_modules/@orpc/server/dist/shared/server.ZxHCEN1h.mjs
class CompositeStandardHandlerPlugin {
  plugins;
  constructor(plugins = []) {
    this.plugins = [...plugins].sort((a, b) => (a.order ?? 0) - (b.order ?? 0));
  }
  init(options, router) {
    for (const plugin of this.plugins) {
      plugin.init?.(options, router);
    }
  }
}

class StandardHandler {
  constructor(router, matcher, codec, options) {
    this.matcher = matcher;
    this.codec = codec;
    const plugins = new CompositeStandardHandlerPlugin(options.plugins);
    plugins.init(options, router);
    this.interceptors = toArray(options.interceptors);
    this.clientInterceptors = toArray(options.clientInterceptors);
    this.rootInterceptors = toArray(options.rootInterceptors);
    this.matcher.init(router);
  }
  interceptors;
  clientInterceptors;
  rootInterceptors;
  async handle(request, options) {
    const prefix = options.prefix?.replace(/\/$/, "") || undefined;
    if (prefix && !request.url.pathname.startsWith(`${prefix}/`) && request.url.pathname !== prefix) {
      return { matched: false, response: undefined };
    }
    return intercept(this.rootInterceptors, { ...options, request, prefix }, async (interceptorOptions) => {
      return runWithSpan({ name: `${request.method} ${request.url.pathname}` }, async (span) => {
        let step;
        try {
          return await intercept(this.interceptors, interceptorOptions, async ({ request: request2, context, prefix: prefix2 }) => {
            const method = request2.method;
            const url = request2.url;
            const pathname = prefix2 ? url.pathname.replace(prefix2, "") : url.pathname;
            const match = await runWithSpan({ name: "find_procedure" }, () => this.matcher.match(method, `/${pathname.replace(/^\/|\/$/g, "")}`));
            if (!match) {
              return { matched: false, response: undefined };
            }
            span?.updateName(`${ORPC_NAME}.${match.path.join("/")}`);
            span?.setAttribute("rpc.system", ORPC_NAME);
            span?.setAttribute("rpc.method", match.path.join("."));
            step = "decode_input";
            let input = await runWithSpan({ name: "decode_input" }, () => this.codec.decode(request2, match.params, match.procedure));
            step = undefined;
            if (isAsyncIteratorObject(input)) {
              input = asyncIteratorWithSpan({ name: "consume_event_iterator_input", signal: request2.signal }, input);
            }
            const client = createProcedureClient(match.procedure, {
              context,
              path: match.path,
              interceptors: this.clientInterceptors
            });
            step = "call_procedure";
            const output = await client(input, {
              signal: request2.signal,
              lastEventId: flattenHeader(request2.headers["last-event-id"])
            });
            step = undefined;
            const response = this.codec.encode(output, match.procedure);
            return {
              matched: true,
              response
            };
          });
        } catch (e) {
          if (step !== "call_procedure") {
            setSpanError(span, e);
          }
          const error = step === "decode_input" && !(e instanceof ORPCError) ? new ORPCError("BAD_REQUEST", {
            message: `Malformed request. Ensure the request body is properly formatted and the 'Content-Type' header is set correctly.`,
            cause: e
          }) : toORPCError(e);
          const response = this.codec.encodeError(error);
          return {
            matched: true,
            response
          };
        }
      });
    });
  }
}

class StandardRPCCodec {
  constructor(serializer) {
    this.serializer = serializer;
  }
  async decode(request, _params, _procedure) {
    const serialized = request.method === "GET" ? parseEmptyableJSON(request.url.searchParams.getAll("data").at(-1)) : await request.body();
    return this.serializer.deserialize(serialized);
  }
  encode(output, _procedure) {
    if (output instanceof ReadableStream) {
      return {
        status: 200,
        headers: {},
        body: output
      };
    }
    return {
      status: 200,
      headers: {},
      body: this.serializer.serialize(output)
    };
  }
  encodeError(error) {
    return {
      status: error.status,
      headers: {},
      body: this.serializer.serialize(error.toJSON())
    };
  }
}

class StandardRPCMatcher {
  filter;
  tree = new NullProtoObj;
  pendingRouters = [];
  constructor(options = {}) {
    this.filter = options.filter ?? true;
  }
  init(router, path = []) {
    const laziedOptions = traverseContractProcedures({ router, path }, (traverseOptions) => {
      if (!value(this.filter, traverseOptions)) {
        return;
      }
      const { path: path2, contract } = traverseOptions;
      const httpPath = toHttpPath(path2);
      if (isProcedure(contract)) {
        this.tree[httpPath] = {
          path: path2,
          contract,
          procedure: contract,
          router
        };
      } else {
        this.tree[httpPath] = {
          path: path2,
          contract,
          procedure: undefined,
          router
        };
      }
    });
    this.pendingRouters.push(...laziedOptions.map((option) => ({
      ...option,
      httpPathPrefix: toHttpPath(option.path)
    })));
  }
  async match(_method, pathname) {
    if (this.pendingRouters.length) {
      const newPendingRouters = [];
      for (const pendingRouter of this.pendingRouters) {
        if (pathname.startsWith(pendingRouter.httpPathPrefix)) {
          const { default: router } = await unlazy(pendingRouter.router);
          this.init(router, pendingRouter.path);
        } else {
          newPendingRouters.push(pendingRouter);
        }
      }
      this.pendingRouters = newPendingRouters;
    }
    const match = this.tree[pathname];
    if (!match) {
      return;
    }
    if (!match.procedure) {
      const { default: maybeProcedure } = await unlazy(getRouter(match.router, match.path));
      if (!isProcedure(maybeProcedure)) {
        throw new Error(`
          [Contract-First] Missing or invalid implementation for procedure at path: ${toHttpPath(match.path)}.
          Ensure that the procedure is correctly defined and matches the expected contract.
        `);
      }
      match.procedure = createContractedProcedure(maybeProcedure, match.contract);
    }
    return {
      path: match.path,
      procedure: match.procedure
    };
  }
}

class StandardRPCHandler extends StandardHandler {
  constructor(router, options = {}) {
    const jsonSerializer = new StandardRPCJsonSerializer(options);
    const serializer = new StandardRPCSerializer(jsonSerializer);
    const matcher = new StandardRPCMatcher(options);
    const codec = new StandardRPCCodec(serializer);
    super(router, matcher, codec, options);
  }
}

// node_modules/.bun/@orpc+server@1.14.7+4d1d9585513888ef/node_modules/@orpc/server/dist/shared/server.TEVCLCFC.mjs
var STRICT_GET_METHOD_PLUGIN_IS_GET_METHOD_CONTEXT_SYMBOL = Symbol("STRICT_GET_METHOD_PLUGIN_IS_GET_METHOD_CONTEXT");

class StrictGetMethodPlugin {
  error;
  order = 7000000;
  constructor(options = {}) {
    this.error = options.error ?? new ORPCError("METHOD_NOT_SUPPORTED");
  }
  init(options) {
    options.rootInterceptors ??= [];
    options.clientInterceptors ??= [];
    options.rootInterceptors.unshift((options2) => {
      const isGetMethod = options2.request.method === "GET";
      return options2.next({
        ...options2,
        context: {
          ...options2.context,
          [STRICT_GET_METHOD_PLUGIN_IS_GET_METHOD_CONTEXT_SYMBOL]: isGetMethod
        }
      });
    });
    options.clientInterceptors.unshift((options2) => {
      if (typeof options2.context[STRICT_GET_METHOD_PLUGIN_IS_GET_METHOD_CONTEXT_SYMBOL] !== "boolean") {
        throw new TypeError("[StrictGetMethodPlugin] strict GET method context has been corrupted or modified by another plugin or interceptor");
      }
      const procedureMethod = fallbackContractConfig("defaultMethod", options2.procedure["~orpc"].route.method);
      if (options2.context[STRICT_GET_METHOD_PLUGIN_IS_GET_METHOD_CONTEXT_SYMBOL] && procedureMethod !== "GET") {
        throw this.error;
      }
      return options2.next();
    });
  }
}

// node_modules/.bun/@orpc+server@1.14.7+4d1d9585513888ef/node_modules/@orpc/server/dist/adapters/fetch/index.mjs
class CompositeFetchHandlerPlugin extends CompositeStandardHandlerPlugin {
  initRuntimeAdapter(options) {
    for (const plugin of this.plugins) {
      plugin.initRuntimeAdapter?.(options);
    }
  }
}

class FetchHandler {
  constructor(standardHandler, options = {}) {
    this.standardHandler = standardHandler;
    const plugin = new CompositeFetchHandlerPlugin(options.plugins);
    plugin.initRuntimeAdapter(options);
    this.adapterInterceptors = toArray(options.adapterInterceptors);
    this.toFetchResponseOptions = options;
  }
  toFetchResponseOptions;
  adapterInterceptors;
  async handle(request, ...rest) {
    return intercept(this.adapterInterceptors, {
      ...resolveFriendlyStandardHandleOptions(resolveMaybeOptionalOptions(rest)),
      request,
      toFetchResponseOptions: this.toFetchResponseOptions
    }, async ({ request: request2, toFetchResponseOptions, ...options }) => {
      const standardRequest = toStandardLazyRequest(request2);
      const result = await this.standardHandler.handle(standardRequest, options);
      if (!result.matched) {
        return result;
      }
      return {
        matched: true,
        response: toFetchResponse(result.response, toFetchResponseOptions)
      };
    });
  }
}

class RPCHandler extends FetchHandler {
  constructor(router, options = {}) {
    if (options.strictGetMethodPluginEnabled ?? true) {
      options.plugins ??= [];
      options.plugins.push(new StrictGetMethodPlugin);
    }
    super(new StandardRPCHandler(router, options), options);
  }
}

// packages/web/src/api/__core/app.ts
var base = os.$context();
function createApp(router) {
  const app = new Hono2().use(cors({
    origin: (origin) => origin ?? "*",
    credentials: true,
    exposeHeaders: ["set-auth-token"]
  }));
  app.get("/api/health", (c) => c.json({ status: "ok" }, 200));
  const handler = new RPCHandler(router);
  app.use("/api/rpc/*", async (c, next) => {
    const { matched, response } = await handler.handle(c.req.raw, {
      prefix: "/api/rpc",
      context: { headers: c.req.raw.headers }
    });
    if (matched)
      return c.newResponse(response.body, response);
    await next();
  });
  return app;
}

// packages/web/src/api/engine/boot.ts
init_store();
await init_scanner();

// packages/web/src/api/engine/feed-alerts.ts
await __promiseAll([
  init_po_feed(),
  init_telegram()
]);
var GRACE_MS = 180000;
var REPEAT_MS = 60 * 60000;
var CHECK_MS = 30000;
var scope = globalThis;
function stateOf() {
  scope.__poFeedAlerts ??= { timer: null, unwatch: null, downSince: 0, notifiedAt: 0 };
  return scope.__poFeedAlerts;
}
var clock = () => new Date().toLocaleTimeString("ru-RU", {
  hour: "2-digit",
  minute: "2-digit",
  timeZone: TZ2
});
var minutes = (ms) => Math.max(1, Math.round(ms / 60000));
function downMessage(note, downMs, repeat) {
  return [
    repeat ? "\uD83D\uDEA8 <b>Сессия Pocket Option всё ещё не работает</b>" : "\uD83D\uDEA8 <b>Сессия Pocket Option отвалилась</b>",
    `Брокер не отдаёт котировки уже ${minutes(downMs)} мин — сигналы не считаются.`,
    ...note ? [`Причина: ${note}`] : [],
    "",
    "<b>Что сделать:</b>",
    "1. Войти на pocketoption.com в том же браузере.",
    '2. DevTools → Network → WS → скопировать кадр <code>42["auth",{...}]</code> целиком.',
    "3. Обновить <code>POCKET_OPTION_SSID</code> и перезапустить бота.",
    "",
    `<i>${clock()} (Киев)</i>`
  ].join(`
`);
}
function upMessage(downMs) {
  return [
    "✅ <b>Фид Pocket Option снова работает</b>",
    `Простой: ${minutes(downMs)} мин. Сканирование продолжается.`,
    `<i>${clock()} (Киев)</i>`
  ].join(`
`);
}
async function notify(text) {
  const sent = await broadcast(text);
  console.warn(`[feed-alerts] оповещение отправлено в ${sent} чат(ов)`);
}
function check() {
  const st = stateOf();
  const feed = feedState();
  if (feed.state === "live" || feed.state === "idle")
    return;
  if (!st.downSince)
    st.downSince = Date.now();
  const downMs = Date.now() - st.downSince;
  const grace = feed.state === "unauthorized" ? 0 : GRACE_MS;
  if (!st.notifiedAt) {
    if (downMs < grace)
      return;
    st.notifiedAt = Date.now();
    notify(downMessage(feed.note, downMs, false));
    return;
  }
  if (Date.now() - st.notifiedAt >= REPEAT_MS) {
    st.notifiedAt = Date.now();
    notify(downMessage(feed.note, downMs, true));
  }
}
function onChange(change) {
  const st = stateOf();
  if (change.state === "live") {
    const downMs = st.downSince ? Date.now() - st.downSince : 0;
    const wasNotified = st.notifiedAt > 0;
    st.downSince = 0;
    st.notifiedAt = 0;
    if (wasNotified)
      notify(upMessage(downMs));
    return;
  }
  if (change.state === "idle") {
    st.downSince = 0;
    return;
  }
  if (!st.downSince)
    st.downSince = Date.now();
  if (change.state === "unauthorized")
    check();
}
function startFeedAlerts() {
  const st = stateOf();
  if (st.timer)
    clearInterval(st.timer);
  st.unwatch?.();
  st.unwatch = watchFeedState(onChange);
  st.timer = setInterval(check, CHECK_MS);
  console.log("[feed-alerts] следим за сессией Pocket Option");
}

// packages/web/src/api/engine/outcomes.ts
init_drizzle_orm();
init_database();
init_schema();
init_day();

// packages/web/src/api/market/history.ts
await __promiseAll([
  init_candles(),
  init_po_feed()
]);
var PERIOD = 60;
var CACHE_TTL_MS2 = 30000;
var BASE_BARS = 240;
var MAX_BARS = 900;
var cache3 = new Map;
function depthFor(at) {
  const minutesBack = Math.ceil((Date.now() / 1000 - at) / 60) + 30;
  return Math.min(MAX_BARS, Math.max(BASE_BARS, minutesBack));
}
async function minuteCandles(poSymbol, bars) {
  const cached = cache3.get(poSymbol);
  if (cached && cached.bars >= bars && Date.now() - cached.at < CACHE_TTL_MS2) {
    return { candles: cached.candles, source: "cache" };
  }
  let candles = [];
  let source = "";
  if (ssidLooksLikeCookie()) {
    try {
      candles = await poCandles(poSymbol, PERIOD, bars);
      source = "pocket-option";
    } catch (error) {
      if (isOtc(poSymbol))
        throw error;
    }
  }
  if (!candles.length) {
    const feedSymbol = toFeedSymbol(poSymbol);
    if (!feedSymbol)
      throw new Error(`${poSymbol}: минутных свечей нет — нужен фид PO`);
    candles = await fetchMinute(feedSymbol);
    source = "public-feed";
  }
  cache3.set(poSymbol, { at: Date.now(), candles, bars });
  return { candles, source };
}
async function fetchMinute(feedSymbol) {
  const url = `https://query1.finance.yahoo.com/v8/finance/chart/${encodeURIComponent(feedSymbol)}?interval=1m&range=2d`;
  const res = await fetch(url, {
    headers: {
      "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/127.0.0.0 Safari/537.36",
      Accept: "application/json"
    },
    signal: AbortSignal.timeout(12000)
  });
  if (!res.ok)
    throw new Error(`feed ${feedSymbol}: HTTP ${res.status}`);
  const json = await res.json();
  const result = json.chart?.result?.[0];
  const quote = result?.indicators?.quote?.[0];
  const ts = result?.timestamp;
  if (!ts || !quote)
    throw new Error(`feed ${feedSymbol}: пустой ответ`);
  const out = [];
  for (let i = 0;i < ts.length; i++) {
    const o = quote.open?.[i];
    const h = quote.high?.[i];
    const l = quote.low?.[i];
    const c = quote.close?.[i];
    if (o == null || h == null || l == null || c == null)
      continue;
    out.push({ time: ts[i], open: o, high: h, low: l, close: c });
  }
  return out.sort((a, b) => a.time - b.time);
}
async function priceAt(poSymbol, at) {
  const { candles, source } = await minuteCandles(poSymbol, depthFor(at));
  if (!candles.length)
    return null;
  const covered = candles.at(-1).time + PERIOD;
  if (covered < at)
    return null;
  let best = null;
  for (const candle of candles) {
    if (candle.time + PERIOD <= at)
      best = candle;
    else
      break;
  }
  if (!best)
    return null;
  const closedAt = best.time + PERIOD;
  const driftSec = at - closedAt;
  if (driftSec > 600)
    return null;
  return { price: best.close, at: closedAt, driftSec, source };
}

// packages/web/src/api/engine/outcomes.ts
var GRACE_MS2 = 90000;
var GIVE_UP_MS = 24 * 3600000;
var BATCH = 25;
function judge(direction, entry, result) {
  if (result === entry)
    return "draw";
  const up = result > entry;
  if (direction === "call")
    return up ? "win" : "loss";
  if (direction === "put")
    return up ? "loss" : "win";
  return "unknown";
}
function profitPct(outcome, payout) {
  if (outcome === "win")
    return payout;
  if (outcome === "loss")
    return -100;
  return 0;
}
async function resolveOne(signal) {
  const expiryEpoch = Math.floor(signal.expiresAt.getTime() / 1000);
  const tradeDay = signal.tradeDay ?? kyivDay(signal.entryAt);
  const overdue = Date.now() - signal.expiresAt.getTime() > GIVE_UP_MS;
  let quote = null;
  let error = "";
  try {
    quote = await priceAt(signal.symbol, expiryEpoch);
  } catch (err) {
    error = err.message;
  }
  if (!quote) {
    if (!overdue) {
      if (signal.tradeDay !== tradeDay) {
        await db2.update(signals).set({ tradeDay }).where(eq(signals.id, signal.id));
      }
      return "pending";
    }
    await db2.update(signals).set({
      outcome: "unknown",
      resolvedAt: new Date,
      resolveNote: error || "фид не отдал цену на момент экспирации",
      tradeDay
    }).where(eq(signals.id, signal.id));
    return "unknown";
  }
  const outcome = judge(signal.direction, signal.price, quote.price);
  const note = [
    `цена экспирации ${quote.price} (${quote.source})`,
    quote.driftSec ? `свеча закрылась на ${quote.driftSec} сек раньше экспирации` : "точное попадание"
  ].join(" · ");
  await db2.update(signals).set({ outcome, resultPrice: quote.price, resolvedAt: new Date, resolveNote: note, tradeDay }).where(eq(signals.id, signal.id));
  return outcome;
}
async function resolvePending(limit = BATCH) {
  const cutoff = new Date(Date.now() - GRACE_MS2);
  const rows = await db2.select().from(signals).where(and(eq(signals.outcome, "pending"), lt(signals.expiresAt, cutoff))).orderBy(asc(signals.expiresAt)).limit(limit);
  const report = {
    checked: rows.length,
    resolved: 0,
    wins: 0,
    losses: 0,
    draws: 0,
    unknown: 0,
    skipped: 0
  };
  for (const row of rows) {
    try {
      const outcome = await resolveOne(row);
      if (outcome === "pending")
        report.skipped += 1;
      else
        report.resolved += 1;
      if (outcome === "win")
        report.wins += 1;
      if (outcome === "loss")
        report.losses += 1;
      if (outcome === "draw")
        report.draws += 1;
      if (outcome === "unknown")
        report.unknown += 1;
    } catch (error) {
      report.skipped += 1;
      console.error(`[outcomes] ${row.symbol} #${row.id}: не удалось закрыть — ${error.message}`);
    }
  }
  if (report.resolved) {
    console.log(`[outcomes] закрыто ${report.resolved}: ${report.wins} в плюс · ${report.losses} в минус` + `${report.draws ? ` · ${report.draws} возврат` : ""}${report.unknown ? ` · ${report.unknown} без данных` : ""}`);
  }
  return report;
}
async function backfillTradeDays() {
  const rows = await db2.select({ id: signals.id, entryAt: signals.entryAt }).from(signals).where(or(isNull(signals.tradeDay), eq(signals.tradeDay, ""))).limit(500);
  for (const row of rows) {
    await db2.update(signals).set({ tradeDay: kyivDay(row.entryAt) }).where(eq(signals.id, row.id));
  }
  if (rows.length)
    console.log(`[outcomes] торговый день проставлен у ${rows.length} сигналов`);
  return rows.length;
}
var scope2 = globalThis;
var state3 = scope2.__poOutcomes ??= { timer: null, running: false };
var TICK_MS = 60000;
async function tick2() {
  if (state3.running)
    return;
  state3.running = true;
  try {
    await resolvePending();
  } catch (error) {
    console.error("[outcomes] проход упал:", error.message);
  } finally {
    state3.running = false;
  }
}
function startOutcomeResolver() {
  if (state3.timer)
    return;
  state3.timer = setInterval(() => void tick2(), TICK_MS);
  backfillTradeDays().then(() => tick2()).catch((error) => console.error("[outcomes] старт:", error.message));
  console.log("[outcomes] закрытие сделок по факту: проверка каждую минуту");
}

// packages/web/src/api/engine/daily-report.ts
init_drizzle_orm();
init_database();
init_schema();
init_day();
await init_telegram();

// packages/web/src/api/engine/stats.ts
init_drizzle_orm();
init_database();
init_schema();
init_day();
var TARGET_WINRATE = 90;
var empty = () => ({
  trades: 0,
  wins: 0,
  losses: 0,
  draws: 0,
  pending: 0,
  unknown: 0,
  decided: 0,
  winrate: 0,
  netPct: 0
});
function add(t, row) {
  t.trades += 1;
  if (row.outcome === "win")
    t.wins += 1;
  else if (row.outcome === "loss")
    t.losses += 1;
  else if (row.outcome === "draw")
    t.draws += 1;
  else if (row.outcome === "pending")
    t.pending += 1;
  else
    t.unknown += 1;
  t.netPct = Number((t.netPct + profitPct(row.outcome, row.payout)).toFixed(2));
  t.decided = t.wins + t.losses;
  t.winrate = t.decided ? Number((t.wins / t.decided * 100).toFixed(1)) : 0;
  return t;
}
function group(rows, keyOf, pick) {
  const map = new Map;
  for (const row of rows) {
    const id = keyOf(row);
    if (!id)
      continue;
    const bucket = map.get(id.key) ?? { ...empty(), key: id.key, label: id.label };
    add(bucket, pick(row));
    map.set(id.key, bucket);
  }
  return [...map.values()].sort((a, b) => b.trades - a.trades || a.key.localeCompare(b.key));
}
function confidenceBucket(confidence) {
  const floor = Math.min(95, Math.max(50, Math.floor(confidence / 5) * 5));
  return { key: String(floor).padStart(2, "0"), label: `${floor}–${floor + 4}%` };
}
function expiryLabel2(seconds) {
  return seconds % 60 === 0 ? `${seconds / 60} мин` : `${seconds} сек`;
}
function asSnapshot(value) {
  if (!value || typeof value !== "object")
    return null;
  const snap = value;
  return snap.decision && snap.indicators ? snap : null;
}
function asFactors(value) {
  return Array.isArray(value) ? value : [];
}
function findFaults(row, snap) {
  const out = [];
  const dir = row.direction;
  if (row.lowPayout)
    out.push("payout вне целевого диапазона");
  if (!snap)
    return out;
  const { decision, indicators, structure, levelAhead } = snap;
  if (decision.margin != null && decision.margin < 0.15)
    out.push("слабый перевес голосов (<15%)");
  if (structure.m30 && structure.m30.bias === "neutral")
    out.push("30m без направления");
  if (structure.m30 && (dir === "call" && structure.m30.bias === "bearish" || dir === "put" && structure.m30.bias === "bullish")) {
    out.push("вход против 30m тренда");
  }
  if (structure.m30 && (dir === "call" && structure.m30.zone === "premium" || dir === "put" && structure.m30.zone === "discount")) {
    out.push(dir === "call" ? "покупка в дорогой зоне (premium)" : "продажа в дешёвой зоне (discount)");
  }
  if (levelAhead && levelAhead.distanceAtr <= 0.5)
    out.push("уровень против входа ближе 0.5 ATR");
  if (indicators.rsi5 != null) {
    if (dir === "call" && indicators.rsi5 >= 70)
      out.push("RSI в перекупленности");
    if (dir === "put" && indicators.rsi5 <= 30)
      out.push("RSI в перепроданности");
  }
  if (indicators.macd5Hist != null) {
    if (dir === "call" && indicators.macd5Hist < 0)
      out.push("MACD 5m против входа");
    if (dir === "put" && indicators.macd5Hist > 0)
      out.push("MACD 5m против входа");
  }
  if (indicators.atrPct > 0 && indicators.atrPct < 0.03)
    out.push("волатильность ниже шума (ATR<0.03%)");
  if (indicators.atrPct > 0.2)
    out.push("экспирация коротка для такой волатильности");
  const factors = asFactors(row.factors ?? snap.factors);
  const forWeight = factors.filter((f) => f.direction === dir).reduce((sum, f) => sum + f.weight, 0);
  const againstWeight = factors.filter((f) => f.direction !== dir && f.direction !== "neutral").reduce((sum, f) => sum + f.weight, 0);
  if (forWeight > 0 && againstWeight / forWeight > 0.6)
    out.push("много контрфакторов в голосовании");
  const hour = snap.kyivHour ?? kyivHour(row.entryAt);
  if (hour >= 0 && hour < 7)
    out.push("тонкий рынок (ночь по Киеву)");
  return out;
}
function toTrade(row) {
  const snap = asSnapshot(row.snapshot);
  const moveAbs = row.resultPrice != null ? Number((row.resultPrice - row.price).toFixed(6)) : null;
  const atrAbs = snap?.indicators.atrAbs ?? null;
  return {
    id: row.id,
    symbol: row.symbol,
    assetName: row.assetName,
    direction: row.direction,
    confidence: row.confidence,
    payout: row.payout,
    lowPayout: row.lowPayout,
    expirySeconds: row.expirySeconds,
    entryAt: row.entryAt,
    expiresAt: row.expiresAt,
    price: row.price,
    resultPrice: row.resultPrice,
    outcome: row.outcome,
    resolveNote: row.resolveNote,
    profitPct: profitPct(row.outcome, row.payout),
    moveAbs,
    moveAtr: moveAbs != null && atrAbs ? Number((moveAbs / atrAbs).toFixed(2)) : null,
    biasH30: row.biasH30,
    biasM15: row.biasM15,
    triggerM5: row.triggerM5,
    reasons: Array.isArray(row.reasons) ? row.reasons : [],
    kyivHour: snap?.kyivHour ?? kyivHour(row.entryAt),
    margin: snap?.decision.margin ?? null,
    atrPct: snap?.indicators.atrPct ?? null,
    rsi5: snap?.indicators.rsi5 ?? null,
    levelAheadAtr: snap?.levelAhead?.distanceAtr ?? null,
    faults: findFaults(row, snap),
    hasSnapshot: snap !== null
  };
}
function streaks(trades) {
  let best = 0;
  let worst = 0;
  let win = 0;
  let loss = 0;
  for (const t of trades) {
    if (t.outcome === "win") {
      win += 1;
      loss = 0;
      best = Math.max(best, win);
    } else if (t.outcome === "loss") {
      loss += 1;
      win = 0;
      worst = Math.max(worst, loss);
    }
  }
  return { best, worst };
}
function factorStats(rows) {
  const map = new Map;
  for (const row of rows) {
    const snap = asSnapshot(row.snapshot);
    const factors = asFactors(row.factors ?? snap?.factors);
    if (!factors.length)
      continue;
    for (const factor of factors) {
      if (factor.direction === "neutral")
        continue;
      const entry = map.get(factor.label) ?? {
        ...empty(),
        label: factor.label,
        weight: 0,
        weightSum: 0,
        against: 0,
        againstLosses: 0
      };
      if (factor.direction === row.direction) {
        add(entry, row);
        entry.weightSum += factor.weight;
      } else {
        entry.against += 1;
        if (row.outcome === "loss")
          entry.againstLosses += 1;
      }
      map.set(factor.label, entry);
    }
  }
  return [...map.values()].map(({ weightSum, ...rest }) => ({
    ...rest,
    weight: rest.trades ? Number((weightSum / rest.trades).toFixed(2)) : 0
  })).sort((a, b) => b.trades - a.trades);
}
async function daySignals(day) {
  return db2.select().from(signals).where(eq(signals.tradeDay, day)).orderBy(asc(signals.entryAt), asc(signals.id));
}
async function dayStats(day) {
  const rows = await daySignals(day);
  const trades = rows.map(toTrade);
  const tally = rows.reduce((acc, row) => add(acc, row), empty());
  const { best, worst } = streaks(trades);
  const faultCount = new Map;
  for (const trade of trades) {
    if (trade.outcome !== "loss")
      continue;
    for (const fault of trade.faults)
      faultCount.set(fault, (faultCount.get(fault) ?? 0) + 1);
  }
  return {
    day,
    tally,
    bestWinStreak: best,
    worstLossStreak: worst,
    byDirection: group(rows, (r) => ({ key: r.direction, label: r.direction === "call" ? "CALL ↑" : "PUT ↓" }), (r) => r),
    bySymbol: group(rows, (r) => ({ key: r.symbol, label: r.assetName }), (r) => r),
    byHour: group(rows, (r) => {
      const hour = kyivHour(r.entryAt);
      return { key: String(hour).padStart(2, "0"), label: `${String(hour).padStart(2, "0")}:00` };
    }, (r) => r).sort((a, b) => a.key.localeCompare(b.key)),
    byConfidence: group(rows, (r) => confidenceBucket(r.confidence), (r) => r).sort((a, b) => a.key.localeCompare(b.key)),
    byExpiry: group(rows, (r) => ({ key: String(r.expirySeconds).padStart(4, "0"), label: expiryLabel2(r.expirySeconds) }), (r) => r).sort((a, b) => a.key.localeCompare(b.key)),
    byTrigger: group(rows, (r) => ({ key: r.triggerM5, label: r.triggerM5 }), (r) => r),
    byBias30: group(rows, (r) => ({ key: r.biasH30, label: r.biasH30 }), (r) => r),
    factors: factorStats(rows),
    faults: [...faultCount.entries()].map(([label, count]) => ({ label, count })).sort((a, b) => b.count - a.count),
    trades,
    snapshots: trades.filter((t) => t.hasSnapshot).length
  };
}
async function availableDays(limit = 60) {
  const rows = await db2.select({
    day: signals.tradeDay,
    trades: sql`count(*)`,
    wins: sql`sum(case when ${signals.outcome} = 'win' then 1 else 0 end)`,
    losses: sql`sum(case when ${signals.outcome} = 'loss' then 1 else 0 end)`,
    pending: sql`sum(case when ${signals.outcome} = 'pending' then 1 else 0 end)`,
    netPct: sql`sum(case when ${signals.outcome} = 'win' then ${signals.payout} when ${signals.outcome} = 'loss' then -100 else 0 end)`
  }).from(signals).where(isNotNull(signals.tradeDay)).groupBy(signals.tradeDay).orderBy(desc(signals.tradeDay)).limit(limit);
  return rows.filter((r) => Boolean(r.day)).map((r) => ({
    day: r.day,
    trades: Number(r.trades),
    wins: Number(r.wins),
    losses: Number(r.losses),
    pending: Number(r.pending),
    winrate: Number(r.wins) + Number(r.losses) ? Number((Number(r.wins) / (Number(r.wins) + Number(r.losses)) * 100).toFixed(1)) : 0,
    netPct: Number(Number(r.netPct).toFixed(2))
  }));
}
async function rangeTally(days) {
  if (!days.length)
    return empty();
  const rows = await db2.select({ outcome: signals.outcome, payout: signals.payout }).from(signals).where(inArray(signals.tradeDay, days));
  return rows.reduce((acc, row) => add(acc, row), empty());
}
var todayKey = () => kyivDay();

// packages/web/src/api/engine/daily-report.ts
var MIN_SAMPLE = 3;
var LAG_PP = 15;
var pct = (value) => `${value.toFixed(1)}%`;
var hhmm = (d) => d.toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit", timeZone: TZ2 });
function winrateOf(trades) {
  const wins = trades.filter((t) => t.outcome === "win").length;
  const losses = trades.filter((t) => t.outcome === "loss").length;
  return wins + losses ? Number((wins / (wins + losses) * 100).toFixed(1)) : 0;
}
function winrateWithout(trades, drop) {
  const kept = trades.filter((t) => !drop(t));
  const cuts = trades.filter((t) => drop(t) && t.outcome !== "pending").length;
  const decided = kept.filter((t) => t.outcome === "win" || t.outcome === "loss").length;
  return { winrate: decided ? winrateOf(kept) : null, cuts, keptDecided: decided };
}
function faultStats(trades) {
  const map = new Map;
  for (const trade of trades) {
    if (trade.outcome !== "win" && trade.outcome !== "loss")
      continue;
    for (const label of trade.faults) {
      const entry = map.get(label) ?? { label, trades: 0, wins: 0, losses: 0, winrate: 0 };
      entry.trades += 1;
      if (trade.outcome === "win")
        entry.wins += 1;
      else
        entry.losses += 1;
      entry.winrate = Number((entry.wins / entry.trades * 100).toFixed(1));
      map.set(label, entry);
    }
  }
  return [...map.values()].sort((a, b) => b.losses - a.losses || b.trades - a.trades);
}
function bestBuckets(list, overall) {
  return list.filter((b) => b.decided >= MIN_SAMPLE && b.winrate >= Math.max(overall, 60)).sort((a, b) => b.winrate - a.winrate || b.decided - a.decided).slice(0, 4);
}
function worstBuckets(list, overall) {
  return list.filter((b) => b.decided >= MIN_SAMPLE && b.winrate <= overall - LAG_PP).sort((a, b) => a.winrate - b.winrate || b.decided - a.decided).slice(0, 4);
}
function moveLabel(trade) {
  if (trade.resultPrice == null || trade.moveAbs == null)
    return "цены экспирации нет";
  const sign = trade.moveAbs > 0 ? "+" : "";
  const atr = trade.moveAtr != null ? ` (${trade.moveAtr} ATR)` : "";
  return `${trade.price} → ${trade.resultPrice} · ${sign}${trade.moveAbs}${atr}`;
}
function analyzeDay(stats, context) {
  const { tally, trades } = stats;
  const decided = trades.filter((t) => t.outcome === "win" || t.outcome === "loss");
  const overall = tally.winrate;
  const faults = faultStats(trades);
  const worked = [];
  const failed = [];
  for (const bucket of bestBuckets(stats.bySymbol, overall)) {
    worked.push(`${bucket.label}: ${bucket.wins}/${bucket.decided} (${pct(bucket.winrate)})`);
  }
  for (const bucket of bestBuckets(stats.byTrigger, overall)) {
    worked.push(`триггер «${bucket.label}»: ${pct(bucket.winrate)} на ${bucket.decided} сделках`);
  }
  for (const bucket of bestBuckets(stats.byExpiry, overall)) {
    worked.push(`экспирация ${bucket.label}: ${pct(bucket.winrate)} на ${bucket.decided} сделках`);
  }
  for (const factor of stats.factors) {
    if (factor.decided >= MIN_SAMPLE && factor.winrate >= Math.max(overall + 10, 70)) {
      worked.push(`фактор «${factor.label}»: ${pct(factor.winrate)} на ${factor.decided} сделках`);
    }
  }
  for (const bucket of worstBuckets(stats.bySymbol, overall)) {
    failed.push(`${bucket.label}: ${bucket.wins}/${bucket.decided} (${pct(bucket.winrate)})`);
  }
  for (const bucket of worstBuckets(stats.byHour, overall)) {
    failed.push(`час ${bucket.label}: ${bucket.wins}/${bucket.decided} (${pct(bucket.winrate)})`);
  }
  for (const bucket of worstBuckets(stats.byConfidence, overall)) {
    failed.push(`уверенность ${bucket.label}: ${pct(bucket.winrate)} на ${bucket.decided} сделках`);
  }
  for (const bucket of worstBuckets(stats.byTrigger, overall)) {
    failed.push(`триггер «${bucket.label}»: ${pct(bucket.winrate)} на ${bucket.decided} сделках`);
  }
  for (const factor of stats.factors) {
    if (factor.decided >= MIN_SAMPLE && factor.winrate <= overall - LAG_PP) {
      failed.push(`фактор «${factor.label}»: ${pct(factor.winrate)} на ${factor.decided} сделках`);
    }
  }
  const losses = trades.filter((t) => t.outcome === "loss").map((t) => ({
    id: t.id,
    symbol: t.symbol,
    at: hhmm(t.entryAt),
    direction: t.direction,
    confidence: t.confidence,
    move: moveLabel(t),
    causes: t.faults.length ? t.faults : ["явных дефектов входа нет — рынок ушёл против"]
  }));
  const proposals = buildProposals(stats, decided, faults);
  const headline = tally.decided ? `${tally.wins} в плюс · ${tally.losses} в минус · винрейт ${pct(overall)} · итог ${tally.netPct > 0 ? "+" : ""}${tally.netPct}% ставки` : tally.trades ? `${tally.trades} сделок, результат ещё не определён` : "сделок не было";
  return { day: stats.day, headline, worked, failed, faults, losses, proposals, context };
}
function buildProposals(stats, decided, faults) {
  const out = [];
  const overall = stats.tally.winrate;
  const push = (title, evidence, action, drop) => {
    const { winrate, cuts, keptDecided } = winrateWithout(stats.trades, drop);
    if (winrate == null || keptDecided < 2 || winrate <= overall)
      return;
    out.push({ title, evidence, action, winrateIfApplied: winrate, cuts });
  };
  const weakConf = stats.byConfidence.filter((b) => b.decided >= MIN_SAMPLE && b.winrate <= overall - LAG_PP).sort((a, b) => a.key.localeCompare(b.key));
  const cut = weakConf.at(-1);
  if (cut) {
    const threshold = Number(cut.key) + 5;
    push(`Поднять порог уверенности до ${threshold}%`, `в диапазоне ${cut.label} винрейт ${pct(cut.winrate)} против ${pct(overall)} по дню`, `minConfidence = ${threshold} в настройках движка`, (t) => t.confidence < threshold);
  }
  for (const bucket of stats.bySymbol.filter((b) => b.decided >= MIN_SAMPLE && b.winrate <= overall - LAG_PP)) {
    push(`Убрать ${bucket.label} из watchlist на день`, `${bucket.wins}/${bucket.decided} (${pct(bucket.winrate)}), итог ${bucket.netPct}% ставки`, `исключить ${bucket.key} до пересмотра — пара не отрабатывает сетапы`, (t) => t.symbol === bucket.key);
  }
  const badHours = stats.byHour.filter((b) => b.decided >= MIN_SAMPLE && b.winrate <= overall - LAG_PP).map((b) => Number(b.key));
  if (badHours.length) {
    const list = badHours.map((h) => `${String(h).padStart(2, "0")}:00`).join(", ");
    push(`Не входить в часы ${list}`, badHours.map((h) => {
      const b = stats.byHour.find((x) => Number(x.key) === h);
      return `${String(h).padStart(2, "0")}:00 — ${pct(b.winrate)} (${b.decided})`;
    }).join(" · "), "добавить окно тишины в расписание сканера", (t) => badHours.includes(t.kyivHour));
  }
  for (const bucket of stats.byExpiry.filter((b) => b.decided >= MIN_SAMPLE && b.winrate <= overall - LAG_PP)) {
    push(`Отказаться от экспирации ${bucket.label}`, `${bucket.wins}/${bucket.decided} (${pct(bucket.winrate)})`, `исключить ${bucket.label} из списка экспираций для текущей волатильности`, (t) => String(t.expirySeconds).padStart(4, "0") === bucket.key);
  }
  for (const fault of faults) {
    if (fault.trades < MIN_SAMPLE || fault.winrate > overall - LAG_PP)
      continue;
    push(`Блокировать вход: ${fault.label}`, `${fault.wins}/${fault.trades} (${pct(fault.winrate)}) при этом условии`, "добавить в blockers стратегии — сигнал не публикуется", (t) => t.faults.includes(fault.label));
  }
  const thinMargin = decided.filter((t) => t.margin != null && t.margin < 0.2);
  if (thinMargin.length >= MIN_SAMPLE && winrateOf(thinMargin) <= overall - LAG_PP) {
    push("Требовать перевес голосов ≥ 20%", `при перевесе <20% винрейт ${pct(winrateOf(thinMargin))} на ${thinMargin.length} сделках`, "добавить проверку margin в analyze(): ниже 0.2 — блокер", (t) => t.margin != null && t.margin < 0.2);
  }
  for (const bucket of stats.byDirection.filter((b) => b.decided >= MIN_SAMPLE && b.winrate <= overall - LAG_PP)) {
    push(`Приостановить ${bucket.label}`, `${bucket.wins}/${bucket.decided} (${pct(bucket.winrate)}) — рынок шёл в одну сторону`, `не публиковать ${bucket.key}, пока 30m bias не развернётся`, (t) => t.direction === bucket.key);
  }
  out.sort((a, b) => (b.winrateIfApplied ?? 0) - (a.winrateIfApplied ?? 0) || a.cuts - b.cuts);
  const best = out[0];
  if (best && (best.winrateIfApplied ?? 0) < TARGET_WINRATE && stats.tally.decided >= 5) {
    out.push({
      title: `До ${TARGET_WINRATE}% одним фильтром не дойти`,
      evidence: `лучший из фильтров даёт ${pct(best.winrateIfApplied ?? 0)} на ${stats.tally.decided - best.cuts} сделках`,
      action: "комбинировать: порог уверенности + запрет входов против 30m тренда + отказ от ночных часов; после смены параметров сравнивать дни, а не отдельные сделки",
      winrateIfApplied: null,
      cuts: 0
    });
  }
  return out.slice(0, 8);
}
function renderReport(stats, analysis) {
  const t = stats.tally;
  const lines = [];
  const L = (s = "") => lines.push(s);
  L(`Отчёт за ${analysis.day} (киевские сутки)`);
  L(analysis.headline);
  L();
  L("── Итоги ──");
  L(`Сделок: ${t.trades} · закрыто: ${t.decided} · ждут экспирации: ${t.pending}`);
  L(`Плюс: ${t.wins} · минус: ${t.losses}${t.draws ? ` · возврат: ${t.draws}` : ""}${t.unknown ? ` · без данных: ${t.unknown}` : ""}`);
  L(`Винрейт: ${pct(t.winrate)} (цель ${TARGET_WINRATE}%) · итог: ${t.netPct > 0 ? "+" : ""}${t.netPct}% ставки`);
  L(`Серии: подряд в плюс ${stats.bestWinStreak} · подряд в минус ${stats.worstLossStreak}`);
  L(`За 7 дней: ${pct(analysis.context.last7Winrate)} на ${analysis.context.last7Trades} сделках`);
  if (stats.trades.length && stats.snapshots < stats.trades.length) {
    L(`Слепки входа есть у ${stats.snapshots} из ${stats.trades.length} сделок`);
  }
  L();
  L("── Сделки по порядку ──");
  if (!stats.trades.length)
    L("сделок не было");
  for (const trade of stats.trades) {
    const mark = trade.outcome === "win" ? "\uD83D\uDFE2" : trade.outcome === "loss" ? "\uD83D\uDD34" : trade.outcome === "draw" ? "⚪" : trade.outcome === "pending" ? "⏳" : "❔";
    L(`${mark} ${hhmm(trade.entryAt)} ${trade.symbol} ${trade.direction.toUpperCase()} · ` + `уверенность ${trade.confidence}% · payout ${trade.payout}% · ${trade.expirySeconds % 60 === 0 ? `${trade.expirySeconds / 60} мин` : `${trade.expirySeconds} сек`}`);
    L(`   ${moveLabel(trade)}`);
    const snapLine = [
      trade.margin != null ? `перевес ${Math.round(trade.margin * 100)}%` : null,
      trade.atrPct != null ? `ATR ${trade.atrPct}%` : null,
      trade.rsi5 != null ? `RSI ${trade.rsi5}` : null,
      trade.levelAheadAtr != null ? `уровень в ${trade.levelAheadAtr} ATR` : null
    ].filter(Boolean).join(" · ");
    if (snapLine)
      L(`   ${snapLine}`);
    L(`   30m: ${trade.biasH30} | 15m: ${trade.biasM15} | 5m: ${trade.triggerM5}`);
    if (trade.faults.length)
      L(`   дефекты: ${trade.faults.join("; ")}`);
  }
  L();
  L("── Что работало ──");
  if (!analysis.worked.length)
    L("устойчивых плюсовых закономерностей не набралось");
  for (const item of analysis.worked)
    L(`+ ${item}`);
  L();
  L("── Что подводило ──");
  if (!analysis.failed.length)
    L("выраженных проблемных разрезов нет");
  for (const item of analysis.failed)
    L(`− ${item}`);
  if (analysis.losses.length) {
    L();
    L("── Разбор убытков ──");
    for (const loss of analysis.losses) {
      L(`\uD83D\uDD34 ${loss.at} ${loss.symbol} ${loss.direction.toUpperCase()} (${loss.confidence}%)`);
      L(`   ${loss.move}`);
      for (const cause of loss.causes)
        L(`   • ${cause}`);
    }
  }
  if (analysis.faults.length) {
    L();
    L("── Дефекты входа: как отрабатывают ──");
    for (const fault of analysis.faults) {
      L(`${fault.label}: ${fault.wins}/${fault.trades} (${pct(fault.winrate)})`);
    }
  }
  L();
  L(`── Что менять (цель ${TARGET_WINRATE}%) ──`);
  if (!analysis.proposals.length)
    L("данных дня не хватает на обоснованное изменение параметров");
  analysis.proposals.forEach((p, i) => {
    L(`${i + 1}. ${p.title}`);
    L(`   основание: ${p.evidence}`);
    L(`   действие: ${p.action}`);
    if (p.winrateIfApplied != null) {
      L(`   винрейт дня с этим фильтром: ${pct(p.winrateIfApplied)} (отсеклось ${p.cuts})`);
    }
  });
  return lines.join(`
`);
}
async function generateDailyReport(day) {
  const stats = await dayStats(day);
  const week = await rangeTally(Array.from({ length: 7 }, (_, i) => shiftDay(day, -i)));
  const analysis = analyzeDay(stats, {
    last7Winrate: week.winrate,
    last7Trades: week.decided
  });
  const summary = renderReport(stats, analysis);
  const row = {
    day,
    trades: stats.tally.trades,
    wins: stats.tally.wins,
    losses: stats.tally.losses,
    draws: stats.tally.draws,
    pending: stats.tally.pending,
    winrate: stats.tally.winrate,
    bestWinStreak: stats.bestWinStreak,
    worstLossStreak: stats.worstLossStreak,
    analysis,
    summary,
    sentToTelegram: false,
    generatedAt: new Date
  };
  await db2.insert(dailyReports).values(row).onConflictDoUpdate({ target: dailyReports.day, set: row });
  return { day, stats, analysis, summary };
}
async function storedReport(day) {
  const [row] = await db2.select().from(dailyReports).where(eq(dailyReports.day, day));
  return row ?? null;
}
var scope3 = globalThis;
var state4 = scope3.__poDailyReport ??= { timer: null };
var AFTER_MIDNIGHT_MS = 3 * 60000;
function schedule2() {
  if (state4.timer)
    clearTimeout(state4.timer);
  const at = nextMidnight().getTime() + AFTER_MIDNIGHT_MS;
  state4.timer = setTimeout(() => void fire(), Math.max(1000, at - Date.now()));
}
async function fire() {
  const day = shiftDay(kyivDay(), -1);
  try {
    const report = await generateDailyReport(day);
    console.log(`[report] ${day}: ${report.stats.tally.wins}/${report.stats.tally.decided} в плюс · ` + `винрейт ${report.stats.tally.winrate}% · предложений ${report.analysis.proposals.length}`);
  } catch (error) {
    console.error(`[report] ${day}: не удалось собрать отчёт —`, error.message);
  } finally {
    schedule2();
  }
}
function startDailyReporter() {
  if (state4.timer)
    return;
  schedule2();
  const at = new Date(nextMidnight().getTime() + AFTER_MIDNIGHT_MS);
  console.log(`[report] ежедневный разбор: следующий в ${hhmm(at)} по Киеву`);
}
function dailyReporterRunning() {
  return state4.timer !== null;
}

// packages/web/src/api/engine/boot.ts
await __promiseAll([
  init_telegram(),
  init_env()
]);
var FLAG = "__pocketSignalBotBooted";
var globalScope = globalThis;
function boot() {
  if (!engineEnabled()) {
    console.warn("[boot] ENGINE_ENABLED=0 — движок не запущен: этот процесс только отдаёт дашборд и читает базу");
    return;
  }
  if (globalScope[FLAG])
    return;
  globalScope[FLAG] = true;
  (async () => {
    try {
      const settings = await getSettings();
      if (settings.poSsid)
        setEnvOverride("POCKET_OPTION_SSID", settings.poSsid);
      if (botConfigured()) {
        startPolling();
        const seed = envStr("TELEGRAM_DEFAULT_CHAT_ID");
        if (seed) {
          const ok = await sendMessage(seed, `♻️ <b>Pocket Signal Bot запущен</b>
Сканирую валютные пары Pocket Option. /help — команды.`);
          if (ok)
            await addSubscriber(seed, "Чат из .env");
          else
            console.warn(`[boot] чат ${seed} недоступен — нужен /start от пользователя`);
        }
      } else {
        console.warn("[boot] TELEGRAM_BOT_TOKEN не задан — рассылка выключена");
      }
      startFeedAlerts();
      startOutcomeResolver();
      startDailyReporter();
      startScanner(settings.scanIntervalSec);
    } catch (error) {
      globalScope[FLAG] = false;
      console.error("[boot] не удалось запустить движок:", error.message);
    }
  })();
}

// packages/web/src/api/ops.ts
init_drizzle_orm();
init_database();
init_schema();
init_store();
init_day();
await __promiseAll([
  init_env(),
  init_po_feed()
]);
var STARTED_AT = Date.now();
var LOG_LIMIT = 800;
var logs = [];
var logsHooked = false;
function push(level, args) {
  const text = args.map((a) => {
    if (typeof a === "string")
      return a;
    if (a instanceof Error)
      return `${a.name}: ${a.message}`;
    try {
      return JSON.stringify(a);
    } catch {
      return String(a);
    }
  }).join(" ");
  logs.push({ at: new Date().toISOString(), level, text });
  if (logs.length > LOG_LIMIT)
    logs.splice(0, logs.length - LOG_LIMIT);
}
function hookLogs() {
  if (logsHooked)
    return;
  logsHooked = true;
  const original = {
    log: console.log.bind(console),
    warn: console.warn.bind(console),
    error: console.error.bind(console)
  };
  console.log = (...args) => {
    push("log", args);
    original.log(...args);
  };
  console.warn = (...args) => {
    push("warn", args);
    original.warn(...args);
  };
  console.error = (...args) => {
    push("error", args);
    original.error(...args);
  };
}
function tokenOf(request) {
  const header = request.headers.get("x-ops-token");
  if (header)
    return header.trim();
  const auth = request.headers.get("authorization");
  if (auth?.toLowerCase().startsWith("bearer "))
    return auth.slice(7).trim();
  return new URL(request.url).searchParams.get("token");
}
function sameToken(a, b) {
  if (a.length !== b.length)
    return false;
  let diff = 0;
  for (let i = 0;i < a.length; i += 1)
    diff |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return diff === 0;
}
function guard(request) {
  const expected = envStr("OPS_TOKEN");
  if (!expected) {
    return { ok: false, status: 503, message: "OPS_TOKEN не задан — служебный канал выключен" };
  }
  if (expected.length < 24) {
    return { ok: false, status: 503, message: "OPS_TOKEN короче 24 символов — задайте длиннее" };
  }
  const got = tokenOf(request);
  if (!got || !sameToken(got, expected)) {
    return { ok: false, status: 401, message: "неверный токен" };
  }
  return { ok: true };
}
async function health() {
  const settings = await getSettings();
  const [lastRun] = await db2.select().from(scanRuns).orderBy(desc(scanRuns.startedAt)).limit(1);
  const { start, end } = kyivDayBounds(kyivDay());
  const today = await db2.select({
    id: signals.id,
    outcome: signals.outcome,
    confidence: signals.confidence
  }).from(signals).where(and(gte(signals.createdAt, start), lt(signals.createdAt, end)));
  const wins = today.filter((s) => s.outcome === "win").length;
  const losses = today.filter((s) => s.outcome === "loss").length;
  const pending = today.filter((s) => s.outcome == null || s.outcome === "pending").length;
  const assets2 = await db2.select({ symbol: assets.symbol }).from(assets);
  return {
    status: "ok",
    runtime: {
      node: process.version,
      bun: typeof globalThis.Bun !== "undefined",
      pid: process.pid,
      uptimeSec: Math.round((Date.now() - STARTED_AT) / 1000),
      rssMb: Math.round(process.memoryUsage().rss / 1024 / 1024),
      tz: TZ,
      now: new Date().toISOString()
    },
    feed: { ...feedState(), ssidLooksLikeCookie: ssidLooksLikeCookie() },
    scanner: {
      enabled: settings.scannerEnabled,
      intervalSec: settings.scanIntervalSec,
      lastRun: lastRun ? {
        startedAt: lastRun.startedAt,
        scanned: lastRun.scanned,
        signals: lastRun.signalsFound,
        errors: lastRun.errors,
        note: lastRun.note
      } : null
    },
    settings: {
      minConfidence: settings.minConfidence,
      minPayout: settings.minPayout,
      maxPayout: settings.maxPayout,
      cooldownMinutes: settings.cooldownMinutes,
      telegramEnabled: settings.telegramEnabled,
      fallbackPairs: settings.fallbackPairs,
      ssidFromDb: Boolean(settings.poSsid)
    },
    assets: assets2.length,
    today: { day: kyivDay(), signals: today.length, wins, losses, pending }
  };
}
async function archive(day, limit) {
  const rows = day ? await (async () => {
    const { start, end } = kyivDayBounds(day);
    return db2.select().from(signals).where(and(gte(signals.createdAt, start), lt(signals.createdAt, end))).orderBy(desc(signals.createdAt)).limit(limit);
  })() : await db2.select().from(signals).orderBy(desc(signals.createdAt)).limit(limit);
  return {
    day,
    count: rows.length,
    signals: rows.map((s) => ({
      ...s,
      dayKey: kyivDay(s.createdAt),
      snapshot: parseSnapshot(s.snapshot)
    }))
  };
}
function parseSnapshot(raw) {
  if (typeof raw !== "string")
    return raw ?? null;
  try {
    return JSON.parse(raw);
  } catch {
    return raw;
  }
}
function registerOps(app) {
  hookLogs();
  app.use("/api/ops/*", async (c, next) => {
    const check = guard(c.req.raw);
    if (!check.ok)
      return c.json({ error: check.message }, check.status);
    await next();
  });
  app.get("/api/ops/health", async (c) => c.json(await health()));
  app.get("/api/ops/archive", async (c) => {
    const day = c.req.query("day") ?? null;
    const limit = Math.min(Math.max(Number(c.req.query("limit") ?? 200), 1), 2000);
    return c.json(await archive(day, limit));
  });
  app.get("/api/ops/report", async (c) => {
    const day = c.req.query("day") ?? kyivDay();
    const [row] = await db2.select().from(dailyReports).where(eq(dailyReports.day, day)).limit(1);
    if (!row)
      return c.json({ day, report: null, note: "разбора за этот день нет" }, 404);
    return c.json({ day, report: row });
  });
  app.get("/api/ops/logs", async (c) => {
    const limit = Math.min(Math.max(Number(c.req.query("limit") ?? 200), 1), LOG_LIMIT);
    const level = c.req.query("level");
    const filtered = level ? logs.filter((l) => l.level === level) : logs;
    return c.json({ count: filtered.length, lines: filtered.slice(-limit) });
  });
  app.post("/api/ops/ssid", async (c) => {
    let body;
    try {
      body = await c.req.json();
    } catch {
      return c.json({ error: "ожидается JSON { ssid }" }, 400);
    }
    const ssid = body.ssid;
    if (typeof ssid !== "string" || ssid.trim().length < 16) {
      return c.json({ error: "ssid слишком короткий или не строка" }, 400);
    }
    const value = ssid.trim();
    setEnvOverride("POCKET_OPTION_SSID", value);
    await updateSettings({ poSsid: value });
    return c.json({
      ok: true,
      ssidLooksLikeCookie: ssidLooksLikeCookie(),
      feed: feedState(),
      note: "SSID применён и сохранён в БД; фид переподключится на следующем цикле"
    });
  });
}

// packages/web/src/api/routes/config.ts
init_drizzle_orm();

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/core.js
var NEVER = Object.freeze({
  status: "aborted"
});
function $constructor(name, initializer, params) {
  function init(inst, def) {
    if (!inst._zod) {
      Object.defineProperty(inst, "_zod", {
        value: {
          def,
          constr: _,
          traits: new Set
        },
        enumerable: false
      });
    }
    if (inst._zod.traits.has(name)) {
      return;
    }
    inst._zod.traits.add(name);
    initializer(inst, def);
    const proto = _.prototype;
    const keys = Object.keys(proto);
    for (let i = 0;i < keys.length; i++) {
      const k = keys[i];
      if (!(k in inst)) {
        inst[k] = proto[k].bind(inst);
      }
    }
  }
  const Parent = params?.Parent ?? Object;

  class Definition extends Parent {
  }
  Object.defineProperty(Definition, "name", { value: name });
  function _(def) {
    var _a;
    const inst = params?.Parent ? new Definition : this;
    init(inst, def);
    (_a = inst._zod).deferred ?? (_a.deferred = []);
    for (const fn of inst._zod.deferred) {
      fn();
    }
    return inst;
  }
  Object.defineProperty(_, "init", { value: init });
  Object.defineProperty(_, Symbol.hasInstance, {
    value: (inst) => {
      if (params?.Parent && inst instanceof params.Parent)
        return true;
      return inst?._zod?.traits?.has(name);
    }
  });
  Object.defineProperty(_, "name", { value: name });
  return _;
}
var $brand = Symbol("zod_brand");

class $ZodAsyncError extends Error {
  constructor() {
    super(`Encountered Promise during synchronous parse. Use .parseAsync() instead.`);
  }
}

class $ZodEncodeError extends Error {
  constructor(name) {
    super(`Encountered unidirectional transform during encode: ${name}`);
    this.name = "ZodEncodeError";
  }
}
var globalConfig = {};
function config(newConfig) {
  if (newConfig)
    Object.assign(globalConfig, newConfig);
  return globalConfig;
}
// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/util.js
function getEnumValues(entries) {
  const numericValues = Object.values(entries).filter((v) => typeof v === "number");
  const values = Object.entries(entries).filter(([k, _]) => numericValues.indexOf(+k) === -1).map(([_, v]) => v);
  return values;
}
function jsonStringifyReplacer(_, value) {
  if (typeof value === "bigint")
    return value.toString();
  return value;
}
function cached(getter) {
  const set = false;
  return {
    get value() {
      if (!set) {
        const value = getter();
        Object.defineProperty(this, "value", { value });
        return value;
      }
      throw new Error("cached value already set");
    }
  };
}
function nullish(input) {
  return input === null || input === undefined;
}
function cleanRegex(source) {
  const start = source.startsWith("^") ? 1 : 0;
  const end = source.endsWith("$") ? source.length - 1 : source.length;
  return source.slice(start, end);
}
function floatSafeRemainder(val, step) {
  const valDecCount = (val.toString().split(".")[1] || "").length;
  const stepString = step.toString();
  let stepDecCount = (stepString.split(".")[1] || "").length;
  if (stepDecCount === 0 && /\d?e-\d?/.test(stepString)) {
    const match = stepString.match(/\d?e-(\d?)/);
    if (match?.[1]) {
      stepDecCount = Number.parseInt(match[1]);
    }
  }
  const decCount = valDecCount > stepDecCount ? valDecCount : stepDecCount;
  const valInt = Number.parseInt(val.toFixed(decCount).replace(".", ""));
  const stepInt = Number.parseInt(step.toFixed(decCount).replace(".", ""));
  return valInt % stepInt / 10 ** decCount;
}
var EVALUATING = Symbol("evaluating");
function defineLazy(object, key, getter) {
  let value = undefined;
  Object.defineProperty(object, key, {
    get() {
      if (value === EVALUATING) {
        return;
      }
      if (value === undefined) {
        value = EVALUATING;
        value = getter();
      }
      return value;
    },
    set(v) {
      Object.defineProperty(object, key, {
        value: v
      });
    },
    configurable: true
  });
}
function assignProp(target, prop, value) {
  Object.defineProperty(target, prop, {
    value,
    writable: true,
    enumerable: true,
    configurable: true
  });
}
function mergeDefs(...defs) {
  const mergedDescriptors = {};
  for (const def of defs) {
    const descriptors = Object.getOwnPropertyDescriptors(def);
    Object.assign(mergedDescriptors, descriptors);
  }
  return Object.defineProperties({}, mergedDescriptors);
}
function esc(str) {
  return JSON.stringify(str);
}
function slugify(input) {
  return input.toLowerCase().trim().replace(/[^\w\s-]/g, "").replace(/[\s_-]+/g, "-").replace(/^-+|-+$/g, "");
}
var captureStackTrace = "captureStackTrace" in Error ? Error.captureStackTrace : (..._args) => {};
function isObject2(data) {
  return typeof data === "object" && data !== null && !Array.isArray(data);
}
var allowsEval = cached(() => {
  if (typeof navigator !== "undefined" && navigator?.userAgent?.includes("Cloudflare")) {
    return false;
  }
  try {
    const F = Function;
    new F("");
    return true;
  } catch (_) {
    return false;
  }
});
function isPlainObject(o) {
  if (isObject2(o) === false)
    return false;
  const ctor = o.constructor;
  if (ctor === undefined)
    return true;
  if (typeof ctor !== "function")
    return true;
  const prot = ctor.prototype;
  if (isObject2(prot) === false)
    return false;
  if (Object.prototype.hasOwnProperty.call(prot, "isPrototypeOf") === false) {
    return false;
  }
  return true;
}
function shallowClone(o) {
  if (isPlainObject(o))
    return { ...o };
  if (Array.isArray(o))
    return [...o];
  return o;
}
var propertyKeyTypes = new Set(["string", "number", "symbol"]);
var primitiveTypes = new Set(["string", "number", "bigint", "boolean", "symbol", "undefined"]);
function escapeRegex(str) {
  return str.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
}
function clone(inst, def, params) {
  const cl = new inst._zod.constr(def ?? inst._zod.def);
  if (!def || params?.parent)
    cl._zod.parent = inst;
  return cl;
}
function normalizeParams(_params) {
  const params = _params;
  if (!params)
    return {};
  if (typeof params === "string")
    return { error: () => params };
  if (params?.message !== undefined) {
    if (params?.error !== undefined)
      throw new Error("Cannot specify both `message` and `error` params");
    params.error = params.message;
  }
  delete params.message;
  if (typeof params.error === "string")
    return { ...params, error: () => params.error };
  return params;
}
function optionalKeys(shape) {
  return Object.keys(shape).filter((k) => {
    return shape[k]._zod.optin === "optional" && shape[k]._zod.optout === "optional";
  });
}
var NUMBER_FORMAT_RANGES = {
  safeint: [Number.MIN_SAFE_INTEGER, Number.MAX_SAFE_INTEGER],
  int32: [-2147483648, 2147483647],
  uint32: [0, 4294967295],
  float32: [-340282346638528860000000000000000000000, 340282346638528860000000000000000000000],
  float64: [-Number.MAX_VALUE, Number.MAX_VALUE]
};
function pick(schema, mask) {
  const currDef = schema._zod.def;
  const checks = currDef.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    throw new Error(".pick() cannot be used on object schemas containing refinements");
  }
  const def = mergeDefs(schema._zod.def, {
    get shape() {
      const newShape = {};
      for (const key in mask) {
        if (!(key in currDef.shape)) {
          throw new Error(`Unrecognized key: "${key}"`);
        }
        if (!mask[key])
          continue;
        newShape[key] = currDef.shape[key];
      }
      assignProp(this, "shape", newShape);
      return newShape;
    },
    checks: []
  });
  return clone(schema, def);
}
function omit(schema, mask) {
  const currDef = schema._zod.def;
  const checks = currDef.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    throw new Error(".omit() cannot be used on object schemas containing refinements");
  }
  const def = mergeDefs(schema._zod.def, {
    get shape() {
      const newShape = { ...schema._zod.def.shape };
      for (const key in mask) {
        if (!(key in currDef.shape)) {
          throw new Error(`Unrecognized key: "${key}"`);
        }
        if (!mask[key])
          continue;
        delete newShape[key];
      }
      assignProp(this, "shape", newShape);
      return newShape;
    },
    checks: []
  });
  return clone(schema, def);
}
function extend(schema, shape) {
  if (!isPlainObject(shape)) {
    throw new Error("Invalid input to extend: expected a plain object");
  }
  const checks = schema._zod.def.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    const existingShape = schema._zod.def.shape;
    for (const key in shape) {
      if (Object.getOwnPropertyDescriptor(existingShape, key) !== undefined) {
        throw new Error("Cannot overwrite keys on object schemas containing refinements. Use `.safeExtend()` instead.");
      }
    }
  }
  const def = mergeDefs(schema._zod.def, {
    get shape() {
      const _shape = { ...schema._zod.def.shape, ...shape };
      assignProp(this, "shape", _shape);
      return _shape;
    }
  });
  return clone(schema, def);
}
function safeExtend(schema, shape) {
  if (!isPlainObject(shape)) {
    throw new Error("Invalid input to safeExtend: expected a plain object");
  }
  const def = mergeDefs(schema._zod.def, {
    get shape() {
      const _shape = { ...schema._zod.def.shape, ...shape };
      assignProp(this, "shape", _shape);
      return _shape;
    }
  });
  return clone(schema, def);
}
function merge(a, b) {
  const def = mergeDefs(a._zod.def, {
    get shape() {
      const _shape = { ...a._zod.def.shape, ...b._zod.def.shape };
      assignProp(this, "shape", _shape);
      return _shape;
    },
    get catchall() {
      return b._zod.def.catchall;
    },
    checks: []
  });
  return clone(a, def);
}
function partial(Class, schema, mask) {
  const currDef = schema._zod.def;
  const checks = currDef.checks;
  const hasChecks = checks && checks.length > 0;
  if (hasChecks) {
    throw new Error(".partial() cannot be used on object schemas containing refinements");
  }
  const def = mergeDefs(schema._zod.def, {
    get shape() {
      const oldShape = schema._zod.def.shape;
      const shape = { ...oldShape };
      if (mask) {
        for (const key in mask) {
          if (!(key in oldShape)) {
            throw new Error(`Unrecognized key: "${key}"`);
          }
          if (!mask[key])
            continue;
          shape[key] = Class ? new Class({
            type: "optional",
            innerType: oldShape[key]
          }) : oldShape[key];
        }
      } else {
        for (const key in oldShape) {
          shape[key] = Class ? new Class({
            type: "optional",
            innerType: oldShape[key]
          }) : oldShape[key];
        }
      }
      assignProp(this, "shape", shape);
      return shape;
    },
    checks: []
  });
  return clone(schema, def);
}
function required(Class, schema, mask) {
  const def = mergeDefs(schema._zod.def, {
    get shape() {
      const oldShape = schema._zod.def.shape;
      const shape = { ...oldShape };
      if (mask) {
        for (const key in mask) {
          if (!(key in shape)) {
            throw new Error(`Unrecognized key: "${key}"`);
          }
          if (!mask[key])
            continue;
          shape[key] = new Class({
            type: "nonoptional",
            innerType: oldShape[key]
          });
        }
      } else {
        for (const key in oldShape) {
          shape[key] = new Class({
            type: "nonoptional",
            innerType: oldShape[key]
          });
        }
      }
      assignProp(this, "shape", shape);
      return shape;
    }
  });
  return clone(schema, def);
}
function aborted(x, startIndex = 0) {
  if (x.aborted === true)
    return true;
  for (let i = startIndex;i < x.issues.length; i++) {
    if (x.issues[i]?.continue !== true) {
      return true;
    }
  }
  return false;
}
function prefixIssues(path, issues) {
  return issues.map((iss) => {
    var _a;
    (_a = iss).path ?? (_a.path = []);
    iss.path.unshift(path);
    return iss;
  });
}
function unwrapMessage(message) {
  return typeof message === "string" ? message : message?.message;
}
function finalizeIssue(iss, ctx, config) {
  const full = { ...iss, path: iss.path ?? [] };
  if (!iss.message) {
    const message = unwrapMessage(iss.inst?._zod.def?.error?.(iss)) ?? unwrapMessage(ctx?.error?.(iss)) ?? unwrapMessage(config.customError?.(iss)) ?? unwrapMessage(config.localeError?.(iss)) ?? "Invalid input";
    full.message = message;
  }
  delete full.inst;
  delete full.continue;
  if (!ctx?.reportInput) {
    delete full.input;
  }
  return full;
}
function getLengthableOrigin(input) {
  if (Array.isArray(input))
    return "array";
  if (typeof input === "string")
    return "string";
  return "unknown";
}
function issue(...args) {
  const [iss, input, inst] = args;
  if (typeof iss === "string") {
    return {
      message: iss,
      code: "custom",
      input,
      inst
    };
  }
  return { ...iss };
}

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/errors.js
var initializer = (inst, def) => {
  inst.name = "$ZodError";
  Object.defineProperty(inst, "_zod", {
    value: inst._zod,
    enumerable: false
  });
  Object.defineProperty(inst, "issues", {
    value: def,
    enumerable: false
  });
  inst.message = JSON.stringify(def, jsonStringifyReplacer, 2);
  Object.defineProperty(inst, "toString", {
    value: () => inst.message,
    enumerable: false
  });
};
var $ZodError = $constructor("$ZodError", initializer);
var $ZodRealError = $constructor("$ZodError", initializer, { Parent: Error });
function flattenError(error, mapper = (issue) => issue.message) {
  const fieldErrors = {};
  const formErrors = [];
  for (const sub of error.issues) {
    if (sub.path.length > 0) {
      fieldErrors[sub.path[0]] = fieldErrors[sub.path[0]] || [];
      fieldErrors[sub.path[0]].push(mapper(sub));
    } else {
      formErrors.push(mapper(sub));
    }
  }
  return { formErrors, fieldErrors };
}
function formatError(error, mapper = (issue) => issue.message) {
  const fieldErrors = { _errors: [] };
  const processError = (error) => {
    for (const issue of error.issues) {
      if (issue.code === "invalid_union" && issue.errors.length) {
        issue.errors.map((issues) => processError({ issues }));
      } else if (issue.code === "invalid_key") {
        processError({ issues: issue.issues });
      } else if (issue.code === "invalid_element") {
        processError({ issues: issue.issues });
      } else if (issue.path.length === 0) {
        fieldErrors._errors.push(mapper(issue));
      } else {
        let curr = fieldErrors;
        let i = 0;
        while (i < issue.path.length) {
          const el = issue.path[i];
          const terminal = i === issue.path.length - 1;
          if (!terminal) {
            curr[el] = curr[el] || { _errors: [] };
          } else {
            curr[el] = curr[el] || { _errors: [] };
            curr[el]._errors.push(mapper(issue));
          }
          curr = curr[el];
          i++;
        }
      }
    }
  };
  processError(error);
  return fieldErrors;
}

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/parse.js
var _parse = (_Err) => (schema, value, _ctx, _params) => {
  const ctx = _ctx ? Object.assign(_ctx, { async: false }) : { async: false };
  const result = schema._zod.run({ value, issues: [] }, ctx);
  if (result instanceof Promise) {
    throw new $ZodAsyncError;
  }
  if (result.issues.length) {
    const e = new (_params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
    captureStackTrace(e, _params?.callee);
    throw e;
  }
  return result.value;
};
var _parseAsync = (_Err) => async (schema, value, _ctx, params) => {
  const ctx = _ctx ? Object.assign(_ctx, { async: true }) : { async: true };
  let result = schema._zod.run({ value, issues: [] }, ctx);
  if (result instanceof Promise)
    result = await result;
  if (result.issues.length) {
    const e = new (params?.Err ?? _Err)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())));
    captureStackTrace(e, params?.callee);
    throw e;
  }
  return result.value;
};
var _safeParse = (_Err) => (schema, value, _ctx) => {
  const ctx = _ctx ? { ..._ctx, async: false } : { async: false };
  const result = schema._zod.run({ value, issues: [] }, ctx);
  if (result instanceof Promise) {
    throw new $ZodAsyncError;
  }
  return result.issues.length ? {
    success: false,
    error: new (_Err ?? $ZodError)(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
  } : { success: true, data: result.value };
};
var safeParse = /* @__PURE__ */ _safeParse($ZodRealError);
var _safeParseAsync = (_Err) => async (schema, value, _ctx) => {
  const ctx = _ctx ? Object.assign(_ctx, { async: true }) : { async: true };
  let result = schema._zod.run({ value, issues: [] }, ctx);
  if (result instanceof Promise)
    result = await result;
  return result.issues.length ? {
    success: false,
    error: new _Err(result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
  } : { success: true, data: result.value };
};
var safeParseAsync = /* @__PURE__ */ _safeParseAsync($ZodRealError);
var _encode = (_Err) => (schema, value, _ctx) => {
  const ctx = _ctx ? Object.assign(_ctx, { direction: "backward" }) : { direction: "backward" };
  return _parse(_Err)(schema, value, ctx);
};
var _decode = (_Err) => (schema, value, _ctx) => {
  return _parse(_Err)(schema, value, _ctx);
};
var _encodeAsync = (_Err) => async (schema, value, _ctx) => {
  const ctx = _ctx ? Object.assign(_ctx, { direction: "backward" }) : { direction: "backward" };
  return _parseAsync(_Err)(schema, value, ctx);
};
var _decodeAsync = (_Err) => async (schema, value, _ctx) => {
  return _parseAsync(_Err)(schema, value, _ctx);
};
var _safeEncode = (_Err) => (schema, value, _ctx) => {
  const ctx = _ctx ? Object.assign(_ctx, { direction: "backward" }) : { direction: "backward" };
  return _safeParse(_Err)(schema, value, ctx);
};
var _safeDecode = (_Err) => (schema, value, _ctx) => {
  return _safeParse(_Err)(schema, value, _ctx);
};
var _safeEncodeAsync = (_Err) => async (schema, value, _ctx) => {
  const ctx = _ctx ? Object.assign(_ctx, { direction: "backward" }) : { direction: "backward" };
  return _safeParseAsync(_Err)(schema, value, ctx);
};
var _safeDecodeAsync = (_Err) => async (schema, value, _ctx) => {
  return _safeParseAsync(_Err)(schema, value, _ctx);
};
// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/regexes.js
var cuid = /^[cC][^\s-]{8,}$/;
var cuid2 = /^[0-9a-z]+$/;
var ulid = /^[0-9A-HJKMNP-TV-Za-hjkmnp-tv-z]{26}$/;
var xid = /^[0-9a-vA-V]{20}$/;
var ksuid = /^[A-Za-z0-9]{27}$/;
var nanoid = /^[a-zA-Z0-9_-]{21}$/;
var duration = /^P(?:(\d+W)|(?!.*W)(?=\d|T\d)(\d+Y)?(\d+M)?(\d+D)?(T(?=\d)(\d+H)?(\d+M)?(\d+([.,]\d+)?S)?)?)$/;
var guid = /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12})$/;
var uuid = (version) => {
  if (!version)
    return /^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[1-8][0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12}|00000000-0000-0000-0000-000000000000|ffffffff-ffff-ffff-ffff-ffffffffffff)$/;
  return new RegExp(`^([0-9a-fA-F]{8}-[0-9a-fA-F]{4}-${version}[0-9a-fA-F]{3}-[89abAB][0-9a-fA-F]{3}-[0-9a-fA-F]{12})$`);
};
var email = /^(?!\.)(?!.*\.\.)([A-Za-z0-9_'+\-\.]*)[A-Za-z0-9_+-]@([A-Za-z0-9][A-Za-z0-9\-]*\.)+[A-Za-z]{2,}$/;
var _emoji = `^(\\p{Extended_Pictographic}|\\p{Emoji_Component})+$`;
function emoji() {
  return new RegExp(_emoji, "u");
}
var ipv4 = /^(?:(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(?:25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])$/;
var ipv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,7}:|([0-9a-fA-F]{1,4}:){1,6}:[0-9a-fA-F]{1,4}|([0-9a-fA-F]{1,4}:){1,5}(:[0-9a-fA-F]{1,4}){1,2}|([0-9a-fA-F]{1,4}:){1,4}(:[0-9a-fA-F]{1,4}){1,3}|([0-9a-fA-F]{1,4}:){1,3}(:[0-9a-fA-F]{1,4}){1,4}|([0-9a-fA-F]{1,4}:){1,2}(:[0-9a-fA-F]{1,4}){1,5}|[0-9a-fA-F]{1,4}:((:[0-9a-fA-F]{1,4}){1,6})|:((:[0-9a-fA-F]{1,4}){1,7}|:))$/;
var cidrv4 = /^((25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\.){3}(25[0-5]|2[0-4][0-9]|1[0-9][0-9]|[1-9][0-9]|[0-9])\/([0-9]|[1-2][0-9]|3[0-2])$/;
var cidrv6 = /^(([0-9a-fA-F]{1,4}:){7}[0-9a-fA-F]{1,4}|::|([0-9a-fA-F]{1,4})?::([0-9a-fA-F]{1,4}:?){0,6})\/(12[0-8]|1[01][0-9]|[1-9]?[0-9])$/;
var base64 = /^$|^(?:[0-9a-zA-Z+/]{4})*(?:(?:[0-9a-zA-Z+/]{2}==)|(?:[0-9a-zA-Z+/]{3}=))?$/;
var base64url = /^[A-Za-z0-9_-]*$/;
var e164 = /^\+[1-9]\d{6,14}$/;
var dateSource = `(?:(?:\\d\\d[2468][048]|\\d\\d[13579][26]|\\d\\d0[48]|[02468][048]00|[13579][26]00)-02-29|\\d{4}-(?:(?:0[13578]|1[02])-(?:0[1-9]|[12]\\d|3[01])|(?:0[469]|11)-(?:0[1-9]|[12]\\d|30)|(?:02)-(?:0[1-9]|1\\d|2[0-8])))`;
var date = /* @__PURE__ */ new RegExp(`^${dateSource}$`);
function timeSource(args) {
  const hhmm = `(?:[01]\\d|2[0-3]):[0-5]\\d`;
  const regex = typeof args.precision === "number" ? args.precision === -1 ? `${hhmm}` : args.precision === 0 ? `${hhmm}:[0-5]\\d` : `${hhmm}:[0-5]\\d\\.\\d{${args.precision}}` : `${hhmm}(?::[0-5]\\d(?:\\.\\d+)?)?`;
  return regex;
}
function time(args) {
  return new RegExp(`^${timeSource(args)}$`);
}
function datetime(args) {
  const time = timeSource({ precision: args.precision });
  const opts = ["Z"];
  if (args.local)
    opts.push("");
  if (args.offset)
    opts.push(`([+-](?:[01]\\d|2[0-3]):[0-5]\\d)`);
  const timeRegex = `${time}(?:${opts.join("|")})`;
  return new RegExp(`^${dateSource}T(?:${timeRegex})$`);
}
var string = (params) => {
  const regex = params ? `[\\s\\S]{${params?.minimum ?? 0},${params?.maximum ?? ""}}` : `[\\s\\S]*`;
  return new RegExp(`^${regex}$`);
};
var integer3 = /^-?\d+$/;
var number = /^-?\d+(?:\.\d+)?$/;
var boolean = /^(?:true|false)$/i;
var lowercase = /^[^A-Z]*$/;
var uppercase = /^[^a-z]*$/;

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/checks.js
var $ZodCheck = /* @__PURE__ */ $constructor("$ZodCheck", (inst, def) => {
  var _a;
  inst._zod ?? (inst._zod = {});
  inst._zod.def = def;
  (_a = inst._zod).onattach ?? (_a.onattach = []);
});
var numericOriginMap = {
  number: "number",
  bigint: "bigint",
  object: "date"
};
var $ZodCheckLessThan = /* @__PURE__ */ $constructor("$ZodCheckLessThan", (inst, def) => {
  $ZodCheck.init(inst, def);
  const origin = numericOriginMap[typeof def.value];
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    const curr = (def.inclusive ? bag.maximum : bag.exclusiveMaximum) ?? Number.POSITIVE_INFINITY;
    if (def.value < curr) {
      if (def.inclusive)
        bag.maximum = def.value;
      else
        bag.exclusiveMaximum = def.value;
    }
  });
  inst._zod.check = (payload) => {
    if (def.inclusive ? payload.value <= def.value : payload.value < def.value) {
      return;
    }
    payload.issues.push({
      origin,
      code: "too_big",
      maximum: typeof def.value === "object" ? def.value.getTime() : def.value,
      input: payload.value,
      inclusive: def.inclusive,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckGreaterThan = /* @__PURE__ */ $constructor("$ZodCheckGreaterThan", (inst, def) => {
  $ZodCheck.init(inst, def);
  const origin = numericOriginMap[typeof def.value];
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    const curr = (def.inclusive ? bag.minimum : bag.exclusiveMinimum) ?? Number.NEGATIVE_INFINITY;
    if (def.value > curr) {
      if (def.inclusive)
        bag.minimum = def.value;
      else
        bag.exclusiveMinimum = def.value;
    }
  });
  inst._zod.check = (payload) => {
    if (def.inclusive ? payload.value >= def.value : payload.value > def.value) {
      return;
    }
    payload.issues.push({
      origin,
      code: "too_small",
      minimum: typeof def.value === "object" ? def.value.getTime() : def.value,
      input: payload.value,
      inclusive: def.inclusive,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckMultipleOf = /* @__PURE__ */ $constructor("$ZodCheckMultipleOf", (inst, def) => {
  $ZodCheck.init(inst, def);
  inst._zod.onattach.push((inst) => {
    var _a;
    (_a = inst._zod.bag).multipleOf ?? (_a.multipleOf = def.value);
  });
  inst._zod.check = (payload) => {
    if (typeof payload.value !== typeof def.value)
      throw new Error("Cannot mix number and bigint in multiple_of check.");
    const isMultiple = typeof payload.value === "bigint" ? payload.value % def.value === BigInt(0) : floatSafeRemainder(payload.value, def.value) === 0;
    if (isMultiple)
      return;
    payload.issues.push({
      origin: typeof payload.value,
      code: "not_multiple_of",
      divisor: def.value,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckNumberFormat = /* @__PURE__ */ $constructor("$ZodCheckNumberFormat", (inst, def) => {
  $ZodCheck.init(inst, def);
  def.format = def.format || "float64";
  const isInt = def.format?.includes("int");
  const origin = isInt ? "int" : "number";
  const [minimum, maximum] = NUMBER_FORMAT_RANGES[def.format];
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    bag.format = def.format;
    bag.minimum = minimum;
    bag.maximum = maximum;
    if (isInt)
      bag.pattern = integer3;
  });
  inst._zod.check = (payload) => {
    const input = payload.value;
    if (isInt) {
      if (!Number.isInteger(input)) {
        payload.issues.push({
          expected: origin,
          format: def.format,
          code: "invalid_type",
          continue: false,
          input,
          inst
        });
        return;
      }
      if (!Number.isSafeInteger(input)) {
        if (input > 0) {
          payload.issues.push({
            input,
            code: "too_big",
            maximum: Number.MAX_SAFE_INTEGER,
            note: "Integers must be within the safe integer range.",
            inst,
            origin,
            inclusive: true,
            continue: !def.abort
          });
        } else {
          payload.issues.push({
            input,
            code: "too_small",
            minimum: Number.MIN_SAFE_INTEGER,
            note: "Integers must be within the safe integer range.",
            inst,
            origin,
            inclusive: true,
            continue: !def.abort
          });
        }
        return;
      }
    }
    if (input < minimum) {
      payload.issues.push({
        origin: "number",
        input,
        code: "too_small",
        minimum,
        inclusive: true,
        inst,
        continue: !def.abort
      });
    }
    if (input > maximum) {
      payload.issues.push({
        origin: "number",
        input,
        code: "too_big",
        maximum,
        inclusive: true,
        inst,
        continue: !def.abort
      });
    }
  };
});
var $ZodCheckMaxLength = /* @__PURE__ */ $constructor("$ZodCheckMaxLength", (inst, def) => {
  var _a;
  $ZodCheck.init(inst, def);
  (_a = inst._zod.def).when ?? (_a.when = (payload) => {
    const val = payload.value;
    return !nullish(val) && val.length !== undefined;
  });
  inst._zod.onattach.push((inst) => {
    const curr = inst._zod.bag.maximum ?? Number.POSITIVE_INFINITY;
    if (def.maximum < curr)
      inst._zod.bag.maximum = def.maximum;
  });
  inst._zod.check = (payload) => {
    const input = payload.value;
    const length = input.length;
    if (length <= def.maximum)
      return;
    const origin = getLengthableOrigin(input);
    payload.issues.push({
      origin,
      code: "too_big",
      maximum: def.maximum,
      inclusive: true,
      input,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckMinLength = /* @__PURE__ */ $constructor("$ZodCheckMinLength", (inst, def) => {
  var _a;
  $ZodCheck.init(inst, def);
  (_a = inst._zod.def).when ?? (_a.when = (payload) => {
    const val = payload.value;
    return !nullish(val) && val.length !== undefined;
  });
  inst._zod.onattach.push((inst) => {
    const curr = inst._zod.bag.minimum ?? Number.NEGATIVE_INFINITY;
    if (def.minimum > curr)
      inst._zod.bag.minimum = def.minimum;
  });
  inst._zod.check = (payload) => {
    const input = payload.value;
    const length = input.length;
    if (length >= def.minimum)
      return;
    const origin = getLengthableOrigin(input);
    payload.issues.push({
      origin,
      code: "too_small",
      minimum: def.minimum,
      inclusive: true,
      input,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckLengthEquals = /* @__PURE__ */ $constructor("$ZodCheckLengthEquals", (inst, def) => {
  var _a;
  $ZodCheck.init(inst, def);
  (_a = inst._zod.def).when ?? (_a.when = (payload) => {
    const val = payload.value;
    return !nullish(val) && val.length !== undefined;
  });
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    bag.minimum = def.length;
    bag.maximum = def.length;
    bag.length = def.length;
  });
  inst._zod.check = (payload) => {
    const input = payload.value;
    const length = input.length;
    if (length === def.length)
      return;
    const origin = getLengthableOrigin(input);
    const tooBig = length > def.length;
    payload.issues.push({
      origin,
      ...tooBig ? { code: "too_big", maximum: def.length } : { code: "too_small", minimum: def.length },
      inclusive: true,
      exact: true,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckStringFormat = /* @__PURE__ */ $constructor("$ZodCheckStringFormat", (inst, def) => {
  var _a, _b;
  $ZodCheck.init(inst, def);
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    bag.format = def.format;
    if (def.pattern) {
      bag.patterns ?? (bag.patterns = new Set);
      bag.patterns.add(def.pattern);
    }
  });
  if (def.pattern)
    (_a = inst._zod).check ?? (_a.check = (payload) => {
      def.pattern.lastIndex = 0;
      if (def.pattern.test(payload.value))
        return;
      payload.issues.push({
        origin: "string",
        code: "invalid_format",
        format: def.format,
        input: payload.value,
        ...def.pattern ? { pattern: def.pattern.toString() } : {},
        inst,
        continue: !def.abort
      });
    });
  else
    (_b = inst._zod).check ?? (_b.check = () => {});
});
var $ZodCheckRegex = /* @__PURE__ */ $constructor("$ZodCheckRegex", (inst, def) => {
  $ZodCheckStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    def.pattern.lastIndex = 0;
    if (def.pattern.test(payload.value))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "regex",
      input: payload.value,
      pattern: def.pattern.toString(),
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckLowerCase = /* @__PURE__ */ $constructor("$ZodCheckLowerCase", (inst, def) => {
  def.pattern ?? (def.pattern = lowercase);
  $ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckUpperCase = /* @__PURE__ */ $constructor("$ZodCheckUpperCase", (inst, def) => {
  def.pattern ?? (def.pattern = uppercase);
  $ZodCheckStringFormat.init(inst, def);
});
var $ZodCheckIncludes = /* @__PURE__ */ $constructor("$ZodCheckIncludes", (inst, def) => {
  $ZodCheck.init(inst, def);
  const escapedRegex = escapeRegex(def.includes);
  const pattern = new RegExp(typeof def.position === "number" ? `^.{${def.position}}${escapedRegex}` : escapedRegex);
  def.pattern = pattern;
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    bag.patterns ?? (bag.patterns = new Set);
    bag.patterns.add(pattern);
  });
  inst._zod.check = (payload) => {
    if (payload.value.includes(def.includes, def.position))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "includes",
      includes: def.includes,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckStartsWith = /* @__PURE__ */ $constructor("$ZodCheckStartsWith", (inst, def) => {
  $ZodCheck.init(inst, def);
  const pattern = new RegExp(`^${escapeRegex(def.prefix)}.*`);
  def.pattern ?? (def.pattern = pattern);
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    bag.patterns ?? (bag.patterns = new Set);
    bag.patterns.add(pattern);
  });
  inst._zod.check = (payload) => {
    if (payload.value.startsWith(def.prefix))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "starts_with",
      prefix: def.prefix,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckEndsWith = /* @__PURE__ */ $constructor("$ZodCheckEndsWith", (inst, def) => {
  $ZodCheck.init(inst, def);
  const pattern = new RegExp(`.*${escapeRegex(def.suffix)}$`);
  def.pattern ?? (def.pattern = pattern);
  inst._zod.onattach.push((inst) => {
    const bag = inst._zod.bag;
    bag.patterns ?? (bag.patterns = new Set);
    bag.patterns.add(pattern);
  });
  inst._zod.check = (payload) => {
    if (payload.value.endsWith(def.suffix))
      return;
    payload.issues.push({
      origin: "string",
      code: "invalid_format",
      format: "ends_with",
      suffix: def.suffix,
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodCheckOverwrite = /* @__PURE__ */ $constructor("$ZodCheckOverwrite", (inst, def) => {
  $ZodCheck.init(inst, def);
  inst._zod.check = (payload) => {
    payload.value = def.tx(payload.value);
  };
});

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/doc.js
class Doc {
  constructor(args = []) {
    this.content = [];
    this.indent = 0;
    if (this)
      this.args = args;
  }
  indented(fn) {
    this.indent += 1;
    fn(this);
    this.indent -= 1;
  }
  write(arg) {
    if (typeof arg === "function") {
      arg(this, { execution: "sync" });
      arg(this, { execution: "async" });
      return;
    }
    const content = arg;
    const lines = content.split(`
`).filter((x) => x);
    const minIndent = Math.min(...lines.map((x) => x.length - x.trimStart().length));
    const dedented = lines.map((x) => x.slice(minIndent)).map((x) => " ".repeat(this.indent * 2) + x);
    for (const line of dedented) {
      this.content.push(line);
    }
  }
  compile() {
    const F = Function;
    const args = this?.args;
    const content = this?.content ?? [``];
    const lines = [...content.map((x) => `  ${x}`)];
    return new F(...args, lines.join(`
`));
  }
}

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/versions.js
var version2 = {
  major: 4,
  minor: 3,
  patch: 6
};

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/schemas.js
var $ZodType = /* @__PURE__ */ $constructor("$ZodType", (inst, def) => {
  var _a;
  inst ?? (inst = {});
  inst._zod.def = def;
  inst._zod.bag = inst._zod.bag || {};
  inst._zod.version = version2;
  const checks = [...inst._zod.def.checks ?? []];
  if (inst._zod.traits.has("$ZodCheck")) {
    checks.unshift(inst);
  }
  for (const ch of checks) {
    for (const fn of ch._zod.onattach) {
      fn(inst);
    }
  }
  if (checks.length === 0) {
    (_a = inst._zod).deferred ?? (_a.deferred = []);
    inst._zod.deferred?.push(() => {
      inst._zod.run = inst._zod.parse;
    });
  } else {
    const runChecks = (payload, checks, ctx) => {
      let isAborted = aborted(payload);
      let asyncResult;
      for (const ch of checks) {
        if (ch._zod.def.when) {
          const shouldRun = ch._zod.def.when(payload);
          if (!shouldRun)
            continue;
        } else if (isAborted) {
          continue;
        }
        const currLen = payload.issues.length;
        const _ = ch._zod.check(payload);
        if (_ instanceof Promise && ctx?.async === false) {
          throw new $ZodAsyncError;
        }
        if (asyncResult || _ instanceof Promise) {
          asyncResult = (asyncResult ?? Promise.resolve()).then(async () => {
            await _;
            const nextLen = payload.issues.length;
            if (nextLen === currLen)
              return;
            if (!isAborted)
              isAborted = aborted(payload, currLen);
          });
        } else {
          const nextLen = payload.issues.length;
          if (nextLen === currLen)
            continue;
          if (!isAborted)
            isAborted = aborted(payload, currLen);
        }
      }
      if (asyncResult) {
        return asyncResult.then(() => {
          return payload;
        });
      }
      return payload;
    };
    const handleCanaryResult = (canary, payload, ctx) => {
      if (aborted(canary)) {
        canary.aborted = true;
        return canary;
      }
      const checkResult = runChecks(payload, checks, ctx);
      if (checkResult instanceof Promise) {
        if (ctx.async === false)
          throw new $ZodAsyncError;
        return checkResult.then((checkResult) => inst._zod.parse(checkResult, ctx));
      }
      return inst._zod.parse(checkResult, ctx);
    };
    inst._zod.run = (payload, ctx) => {
      if (ctx.skipChecks) {
        return inst._zod.parse(payload, ctx);
      }
      if (ctx.direction === "backward") {
        const canary = inst._zod.parse({ value: payload.value, issues: [] }, { ...ctx, skipChecks: true });
        if (canary instanceof Promise) {
          return canary.then((canary) => {
            return handleCanaryResult(canary, payload, ctx);
          });
        }
        return handleCanaryResult(canary, payload, ctx);
      }
      const result = inst._zod.parse(payload, ctx);
      if (result instanceof Promise) {
        if (ctx.async === false)
          throw new $ZodAsyncError;
        return result.then((result) => runChecks(result, checks, ctx));
      }
      return runChecks(result, checks, ctx);
    };
  }
  defineLazy(inst, "~standard", () => ({
    validate: (value) => {
      try {
        const r = safeParse(inst, value);
        return r.success ? { value: r.data } : { issues: r.error?.issues };
      } catch (_) {
        return safeParseAsync(inst, value).then((r) => r.success ? { value: r.data } : { issues: r.error?.issues });
      }
    },
    vendor: "zod",
    version: 1
  }));
});
var $ZodString = /* @__PURE__ */ $constructor("$ZodString", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.pattern = [...inst?._zod.bag?.patterns ?? []].pop() ?? string(inst._zod.bag);
  inst._zod.parse = (payload, _) => {
    if (def.coerce)
      try {
        payload.value = String(payload.value);
      } catch (_) {}
    if (typeof payload.value === "string")
      return payload;
    payload.issues.push({
      expected: "string",
      code: "invalid_type",
      input: payload.value,
      inst
    });
    return payload;
  };
});
var $ZodStringFormat = /* @__PURE__ */ $constructor("$ZodStringFormat", (inst, def) => {
  $ZodCheckStringFormat.init(inst, def);
  $ZodString.init(inst, def);
});
var $ZodGUID = /* @__PURE__ */ $constructor("$ZodGUID", (inst, def) => {
  def.pattern ?? (def.pattern = guid);
  $ZodStringFormat.init(inst, def);
});
var $ZodUUID = /* @__PURE__ */ $constructor("$ZodUUID", (inst, def) => {
  if (def.version) {
    const versionMap = {
      v1: 1,
      v2: 2,
      v3: 3,
      v4: 4,
      v5: 5,
      v6: 6,
      v7: 7,
      v8: 8
    };
    const v = versionMap[def.version];
    if (v === undefined)
      throw new Error(`Invalid UUID version: "${def.version}"`);
    def.pattern ?? (def.pattern = uuid(v));
  } else
    def.pattern ?? (def.pattern = uuid());
  $ZodStringFormat.init(inst, def);
});
var $ZodEmail = /* @__PURE__ */ $constructor("$ZodEmail", (inst, def) => {
  def.pattern ?? (def.pattern = email);
  $ZodStringFormat.init(inst, def);
});
var $ZodURL = /* @__PURE__ */ $constructor("$ZodURL", (inst, def) => {
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    try {
      const trimmed = payload.value.trim();
      const url = new URL(trimmed);
      if (def.hostname) {
        def.hostname.lastIndex = 0;
        if (!def.hostname.test(url.hostname)) {
          payload.issues.push({
            code: "invalid_format",
            format: "url",
            note: "Invalid hostname",
            pattern: def.hostname.source,
            input: payload.value,
            inst,
            continue: !def.abort
          });
        }
      }
      if (def.protocol) {
        def.protocol.lastIndex = 0;
        if (!def.protocol.test(url.protocol.endsWith(":") ? url.protocol.slice(0, -1) : url.protocol)) {
          payload.issues.push({
            code: "invalid_format",
            format: "url",
            note: "Invalid protocol",
            pattern: def.protocol.source,
            input: payload.value,
            inst,
            continue: !def.abort
          });
        }
      }
      if (def.normalize) {
        payload.value = url.href;
      } else {
        payload.value = trimmed;
      }
      return;
    } catch (_) {
      payload.issues.push({
        code: "invalid_format",
        format: "url",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    }
  };
});
var $ZodEmoji = /* @__PURE__ */ $constructor("$ZodEmoji", (inst, def) => {
  def.pattern ?? (def.pattern = emoji());
  $ZodStringFormat.init(inst, def);
});
var $ZodNanoID = /* @__PURE__ */ $constructor("$ZodNanoID", (inst, def) => {
  def.pattern ?? (def.pattern = nanoid);
  $ZodStringFormat.init(inst, def);
});
var $ZodCUID = /* @__PURE__ */ $constructor("$ZodCUID", (inst, def) => {
  def.pattern ?? (def.pattern = cuid);
  $ZodStringFormat.init(inst, def);
});
var $ZodCUID2 = /* @__PURE__ */ $constructor("$ZodCUID2", (inst, def) => {
  def.pattern ?? (def.pattern = cuid2);
  $ZodStringFormat.init(inst, def);
});
var $ZodULID = /* @__PURE__ */ $constructor("$ZodULID", (inst, def) => {
  def.pattern ?? (def.pattern = ulid);
  $ZodStringFormat.init(inst, def);
});
var $ZodXID = /* @__PURE__ */ $constructor("$ZodXID", (inst, def) => {
  def.pattern ?? (def.pattern = xid);
  $ZodStringFormat.init(inst, def);
});
var $ZodKSUID = /* @__PURE__ */ $constructor("$ZodKSUID", (inst, def) => {
  def.pattern ?? (def.pattern = ksuid);
  $ZodStringFormat.init(inst, def);
});
var $ZodISODateTime = /* @__PURE__ */ $constructor("$ZodISODateTime", (inst, def) => {
  def.pattern ?? (def.pattern = datetime(def));
  $ZodStringFormat.init(inst, def);
});
var $ZodISODate = /* @__PURE__ */ $constructor("$ZodISODate", (inst, def) => {
  def.pattern ?? (def.pattern = date);
  $ZodStringFormat.init(inst, def);
});
var $ZodISOTime = /* @__PURE__ */ $constructor("$ZodISOTime", (inst, def) => {
  def.pattern ?? (def.pattern = time(def));
  $ZodStringFormat.init(inst, def);
});
var $ZodISODuration = /* @__PURE__ */ $constructor("$ZodISODuration", (inst, def) => {
  def.pattern ?? (def.pattern = duration);
  $ZodStringFormat.init(inst, def);
});
var $ZodIPv4 = /* @__PURE__ */ $constructor("$ZodIPv4", (inst, def) => {
  def.pattern ?? (def.pattern = ipv4);
  $ZodStringFormat.init(inst, def);
  inst._zod.bag.format = `ipv4`;
});
var $ZodIPv6 = /* @__PURE__ */ $constructor("$ZodIPv6", (inst, def) => {
  def.pattern ?? (def.pattern = ipv6);
  $ZodStringFormat.init(inst, def);
  inst._zod.bag.format = `ipv6`;
  inst._zod.check = (payload) => {
    try {
      new URL(`http://[${payload.value}]`);
    } catch {
      payload.issues.push({
        code: "invalid_format",
        format: "ipv6",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    }
  };
});
var $ZodCIDRv4 = /* @__PURE__ */ $constructor("$ZodCIDRv4", (inst, def) => {
  def.pattern ?? (def.pattern = cidrv4);
  $ZodStringFormat.init(inst, def);
});
var $ZodCIDRv6 = /* @__PURE__ */ $constructor("$ZodCIDRv6", (inst, def) => {
  def.pattern ?? (def.pattern = cidrv6);
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    const parts = payload.value.split("/");
    try {
      if (parts.length !== 2)
        throw new Error;
      const [address, prefix] = parts;
      if (!prefix)
        throw new Error;
      const prefixNum = Number(prefix);
      if (`${prefixNum}` !== prefix)
        throw new Error;
      if (prefixNum < 0 || prefixNum > 128)
        throw new Error;
      new URL(`http://[${address}]`);
    } catch {
      payload.issues.push({
        code: "invalid_format",
        format: "cidrv6",
        input: payload.value,
        inst,
        continue: !def.abort
      });
    }
  };
});
function isValidBase64(data) {
  if (data === "")
    return true;
  if (data.length % 4 !== 0)
    return false;
  try {
    atob(data);
    return true;
  } catch {
    return false;
  }
}
var $ZodBase64 = /* @__PURE__ */ $constructor("$ZodBase64", (inst, def) => {
  def.pattern ?? (def.pattern = base64);
  $ZodStringFormat.init(inst, def);
  inst._zod.bag.contentEncoding = "base64";
  inst._zod.check = (payload) => {
    if (isValidBase64(payload.value))
      return;
    payload.issues.push({
      code: "invalid_format",
      format: "base64",
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
function isValidBase64URL(data) {
  if (!base64url.test(data))
    return false;
  const base64 = data.replace(/[-_]/g, (c) => c === "-" ? "+" : "/");
  const padded = base64.padEnd(Math.ceil(base64.length / 4) * 4, "=");
  return isValidBase64(padded);
}
var $ZodBase64URL = /* @__PURE__ */ $constructor("$ZodBase64URL", (inst, def) => {
  def.pattern ?? (def.pattern = base64url);
  $ZodStringFormat.init(inst, def);
  inst._zod.bag.contentEncoding = "base64url";
  inst._zod.check = (payload) => {
    if (isValidBase64URL(payload.value))
      return;
    payload.issues.push({
      code: "invalid_format",
      format: "base64url",
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodE164 = /* @__PURE__ */ $constructor("$ZodE164", (inst, def) => {
  def.pattern ?? (def.pattern = e164);
  $ZodStringFormat.init(inst, def);
});
function isValidJWT(token, algorithm = null) {
  try {
    const tokensParts = token.split(".");
    if (tokensParts.length !== 3)
      return false;
    const [header] = tokensParts;
    if (!header)
      return false;
    const parsedHeader = JSON.parse(atob(header));
    if ("typ" in parsedHeader && parsedHeader?.typ !== "JWT")
      return false;
    if (!parsedHeader.alg)
      return false;
    if (algorithm && (!("alg" in parsedHeader) || parsedHeader.alg !== algorithm))
      return false;
    return true;
  } catch {
    return false;
  }
}
var $ZodJWT = /* @__PURE__ */ $constructor("$ZodJWT", (inst, def) => {
  $ZodStringFormat.init(inst, def);
  inst._zod.check = (payload) => {
    if (isValidJWT(payload.value, def.alg))
      return;
    payload.issues.push({
      code: "invalid_format",
      format: "jwt",
      input: payload.value,
      inst,
      continue: !def.abort
    });
  };
});
var $ZodNumber = /* @__PURE__ */ $constructor("$ZodNumber", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.pattern = inst._zod.bag.pattern ?? number;
  inst._zod.parse = (payload, _ctx) => {
    if (def.coerce)
      try {
        payload.value = Number(payload.value);
      } catch (_) {}
    const input = payload.value;
    if (typeof input === "number" && !Number.isNaN(input) && Number.isFinite(input)) {
      return payload;
    }
    const received = typeof input === "number" ? Number.isNaN(input) ? "NaN" : !Number.isFinite(input) ? "Infinity" : undefined : undefined;
    payload.issues.push({
      expected: "number",
      code: "invalid_type",
      input,
      inst,
      ...received ? { received } : {}
    });
    return payload;
  };
});
var $ZodNumberFormat = /* @__PURE__ */ $constructor("$ZodNumberFormat", (inst, def) => {
  $ZodCheckNumberFormat.init(inst, def);
  $ZodNumber.init(inst, def);
});
var $ZodBoolean = /* @__PURE__ */ $constructor("$ZodBoolean", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.pattern = boolean;
  inst._zod.parse = (payload, _ctx) => {
    if (def.coerce)
      try {
        payload.value = Boolean(payload.value);
      } catch (_) {}
    const input = payload.value;
    if (typeof input === "boolean")
      return payload;
    payload.issues.push({
      expected: "boolean",
      code: "invalid_type",
      input,
      inst
    });
    return payload;
  };
});
var $ZodUnknown = /* @__PURE__ */ $constructor("$ZodUnknown", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload) => payload;
});
var $ZodNever = /* @__PURE__ */ $constructor("$ZodNever", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, _ctx) => {
    payload.issues.push({
      expected: "never",
      code: "invalid_type",
      input: payload.value,
      inst
    });
    return payload;
  };
});
function handleArrayResult(result, final, index) {
  if (result.issues.length) {
    final.issues.push(...prefixIssues(index, result.issues));
  }
  final.value[index] = result.value;
}
var $ZodArray = /* @__PURE__ */ $constructor("$ZodArray", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, ctx) => {
    const input = payload.value;
    if (!Array.isArray(input)) {
      payload.issues.push({
        expected: "array",
        code: "invalid_type",
        input,
        inst
      });
      return payload;
    }
    payload.value = Array(input.length);
    const proms = [];
    for (let i = 0;i < input.length; i++) {
      const item = input[i];
      const result = def.element._zod.run({
        value: item,
        issues: []
      }, ctx);
      if (result instanceof Promise) {
        proms.push(result.then((result) => handleArrayResult(result, payload, i)));
      } else {
        handleArrayResult(result, payload, i);
      }
    }
    if (proms.length) {
      return Promise.all(proms).then(() => payload);
    }
    return payload;
  };
});
function handlePropertyResult(result, final, key, input, isOptionalOut) {
  if (result.issues.length) {
    if (isOptionalOut && !(key in input)) {
      return;
    }
    final.issues.push(...prefixIssues(key, result.issues));
  }
  if (result.value === undefined) {
    if (key in input) {
      final.value[key] = undefined;
    }
  } else {
    final.value[key] = result.value;
  }
}
function normalizeDef(def) {
  const keys = Object.keys(def.shape);
  for (const k of keys) {
    if (!def.shape?.[k]?._zod?.traits?.has("$ZodType")) {
      throw new Error(`Invalid element at key "${k}": expected a Zod schema`);
    }
  }
  const okeys = optionalKeys(def.shape);
  return {
    ...def,
    keys,
    keySet: new Set(keys),
    numKeys: keys.length,
    optionalKeys: new Set(okeys)
  };
}
function handleCatchall(proms, input, payload, ctx, def, inst) {
  const unrecognized = [];
  const keySet = def.keySet;
  const _catchall = def.catchall._zod;
  const t = _catchall.def.type;
  const isOptionalOut = _catchall.optout === "optional";
  for (const key in input) {
    if (keySet.has(key))
      continue;
    if (t === "never") {
      unrecognized.push(key);
      continue;
    }
    const r = _catchall.run({ value: input[key], issues: [] }, ctx);
    if (r instanceof Promise) {
      proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, isOptionalOut)));
    } else {
      handlePropertyResult(r, payload, key, input, isOptionalOut);
    }
  }
  if (unrecognized.length) {
    payload.issues.push({
      code: "unrecognized_keys",
      keys: unrecognized,
      input,
      inst
    });
  }
  if (!proms.length)
    return payload;
  return Promise.all(proms).then(() => {
    return payload;
  });
}
var $ZodObject = /* @__PURE__ */ $constructor("$ZodObject", (inst, def) => {
  $ZodType.init(inst, def);
  const desc = Object.getOwnPropertyDescriptor(def, "shape");
  if (!desc?.get) {
    const sh = def.shape;
    Object.defineProperty(def, "shape", {
      get: () => {
        const newSh = { ...sh };
        Object.defineProperty(def, "shape", {
          value: newSh
        });
        return newSh;
      }
    });
  }
  const _normalized = cached(() => normalizeDef(def));
  defineLazy(inst._zod, "propValues", () => {
    const shape = def.shape;
    const propValues = {};
    for (const key in shape) {
      const field = shape[key]._zod;
      if (field.values) {
        propValues[key] ?? (propValues[key] = new Set);
        for (const v of field.values)
          propValues[key].add(v);
      }
    }
    return propValues;
  });
  const isObject = isObject2;
  const catchall = def.catchall;
  let value;
  inst._zod.parse = (payload, ctx) => {
    value ?? (value = _normalized.value);
    const input = payload.value;
    if (!isObject(input)) {
      payload.issues.push({
        expected: "object",
        code: "invalid_type",
        input,
        inst
      });
      return payload;
    }
    payload.value = {};
    const proms = [];
    const shape = value.shape;
    for (const key of value.keys) {
      const el = shape[key];
      const isOptionalOut = el._zod.optout === "optional";
      const r = el._zod.run({ value: input[key], issues: [] }, ctx);
      if (r instanceof Promise) {
        proms.push(r.then((r) => handlePropertyResult(r, payload, key, input, isOptionalOut)));
      } else {
        handlePropertyResult(r, payload, key, input, isOptionalOut);
      }
    }
    if (!catchall) {
      return proms.length ? Promise.all(proms).then(() => payload) : payload;
    }
    return handleCatchall(proms, input, payload, ctx, _normalized.value, inst);
  };
});
var $ZodObjectJIT = /* @__PURE__ */ $constructor("$ZodObjectJIT", (inst, def) => {
  $ZodObject.init(inst, def);
  const superParse = inst._zod.parse;
  const _normalized = cached(() => normalizeDef(def));
  const generateFastpass = (shape) => {
    const doc = new Doc(["shape", "payload", "ctx"]);
    const normalized = _normalized.value;
    const parseStr = (key) => {
      const k = esc(key);
      return `shape[${k}]._zod.run({ value: input[${k}], issues: [] }, ctx)`;
    };
    doc.write(`const input = payload.value;`);
    const ids = Object.create(null);
    let counter = 0;
    for (const key of normalized.keys) {
      ids[key] = `key_${counter++}`;
    }
    doc.write(`const newResult = {};`);
    for (const key of normalized.keys) {
      const id = ids[key];
      const k = esc(key);
      const schema = shape[key];
      const isOptionalOut = schema?._zod?.optout === "optional";
      doc.write(`const ${id} = ${parseStr(key)};`);
      if (isOptionalOut) {
        doc.write(`
        if (${id}.issues.length) {
          if (${k} in input) {
            payload.issues = payload.issues.concat(${id}.issues.map(iss => ({
              ...iss,
              path: iss.path ? [${k}, ...iss.path] : [${k}]
            })));
          }
        }
        
        if (${id}.value === undefined) {
          if (${k} in input) {
            newResult[${k}] = undefined;
          }
        } else {
          newResult[${k}] = ${id}.value;
        }
        
      `);
      } else {
        doc.write(`
        if (${id}.issues.length) {
          payload.issues = payload.issues.concat(${id}.issues.map(iss => ({
            ...iss,
            path: iss.path ? [${k}, ...iss.path] : [${k}]
          })));
        }
        
        if (${id}.value === undefined) {
          if (${k} in input) {
            newResult[${k}] = undefined;
          }
        } else {
          newResult[${k}] = ${id}.value;
        }
        
      `);
      }
    }
    doc.write(`payload.value = newResult;`);
    doc.write(`return payload;`);
    const fn = doc.compile();
    return (payload, ctx) => fn(shape, payload, ctx);
  };
  let fastpass;
  const isObject = isObject2;
  const jit = !globalConfig.jitless;
  const allowsEval2 = allowsEval;
  const fastEnabled = jit && allowsEval2.value;
  const catchall = def.catchall;
  let value;
  inst._zod.parse = (payload, ctx) => {
    value ?? (value = _normalized.value);
    const input = payload.value;
    if (!isObject(input)) {
      payload.issues.push({
        expected: "object",
        code: "invalid_type",
        input,
        inst
      });
      return payload;
    }
    if (jit && fastEnabled && ctx?.async === false && ctx.jitless !== true) {
      if (!fastpass)
        fastpass = generateFastpass(def.shape);
      payload = fastpass(payload, ctx);
      if (!catchall)
        return payload;
      return handleCatchall([], input, payload, ctx, value, inst);
    }
    return superParse(payload, ctx);
  };
});
function handleUnionResults(results, final, inst, ctx) {
  for (const result of results) {
    if (result.issues.length === 0) {
      final.value = result.value;
      return final;
    }
  }
  const nonaborted = results.filter((r) => !aborted(r));
  if (nonaborted.length === 1) {
    final.value = nonaborted[0].value;
    return nonaborted[0];
  }
  final.issues.push({
    code: "invalid_union",
    input: final.value,
    inst,
    errors: results.map((result) => result.issues.map((iss) => finalizeIssue(iss, ctx, config())))
  });
  return final;
}
var $ZodUnion = /* @__PURE__ */ $constructor("$ZodUnion", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazy(inst._zod, "optin", () => def.options.some((o) => o._zod.optin === "optional") ? "optional" : undefined);
  defineLazy(inst._zod, "optout", () => def.options.some((o) => o._zod.optout === "optional") ? "optional" : undefined);
  defineLazy(inst._zod, "values", () => {
    if (def.options.every((o) => o._zod.values)) {
      return new Set(def.options.flatMap((option) => Array.from(option._zod.values)));
    }
    return;
  });
  defineLazy(inst._zod, "pattern", () => {
    if (def.options.every((o) => o._zod.pattern)) {
      const patterns = def.options.map((o) => o._zod.pattern);
      return new RegExp(`^(${patterns.map((p) => cleanRegex(p.source)).join("|")})$`);
    }
    return;
  });
  const single = def.options.length === 1;
  const first = def.options[0]._zod.run;
  inst._zod.parse = (payload, ctx) => {
    if (single) {
      return first(payload, ctx);
    }
    let async = false;
    const results = [];
    for (const option of def.options) {
      const result = option._zod.run({
        value: payload.value,
        issues: []
      }, ctx);
      if (result instanceof Promise) {
        results.push(result);
        async = true;
      } else {
        if (result.issues.length === 0)
          return result;
        results.push(result);
      }
    }
    if (!async)
      return handleUnionResults(results, payload, inst, ctx);
    return Promise.all(results).then((results) => {
      return handleUnionResults(results, payload, inst, ctx);
    });
  };
});
var $ZodIntersection = /* @__PURE__ */ $constructor("$ZodIntersection", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, ctx) => {
    const input = payload.value;
    const left = def.left._zod.run({ value: input, issues: [] }, ctx);
    const right = def.right._zod.run({ value: input, issues: [] }, ctx);
    const async = left instanceof Promise || right instanceof Promise;
    if (async) {
      return Promise.all([left, right]).then(([left, right]) => {
        return handleIntersectionResults(payload, left, right);
      });
    }
    return handleIntersectionResults(payload, left, right);
  };
});
function mergeValues(a, b) {
  if (a === b) {
    return { valid: true, data: a };
  }
  if (a instanceof Date && b instanceof Date && +a === +b) {
    return { valid: true, data: a };
  }
  if (isPlainObject(a) && isPlainObject(b)) {
    const bKeys = Object.keys(b);
    const sharedKeys = Object.keys(a).filter((key) => bKeys.indexOf(key) !== -1);
    const newObj = { ...a, ...b };
    for (const key of sharedKeys) {
      const sharedValue = mergeValues(a[key], b[key]);
      if (!sharedValue.valid) {
        return {
          valid: false,
          mergeErrorPath: [key, ...sharedValue.mergeErrorPath]
        };
      }
      newObj[key] = sharedValue.data;
    }
    return { valid: true, data: newObj };
  }
  if (Array.isArray(a) && Array.isArray(b)) {
    if (a.length !== b.length) {
      return { valid: false, mergeErrorPath: [] };
    }
    const newArray = [];
    for (let index = 0;index < a.length; index++) {
      const itemA = a[index];
      const itemB = b[index];
      const sharedValue = mergeValues(itemA, itemB);
      if (!sharedValue.valid) {
        return {
          valid: false,
          mergeErrorPath: [index, ...sharedValue.mergeErrorPath]
        };
      }
      newArray.push(sharedValue.data);
    }
    return { valid: true, data: newArray };
  }
  return { valid: false, mergeErrorPath: [] };
}
function handleIntersectionResults(result, left, right) {
  const unrecKeys = new Map;
  let unrecIssue;
  for (const iss of left.issues) {
    if (iss.code === "unrecognized_keys") {
      unrecIssue ?? (unrecIssue = iss);
      for (const k of iss.keys) {
        if (!unrecKeys.has(k))
          unrecKeys.set(k, {});
        unrecKeys.get(k).l = true;
      }
    } else {
      result.issues.push(iss);
    }
  }
  for (const iss of right.issues) {
    if (iss.code === "unrecognized_keys") {
      for (const k of iss.keys) {
        if (!unrecKeys.has(k))
          unrecKeys.set(k, {});
        unrecKeys.get(k).r = true;
      }
    } else {
      result.issues.push(iss);
    }
  }
  const bothKeys = [...unrecKeys].filter(([, f]) => f.l && f.r).map(([k]) => k);
  if (bothKeys.length && unrecIssue) {
    result.issues.push({ ...unrecIssue, keys: bothKeys });
  }
  if (aborted(result))
    return result;
  const merged = mergeValues(left.value, right.value);
  if (!merged.valid) {
    throw new Error(`Unmergable intersection. Error path: ` + `${JSON.stringify(merged.mergeErrorPath)}`);
  }
  result.value = merged.data;
  return result;
}
var $ZodEnum = /* @__PURE__ */ $constructor("$ZodEnum", (inst, def) => {
  $ZodType.init(inst, def);
  const values = getEnumValues(def.entries);
  const valuesSet = new Set(values);
  inst._zod.values = valuesSet;
  inst._zod.pattern = new RegExp(`^(${values.filter((k) => propertyKeyTypes.has(typeof k)).map((o) => typeof o === "string" ? escapeRegex(o) : o.toString()).join("|")})$`);
  inst._zod.parse = (payload, _ctx) => {
    const input = payload.value;
    if (valuesSet.has(input)) {
      return payload;
    }
    payload.issues.push({
      code: "invalid_value",
      values,
      input,
      inst
    });
    return payload;
  };
});
var $ZodTransform = /* @__PURE__ */ $constructor("$ZodTransform", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      throw new $ZodEncodeError(inst.constructor.name);
    }
    const _out = def.transform(payload.value, payload);
    if (ctx.async) {
      const output = _out instanceof Promise ? _out : Promise.resolve(_out);
      return output.then((output) => {
        payload.value = output;
        return payload;
      });
    }
    if (_out instanceof Promise) {
      throw new $ZodAsyncError;
    }
    payload.value = _out;
    return payload;
  };
});
function handleOptionalResult(result, input) {
  if (result.issues.length && input === undefined) {
    return { issues: [], value: undefined };
  }
  return result;
}
var $ZodOptional = /* @__PURE__ */ $constructor("$ZodOptional", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.optin = "optional";
  inst._zod.optout = "optional";
  defineLazy(inst._zod, "values", () => {
    return def.innerType._zod.values ? new Set([...def.innerType._zod.values, undefined]) : undefined;
  });
  defineLazy(inst._zod, "pattern", () => {
    const pattern = def.innerType._zod.pattern;
    return pattern ? new RegExp(`^(${cleanRegex(pattern.source)})?$`) : undefined;
  });
  inst._zod.parse = (payload, ctx) => {
    if (def.innerType._zod.optin === "optional") {
      const result = def.innerType._zod.run(payload, ctx);
      if (result instanceof Promise)
        return result.then((r) => handleOptionalResult(r, payload.value));
      return handleOptionalResult(result, payload.value);
    }
    if (payload.value === undefined) {
      return payload;
    }
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodExactOptional = /* @__PURE__ */ $constructor("$ZodExactOptional", (inst, def) => {
  $ZodOptional.init(inst, def);
  defineLazy(inst._zod, "values", () => def.innerType._zod.values);
  defineLazy(inst._zod, "pattern", () => def.innerType._zod.pattern);
  inst._zod.parse = (payload, ctx) => {
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodNullable = /* @__PURE__ */ $constructor("$ZodNullable", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazy(inst._zod, "optin", () => def.innerType._zod.optin);
  defineLazy(inst._zod, "optout", () => def.innerType._zod.optout);
  defineLazy(inst._zod, "pattern", () => {
    const pattern = def.innerType._zod.pattern;
    return pattern ? new RegExp(`^(${cleanRegex(pattern.source)}|null)$`) : undefined;
  });
  defineLazy(inst._zod, "values", () => {
    return def.innerType._zod.values ? new Set([...def.innerType._zod.values, null]) : undefined;
  });
  inst._zod.parse = (payload, ctx) => {
    if (payload.value === null)
      return payload;
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodDefault = /* @__PURE__ */ $constructor("$ZodDefault", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.optin = "optional";
  defineLazy(inst._zod, "values", () => def.innerType._zod.values);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    if (payload.value === undefined) {
      payload.value = def.defaultValue;
      return payload;
    }
    const result = def.innerType._zod.run(payload, ctx);
    if (result instanceof Promise) {
      return result.then((result) => handleDefaultResult(result, def));
    }
    return handleDefaultResult(result, def);
  };
});
function handleDefaultResult(payload, def) {
  if (payload.value === undefined) {
    payload.value = def.defaultValue;
  }
  return payload;
}
var $ZodPrefault = /* @__PURE__ */ $constructor("$ZodPrefault", (inst, def) => {
  $ZodType.init(inst, def);
  inst._zod.optin = "optional";
  defineLazy(inst._zod, "values", () => def.innerType._zod.values);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    if (payload.value === undefined) {
      payload.value = def.defaultValue;
    }
    return def.innerType._zod.run(payload, ctx);
  };
});
var $ZodNonOptional = /* @__PURE__ */ $constructor("$ZodNonOptional", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazy(inst._zod, "values", () => {
    const v = def.innerType._zod.values;
    return v ? new Set([...v].filter((x) => x !== undefined)) : undefined;
  });
  inst._zod.parse = (payload, ctx) => {
    const result = def.innerType._zod.run(payload, ctx);
    if (result instanceof Promise) {
      return result.then((result) => handleNonOptionalResult(result, inst));
    }
    return handleNonOptionalResult(result, inst);
  };
});
function handleNonOptionalResult(payload, inst) {
  if (!payload.issues.length && payload.value === undefined) {
    payload.issues.push({
      code: "invalid_type",
      expected: "nonoptional",
      input: payload.value,
      inst
    });
  }
  return payload;
}
var $ZodCatch = /* @__PURE__ */ $constructor("$ZodCatch", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazy(inst._zod, "optin", () => def.innerType._zod.optin);
  defineLazy(inst._zod, "optout", () => def.innerType._zod.optout);
  defineLazy(inst._zod, "values", () => def.innerType._zod.values);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    const result = def.innerType._zod.run(payload, ctx);
    if (result instanceof Promise) {
      return result.then((result) => {
        payload.value = result.value;
        if (result.issues.length) {
          payload.value = def.catchValue({
            ...payload,
            error: {
              issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config()))
            },
            input: payload.value
          });
          payload.issues = [];
        }
        return payload;
      });
    }
    payload.value = result.value;
    if (result.issues.length) {
      payload.value = def.catchValue({
        ...payload,
        error: {
          issues: result.issues.map((iss) => finalizeIssue(iss, ctx, config()))
        },
        input: payload.value
      });
      payload.issues = [];
    }
    return payload;
  };
});
var $ZodPipe = /* @__PURE__ */ $constructor("$ZodPipe", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazy(inst._zod, "values", () => def.in._zod.values);
  defineLazy(inst._zod, "optin", () => def.in._zod.optin);
  defineLazy(inst._zod, "optout", () => def.out._zod.optout);
  defineLazy(inst._zod, "propValues", () => def.in._zod.propValues);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      const right = def.out._zod.run(payload, ctx);
      if (right instanceof Promise) {
        return right.then((right) => handlePipeResult(right, def.in, ctx));
      }
      return handlePipeResult(right, def.in, ctx);
    }
    const left = def.in._zod.run(payload, ctx);
    if (left instanceof Promise) {
      return left.then((left) => handlePipeResult(left, def.out, ctx));
    }
    return handlePipeResult(left, def.out, ctx);
  };
});
function handlePipeResult(left, next, ctx) {
  if (left.issues.length) {
    left.aborted = true;
    return left;
  }
  return next._zod.run({ value: left.value, issues: left.issues }, ctx);
}
var $ZodReadonly = /* @__PURE__ */ $constructor("$ZodReadonly", (inst, def) => {
  $ZodType.init(inst, def);
  defineLazy(inst._zod, "propValues", () => def.innerType._zod.propValues);
  defineLazy(inst._zod, "values", () => def.innerType._zod.values);
  defineLazy(inst._zod, "optin", () => def.innerType?._zod?.optin);
  defineLazy(inst._zod, "optout", () => def.innerType?._zod?.optout);
  inst._zod.parse = (payload, ctx) => {
    if (ctx.direction === "backward") {
      return def.innerType._zod.run(payload, ctx);
    }
    const result = def.innerType._zod.run(payload, ctx);
    if (result instanceof Promise) {
      return result.then(handleReadonlyResult);
    }
    return handleReadonlyResult(result);
  };
});
function handleReadonlyResult(payload) {
  payload.value = Object.freeze(payload.value);
  return payload;
}
var $ZodCustom = /* @__PURE__ */ $constructor("$ZodCustom", (inst, def) => {
  $ZodCheck.init(inst, def);
  $ZodType.init(inst, def);
  inst._zod.parse = (payload, _) => {
    return payload;
  };
  inst._zod.check = (payload) => {
    const input = payload.value;
    const r = def.fn(input);
    if (r instanceof Promise) {
      return r.then((r) => handleRefineResult(r, payload, input, inst));
    }
    handleRefineResult(r, payload, input, inst);
    return;
  };
});
function handleRefineResult(result, payload, input, inst) {
  if (!result) {
    const _iss = {
      code: "custom",
      input,
      inst,
      path: [...inst._zod.def.path ?? []],
      continue: !inst._zod.def.abort
    };
    if (inst._zod.def.params)
      _iss.params = inst._zod.def.params;
    payload.issues.push(issue(_iss));
  }
}
// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/registries.js
var _a;
var $output = Symbol("ZodOutput");
var $input = Symbol("ZodInput");

class $ZodRegistry {
  constructor() {
    this._map = new WeakMap;
    this._idmap = new Map;
  }
  add(schema, ..._meta) {
    const meta = _meta[0];
    this._map.set(schema, meta);
    if (meta && typeof meta === "object" && "id" in meta) {
      this._idmap.set(meta.id, schema);
    }
    return this;
  }
  clear() {
    this._map = new WeakMap;
    this._idmap = new Map;
    return this;
  }
  remove(schema) {
    const meta = this._map.get(schema);
    if (meta && typeof meta === "object" && "id" in meta) {
      this._idmap.delete(meta.id);
    }
    this._map.delete(schema);
    return this;
  }
  get(schema) {
    const p = schema._zod.parent;
    if (p) {
      const pm = { ...this.get(p) ?? {} };
      delete pm.id;
      const f = { ...pm, ...this._map.get(schema) };
      return Object.keys(f).length ? f : undefined;
    }
    return this._map.get(schema);
  }
  has(schema) {
    return this._map.has(schema);
  }
}
function registry() {
  return new $ZodRegistry;
}
(_a = globalThis).__zod_globalRegistry ?? (_a.__zod_globalRegistry = registry());
var globalRegistry = globalThis.__zod_globalRegistry;
// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/api.js
function _string(Class, params) {
  return new Class({
    type: "string",
    ...normalizeParams(params)
  });
}
function _email(Class, params) {
  return new Class({
    type: "string",
    format: "email",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _guid(Class, params) {
  return new Class({
    type: "string",
    format: "guid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _uuid(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _uuidv4(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    version: "v4",
    ...normalizeParams(params)
  });
}
function _uuidv6(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    version: "v6",
    ...normalizeParams(params)
  });
}
function _uuidv7(Class, params) {
  return new Class({
    type: "string",
    format: "uuid",
    check: "string_format",
    abort: false,
    version: "v7",
    ...normalizeParams(params)
  });
}
function _url(Class, params) {
  return new Class({
    type: "string",
    format: "url",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _emoji2(Class, params) {
  return new Class({
    type: "string",
    format: "emoji",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _nanoid(Class, params) {
  return new Class({
    type: "string",
    format: "nanoid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cuid(Class, params) {
  return new Class({
    type: "string",
    format: "cuid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cuid2(Class, params) {
  return new Class({
    type: "string",
    format: "cuid2",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ulid(Class, params) {
  return new Class({
    type: "string",
    format: "ulid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _xid(Class, params) {
  return new Class({
    type: "string",
    format: "xid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ksuid(Class, params) {
  return new Class({
    type: "string",
    format: "ksuid",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ipv4(Class, params) {
  return new Class({
    type: "string",
    format: "ipv4",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _ipv6(Class, params) {
  return new Class({
    type: "string",
    format: "ipv6",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cidrv4(Class, params) {
  return new Class({
    type: "string",
    format: "cidrv4",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _cidrv6(Class, params) {
  return new Class({
    type: "string",
    format: "cidrv6",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _base64(Class, params) {
  return new Class({
    type: "string",
    format: "base64",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _base64url(Class, params) {
  return new Class({
    type: "string",
    format: "base64url",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _e164(Class, params) {
  return new Class({
    type: "string",
    format: "e164",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _jwt(Class, params) {
  return new Class({
    type: "string",
    format: "jwt",
    check: "string_format",
    abort: false,
    ...normalizeParams(params)
  });
}
function _isoDateTime(Class, params) {
  return new Class({
    type: "string",
    format: "datetime",
    check: "string_format",
    offset: false,
    local: false,
    precision: null,
    ...normalizeParams(params)
  });
}
function _isoDate(Class, params) {
  return new Class({
    type: "string",
    format: "date",
    check: "string_format",
    ...normalizeParams(params)
  });
}
function _isoTime(Class, params) {
  return new Class({
    type: "string",
    format: "time",
    check: "string_format",
    precision: null,
    ...normalizeParams(params)
  });
}
function _isoDuration(Class, params) {
  return new Class({
    type: "string",
    format: "duration",
    check: "string_format",
    ...normalizeParams(params)
  });
}
function _number(Class, params) {
  return new Class({
    type: "number",
    checks: [],
    ...normalizeParams(params)
  });
}
function _int(Class, params) {
  return new Class({
    type: "number",
    check: "number_format",
    abort: false,
    format: "safeint",
    ...normalizeParams(params)
  });
}
function _boolean(Class, params) {
  return new Class({
    type: "boolean",
    ...normalizeParams(params)
  });
}
function _unknown(Class) {
  return new Class({
    type: "unknown"
  });
}
function _never(Class, params) {
  return new Class({
    type: "never",
    ...normalizeParams(params)
  });
}
function _lt(value, params) {
  return new $ZodCheckLessThan({
    check: "less_than",
    ...normalizeParams(params),
    value,
    inclusive: false
  });
}
function _lte(value, params) {
  return new $ZodCheckLessThan({
    check: "less_than",
    ...normalizeParams(params),
    value,
    inclusive: true
  });
}
function _gt(value, params) {
  return new $ZodCheckGreaterThan({
    check: "greater_than",
    ...normalizeParams(params),
    value,
    inclusive: false
  });
}
function _gte(value, params) {
  return new $ZodCheckGreaterThan({
    check: "greater_than",
    ...normalizeParams(params),
    value,
    inclusive: true
  });
}
function _multipleOf(value, params) {
  return new $ZodCheckMultipleOf({
    check: "multiple_of",
    ...normalizeParams(params),
    value
  });
}
function _maxLength(maximum, params) {
  const ch = new $ZodCheckMaxLength({
    check: "max_length",
    ...normalizeParams(params),
    maximum
  });
  return ch;
}
function _minLength(minimum, params) {
  return new $ZodCheckMinLength({
    check: "min_length",
    ...normalizeParams(params),
    minimum
  });
}
function _length(length, params) {
  return new $ZodCheckLengthEquals({
    check: "length_equals",
    ...normalizeParams(params),
    length
  });
}
function _regex(pattern, params) {
  return new $ZodCheckRegex({
    check: "string_format",
    format: "regex",
    ...normalizeParams(params),
    pattern
  });
}
function _lowercase(params) {
  return new $ZodCheckLowerCase({
    check: "string_format",
    format: "lowercase",
    ...normalizeParams(params)
  });
}
function _uppercase(params) {
  return new $ZodCheckUpperCase({
    check: "string_format",
    format: "uppercase",
    ...normalizeParams(params)
  });
}
function _includes(includes, params) {
  return new $ZodCheckIncludes({
    check: "string_format",
    format: "includes",
    ...normalizeParams(params),
    includes
  });
}
function _startsWith(prefix, params) {
  return new $ZodCheckStartsWith({
    check: "string_format",
    format: "starts_with",
    ...normalizeParams(params),
    prefix
  });
}
function _endsWith(suffix, params) {
  return new $ZodCheckEndsWith({
    check: "string_format",
    format: "ends_with",
    ...normalizeParams(params),
    suffix
  });
}
function _overwrite(tx) {
  return new $ZodCheckOverwrite({
    check: "overwrite",
    tx
  });
}
function _normalize(form) {
  return _overwrite((input) => input.normalize(form));
}
function _trim() {
  return _overwrite((input) => input.trim());
}
function _toLowerCase() {
  return _overwrite((input) => input.toLowerCase());
}
function _toUpperCase() {
  return _overwrite((input) => input.toUpperCase());
}
function _slugify() {
  return _overwrite((input) => slugify(input));
}
function _array(Class, element, params) {
  return new Class({
    type: "array",
    element,
    ...normalizeParams(params)
  });
}
function _refine(Class, fn, _params) {
  const schema = new Class({
    type: "custom",
    check: "custom",
    fn,
    ...normalizeParams(_params)
  });
  return schema;
}
function _superRefine(fn) {
  const ch = _check((payload) => {
    payload.addIssue = (issue2) => {
      if (typeof issue2 === "string") {
        payload.issues.push(issue(issue2, payload.value, ch._zod.def));
      } else {
        const _issue = issue2;
        if (_issue.fatal)
          _issue.continue = false;
        _issue.code ?? (_issue.code = "custom");
        _issue.input ?? (_issue.input = payload.value);
        _issue.inst ?? (_issue.inst = ch);
        _issue.continue ?? (_issue.continue = !ch._zod.def.abort);
        payload.issues.push(issue(_issue));
      }
    };
    return fn(payload.value, payload);
  });
  return ch;
}
function _check(fn, params) {
  const ch = new $ZodCheck({
    check: "custom",
    ...normalizeParams(params)
  });
  ch._zod.check = fn;
  return ch;
}
// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/to-json-schema.js
function initializeContext(params) {
  let target = params?.target ?? "draft-2020-12";
  if (target === "draft-4")
    target = "draft-04";
  if (target === "draft-7")
    target = "draft-07";
  return {
    processors: params.processors ?? {},
    metadataRegistry: params?.metadata ?? globalRegistry,
    target,
    unrepresentable: params?.unrepresentable ?? "throw",
    override: params?.override ?? (() => {}),
    io: params?.io ?? "output",
    counter: 0,
    seen: new Map,
    cycles: params?.cycles ?? "ref",
    reused: params?.reused ?? "inline",
    external: params?.external ?? undefined
  };
}
function process2(schema, ctx, _params = { path: [], schemaPath: [] }) {
  var _a;
  const def = schema._zod.def;
  const seen = ctx.seen.get(schema);
  if (seen) {
    seen.count++;
    const isCycle = _params.schemaPath.includes(schema);
    if (isCycle) {
      seen.cycle = _params.path;
    }
    return seen.schema;
  }
  const result = { schema: {}, count: 1, cycle: undefined, path: _params.path };
  ctx.seen.set(schema, result);
  const overrideSchema = schema._zod.toJSONSchema?.();
  if (overrideSchema) {
    result.schema = overrideSchema;
  } else {
    const params = {
      ..._params,
      schemaPath: [..._params.schemaPath, schema],
      path: _params.path
    };
    if (schema._zod.processJSONSchema) {
      schema._zod.processJSONSchema(ctx, result.schema, params);
    } else {
      const _json = result.schema;
      const processor = ctx.processors[def.type];
      if (!processor) {
        throw new Error(`[toJSONSchema]: Non-representable type encountered: ${def.type}`);
      }
      processor(schema, ctx, _json, params);
    }
    const parent = schema._zod.parent;
    if (parent) {
      if (!result.ref)
        result.ref = parent;
      process2(parent, ctx, params);
      ctx.seen.get(parent).isParent = true;
    }
  }
  const meta = ctx.metadataRegistry.get(schema);
  if (meta)
    Object.assign(result.schema, meta);
  if (ctx.io === "input" && isTransforming(schema)) {
    delete result.schema.examples;
    delete result.schema.default;
  }
  if (ctx.io === "input" && result.schema._prefault)
    (_a = result.schema).default ?? (_a.default = result.schema._prefault);
  delete result.schema._prefault;
  const _result = ctx.seen.get(schema);
  return _result.schema;
}
function extractDefs(ctx, schema) {
  const root = ctx.seen.get(schema);
  if (!root)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const idToSchema = new Map;
  for (const entry of ctx.seen.entries()) {
    const id = ctx.metadataRegistry.get(entry[0])?.id;
    if (id) {
      const existing = idToSchema.get(id);
      if (existing && existing !== entry[0]) {
        throw new Error(`Duplicate schema id "${id}" detected during JSON Schema conversion. Two different schemas cannot share the same id when converted together.`);
      }
      idToSchema.set(id, entry[0]);
    }
  }
  const makeURI = (entry) => {
    const defsSegment = ctx.target === "draft-2020-12" ? "$defs" : "definitions";
    if (ctx.external) {
      const externalId = ctx.external.registry.get(entry[0])?.id;
      const uriGenerator = ctx.external.uri ?? ((id) => id);
      if (externalId) {
        return { ref: uriGenerator(externalId) };
      }
      const id = entry[1].defId ?? entry[1].schema.id ?? `schema${ctx.counter++}`;
      entry[1].defId = id;
      return { defId: id, ref: `${uriGenerator("__shared")}#/${defsSegment}/${id}` };
    }
    if (entry[1] === root) {
      return { ref: "#" };
    }
    const uriPrefix = `#`;
    const defUriPrefix = `${uriPrefix}/${defsSegment}/`;
    const defId = entry[1].schema.id ?? `__schema${ctx.counter++}`;
    return { defId, ref: defUriPrefix + defId };
  };
  const extractToDef = (entry) => {
    if (entry[1].schema.$ref) {
      return;
    }
    const seen = entry[1];
    const { ref, defId } = makeURI(entry);
    seen.def = { ...seen.schema };
    if (defId)
      seen.defId = defId;
    const schema = seen.schema;
    for (const key in schema) {
      delete schema[key];
    }
    schema.$ref = ref;
  };
  if (ctx.cycles === "throw") {
    for (const entry of ctx.seen.entries()) {
      const seen = entry[1];
      if (seen.cycle) {
        throw new Error("Cycle detected: " + `#/${seen.cycle?.join("/")}/<root>` + '\n\nSet the `cycles` parameter to `"ref"` to resolve cyclical schemas with defs.');
      }
    }
  }
  for (const entry of ctx.seen.entries()) {
    const seen = entry[1];
    if (schema === entry[0]) {
      extractToDef(entry);
      continue;
    }
    if (ctx.external) {
      const ext = ctx.external.registry.get(entry[0])?.id;
      if (schema !== entry[0] && ext) {
        extractToDef(entry);
        continue;
      }
    }
    const id = ctx.metadataRegistry.get(entry[0])?.id;
    if (id) {
      extractToDef(entry);
      continue;
    }
    if (seen.cycle) {
      extractToDef(entry);
      continue;
    }
    if (seen.count > 1) {
      if (ctx.reused === "ref") {
        extractToDef(entry);
        continue;
      }
    }
  }
}
function finalize(ctx, schema) {
  const root = ctx.seen.get(schema);
  if (!root)
    throw new Error("Unprocessed schema. This is a bug in Zod.");
  const flattenRef = (zodSchema) => {
    const seen = ctx.seen.get(zodSchema);
    if (seen.ref === null)
      return;
    const schema = seen.def ?? seen.schema;
    const _cached = { ...schema };
    const ref = seen.ref;
    seen.ref = null;
    if (ref) {
      flattenRef(ref);
      const refSeen = ctx.seen.get(ref);
      const refSchema = refSeen.schema;
      if (refSchema.$ref && (ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0")) {
        schema.allOf = schema.allOf ?? [];
        schema.allOf.push(refSchema);
      } else {
        Object.assign(schema, refSchema);
      }
      Object.assign(schema, _cached);
      const isParentRef = zodSchema._zod.parent === ref;
      if (isParentRef) {
        for (const key in schema) {
          if (key === "$ref" || key === "allOf")
            continue;
          if (!(key in _cached)) {
            delete schema[key];
          }
        }
      }
      if (refSchema.$ref && refSeen.def) {
        for (const key in schema) {
          if (key === "$ref" || key === "allOf")
            continue;
          if (key in refSeen.def && JSON.stringify(schema[key]) === JSON.stringify(refSeen.def[key])) {
            delete schema[key];
          }
        }
      }
    }
    const parent = zodSchema._zod.parent;
    if (parent && parent !== ref) {
      flattenRef(parent);
      const parentSeen = ctx.seen.get(parent);
      if (parentSeen?.schema.$ref) {
        schema.$ref = parentSeen.schema.$ref;
        if (parentSeen.def) {
          for (const key in schema) {
            if (key === "$ref" || key === "allOf")
              continue;
            if (key in parentSeen.def && JSON.stringify(schema[key]) === JSON.stringify(parentSeen.def[key])) {
              delete schema[key];
            }
          }
        }
      }
    }
    ctx.override({
      zodSchema,
      jsonSchema: schema,
      path: seen.path ?? []
    });
  };
  for (const entry of [...ctx.seen.entries()].reverse()) {
    flattenRef(entry[0]);
  }
  const result = {};
  if (ctx.target === "draft-2020-12") {
    result.$schema = "https://json-schema.org/draft/2020-12/schema";
  } else if (ctx.target === "draft-07") {
    result.$schema = "http://json-schema.org/draft-07/schema#";
  } else if (ctx.target === "draft-04") {
    result.$schema = "http://json-schema.org/draft-04/schema#";
  } else if (ctx.target === "openapi-3.0") {}
  if (ctx.external?.uri) {
    const id = ctx.external.registry.get(schema)?.id;
    if (!id)
      throw new Error("Schema is missing an `id` property");
    result.$id = ctx.external.uri(id);
  }
  Object.assign(result, root.def ?? root.schema);
  const defs = ctx.external?.defs ?? {};
  for (const entry of ctx.seen.entries()) {
    const seen = entry[1];
    if (seen.def && seen.defId) {
      defs[seen.defId] = seen.def;
    }
  }
  if (ctx.external) {} else {
    if (Object.keys(defs).length > 0) {
      if (ctx.target === "draft-2020-12") {
        result.$defs = defs;
      } else {
        result.definitions = defs;
      }
    }
  }
  try {
    const finalized = JSON.parse(JSON.stringify(result));
    Object.defineProperty(finalized, "~standard", {
      value: {
        ...schema["~standard"],
        jsonSchema: {
          input: createStandardJSONSchemaMethod(schema, "input", ctx.processors),
          output: createStandardJSONSchemaMethod(schema, "output", ctx.processors)
        }
      },
      enumerable: false,
      writable: false
    });
    return finalized;
  } catch (_err) {
    throw new Error("Error converting schema to JSON.");
  }
}
function isTransforming(_schema, _ctx) {
  const ctx = _ctx ?? { seen: new Set };
  if (ctx.seen.has(_schema))
    return false;
  ctx.seen.add(_schema);
  const def = _schema._zod.def;
  if (def.type === "transform")
    return true;
  if (def.type === "array")
    return isTransforming(def.element, ctx);
  if (def.type === "set")
    return isTransforming(def.valueType, ctx);
  if (def.type === "lazy")
    return isTransforming(def.getter(), ctx);
  if (def.type === "promise" || def.type === "optional" || def.type === "nonoptional" || def.type === "nullable" || def.type === "readonly" || def.type === "default" || def.type === "prefault") {
    return isTransforming(def.innerType, ctx);
  }
  if (def.type === "intersection") {
    return isTransforming(def.left, ctx) || isTransforming(def.right, ctx);
  }
  if (def.type === "record" || def.type === "map") {
    return isTransforming(def.keyType, ctx) || isTransforming(def.valueType, ctx);
  }
  if (def.type === "pipe") {
    return isTransforming(def.in, ctx) || isTransforming(def.out, ctx);
  }
  if (def.type === "object") {
    for (const key in def.shape) {
      if (isTransforming(def.shape[key], ctx))
        return true;
    }
    return false;
  }
  if (def.type === "union") {
    for (const option of def.options) {
      if (isTransforming(option, ctx))
        return true;
    }
    return false;
  }
  if (def.type === "tuple") {
    for (const item of def.items) {
      if (isTransforming(item, ctx))
        return true;
    }
    if (def.rest && isTransforming(def.rest, ctx))
      return true;
    return false;
  }
  return false;
}
var createToJSONSchemaMethod = (schema, processors = {}) => (params) => {
  const ctx = initializeContext({ ...params, processors });
  process2(schema, ctx);
  extractDefs(ctx, schema);
  return finalize(ctx, schema);
};
var createStandardJSONSchemaMethod = (schema, io, processors = {}) => (params) => {
  const { libraryOptions, target } = params ?? {};
  const ctx = initializeContext({ ...libraryOptions ?? {}, target, io, processors });
  process2(schema, ctx);
  extractDefs(ctx, schema);
  return finalize(ctx, schema);
};
// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/core/json-schema-processors.js
var formatMap = {
  guid: "uuid",
  url: "uri",
  datetime: "date-time",
  json_string: "json-string",
  regex: ""
};
var stringProcessor = (schema, ctx, _json, _params) => {
  const json = _json;
  json.type = "string";
  const { minimum, maximum, format, patterns, contentEncoding } = schema._zod.bag;
  if (typeof minimum === "number")
    json.minLength = minimum;
  if (typeof maximum === "number")
    json.maxLength = maximum;
  if (format) {
    json.format = formatMap[format] ?? format;
    if (json.format === "")
      delete json.format;
    if (format === "time") {
      delete json.format;
    }
  }
  if (contentEncoding)
    json.contentEncoding = contentEncoding;
  if (patterns && patterns.size > 0) {
    const regexes = [...patterns];
    if (regexes.length === 1)
      json.pattern = regexes[0].source;
    else if (regexes.length > 1) {
      json.allOf = [
        ...regexes.map((regex) => ({
          ...ctx.target === "draft-07" || ctx.target === "draft-04" || ctx.target === "openapi-3.0" ? { type: "string" } : {},
          pattern: regex.source
        }))
      ];
    }
  }
};
var numberProcessor = (schema, ctx, _json, _params) => {
  const json = _json;
  const { minimum, maximum, format, multipleOf, exclusiveMaximum, exclusiveMinimum } = schema._zod.bag;
  if (typeof format === "string" && format.includes("int"))
    json.type = "integer";
  else
    json.type = "number";
  if (typeof exclusiveMinimum === "number") {
    if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") {
      json.minimum = exclusiveMinimum;
      json.exclusiveMinimum = true;
    } else {
      json.exclusiveMinimum = exclusiveMinimum;
    }
  }
  if (typeof minimum === "number") {
    json.minimum = minimum;
    if (typeof exclusiveMinimum === "number" && ctx.target !== "draft-04") {
      if (exclusiveMinimum >= minimum)
        delete json.minimum;
      else
        delete json.exclusiveMinimum;
    }
  }
  if (typeof exclusiveMaximum === "number") {
    if (ctx.target === "draft-04" || ctx.target === "openapi-3.0") {
      json.maximum = exclusiveMaximum;
      json.exclusiveMaximum = true;
    } else {
      json.exclusiveMaximum = exclusiveMaximum;
    }
  }
  if (typeof maximum === "number") {
    json.maximum = maximum;
    if (typeof exclusiveMaximum === "number" && ctx.target !== "draft-04") {
      if (exclusiveMaximum <= maximum)
        delete json.maximum;
      else
        delete json.exclusiveMaximum;
    }
  }
  if (typeof multipleOf === "number")
    json.multipleOf = multipleOf;
};
var booleanProcessor = (_schema, _ctx, json, _params) => {
  json.type = "boolean";
};
var neverProcessor = (_schema, _ctx, json, _params) => {
  json.not = {};
};
var unknownProcessor = (_schema, _ctx, _json, _params) => {};
var enumProcessor = (schema, _ctx, json, _params) => {
  const def = schema._zod.def;
  const values = getEnumValues(def.entries);
  if (values.every((v) => typeof v === "number"))
    json.type = "number";
  if (values.every((v) => typeof v === "string"))
    json.type = "string";
  json.enum = values;
};
var customProcessor = (_schema, ctx, _json, _params) => {
  if (ctx.unrepresentable === "throw") {
    throw new Error("Custom types cannot be represented in JSON Schema");
  }
};
var transformProcessor = (_schema, ctx, _json, _params) => {
  if (ctx.unrepresentable === "throw") {
    throw new Error("Transforms cannot be represented in JSON Schema");
  }
};
var arrayProcessor = (schema, ctx, _json, params) => {
  const json = _json;
  const def = schema._zod.def;
  const { minimum, maximum } = schema._zod.bag;
  if (typeof minimum === "number")
    json.minItems = minimum;
  if (typeof maximum === "number")
    json.maxItems = maximum;
  json.type = "array";
  json.items = process2(def.element, ctx, { ...params, path: [...params.path, "items"] });
};
var objectProcessor = (schema, ctx, _json, params) => {
  const json = _json;
  const def = schema._zod.def;
  json.type = "object";
  json.properties = {};
  const shape = def.shape;
  for (const key in shape) {
    json.properties[key] = process2(shape[key], ctx, {
      ...params,
      path: [...params.path, "properties", key]
    });
  }
  const allKeys = new Set(Object.keys(shape));
  const requiredKeys = new Set([...allKeys].filter((key) => {
    const v = def.shape[key]._zod;
    if (ctx.io === "input") {
      return v.optin === undefined;
    } else {
      return v.optout === undefined;
    }
  }));
  if (requiredKeys.size > 0) {
    json.required = Array.from(requiredKeys);
  }
  if (def.catchall?._zod.def.type === "never") {
    json.additionalProperties = false;
  } else if (!def.catchall) {
    if (ctx.io === "output")
      json.additionalProperties = false;
  } else if (def.catchall) {
    json.additionalProperties = process2(def.catchall, ctx, {
      ...params,
      path: [...params.path, "additionalProperties"]
    });
  }
};
var unionProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  const isExclusive = def.inclusive === false;
  const options = def.options.map((x, i) => process2(x, ctx, {
    ...params,
    path: [...params.path, isExclusive ? "oneOf" : "anyOf", i]
  }));
  if (isExclusive) {
    json.oneOf = options;
  } else {
    json.anyOf = options;
  }
};
var intersectionProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  const a = process2(def.left, ctx, {
    ...params,
    path: [...params.path, "allOf", 0]
  });
  const b = process2(def.right, ctx, {
    ...params,
    path: [...params.path, "allOf", 1]
  });
  const isSimpleIntersection = (val) => ("allOf" in val) && Object.keys(val).length === 1;
  const allOf = [
    ...isSimpleIntersection(a) ? a.allOf : [a],
    ...isSimpleIntersection(b) ? b.allOf : [b]
  ];
  json.allOf = allOf;
};
var nullableProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  const inner = process2(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  if (ctx.target === "openapi-3.0") {
    seen.ref = def.innerType;
    json.nullable = true;
  } else {
    json.anyOf = [inner, { type: "null" }];
  }
};
var nonoptionalProcessor = (schema, ctx, _json, params) => {
  const def = schema._zod.def;
  process2(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
};
var defaultProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  process2(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  json.default = JSON.parse(JSON.stringify(def.defaultValue));
};
var prefaultProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  process2(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  if (ctx.io === "input")
    json._prefault = JSON.parse(JSON.stringify(def.defaultValue));
};
var catchProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  process2(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  let catchValue;
  try {
    catchValue = def.catchValue(undefined);
  } catch {
    throw new Error("Dynamic catch values are not supported in JSON Schema");
  }
  json.default = catchValue;
};
var pipeProcessor = (schema, ctx, _json, params) => {
  const def = schema._zod.def;
  const innerType = ctx.io === "input" ? def.in._zod.def.type === "transform" ? def.out : def.in : def.out;
  process2(innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = innerType;
};
var readonlyProcessor = (schema, ctx, json, params) => {
  const def = schema._zod.def;
  process2(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
  json.readOnly = true;
};
var optionalProcessor = (schema, ctx, _json, params) => {
  const def = schema._zod.def;
  process2(def.innerType, ctx, params);
  const seen = ctx.seen.get(schema);
  seen.ref = def.innerType;
};
// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/classic/iso.js
var ZodISODateTime = /* @__PURE__ */ $constructor("ZodISODateTime", (inst, def) => {
  $ZodISODateTime.init(inst, def);
  ZodStringFormat.init(inst, def);
});
function datetime2(params) {
  return _isoDateTime(ZodISODateTime, params);
}
var ZodISODate = /* @__PURE__ */ $constructor("ZodISODate", (inst, def) => {
  $ZodISODate.init(inst, def);
  ZodStringFormat.init(inst, def);
});
function date2(params) {
  return _isoDate(ZodISODate, params);
}
var ZodISOTime = /* @__PURE__ */ $constructor("ZodISOTime", (inst, def) => {
  $ZodISOTime.init(inst, def);
  ZodStringFormat.init(inst, def);
});
function time2(params) {
  return _isoTime(ZodISOTime, params);
}
var ZodISODuration = /* @__PURE__ */ $constructor("ZodISODuration", (inst, def) => {
  $ZodISODuration.init(inst, def);
  ZodStringFormat.init(inst, def);
});
function duration2(params) {
  return _isoDuration(ZodISODuration, params);
}

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/classic/errors.js
var initializer2 = (inst, issues) => {
  $ZodError.init(inst, issues);
  inst.name = "ZodError";
  Object.defineProperties(inst, {
    format: {
      value: (mapper) => formatError(inst, mapper)
    },
    flatten: {
      value: (mapper) => flattenError(inst, mapper)
    },
    addIssue: {
      value: (issue) => {
        inst.issues.push(issue);
        inst.message = JSON.stringify(inst.issues, jsonStringifyReplacer, 2);
      }
    },
    addIssues: {
      value: (issues) => {
        inst.issues.push(...issues);
        inst.message = JSON.stringify(inst.issues, jsonStringifyReplacer, 2);
      }
    },
    isEmpty: {
      get() {
        return inst.issues.length === 0;
      }
    }
  });
};
var ZodError = $constructor("ZodError", initializer2);
var ZodRealError = $constructor("ZodError", initializer2, {
  Parent: Error
});

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/classic/parse.js
var parse3 = /* @__PURE__ */ _parse(ZodRealError);
var parseAsync2 = /* @__PURE__ */ _parseAsync(ZodRealError);
var safeParse2 = /* @__PURE__ */ _safeParse(ZodRealError);
var safeParseAsync2 = /* @__PURE__ */ _safeParseAsync(ZodRealError);
var encode = /* @__PURE__ */ _encode(ZodRealError);
var decode = /* @__PURE__ */ _decode(ZodRealError);
var encodeAsync = /* @__PURE__ */ _encodeAsync(ZodRealError);
var decodeAsync = /* @__PURE__ */ _decodeAsync(ZodRealError);
var safeEncode = /* @__PURE__ */ _safeEncode(ZodRealError);
var safeDecode = /* @__PURE__ */ _safeDecode(ZodRealError);
var safeEncodeAsync = /* @__PURE__ */ _safeEncodeAsync(ZodRealError);
var safeDecodeAsync = /* @__PURE__ */ _safeDecodeAsync(ZodRealError);

// node_modules/.bun/zod@4.3.6/node_modules/zod/v4/classic/schemas.js
var ZodType = /* @__PURE__ */ $constructor("ZodType", (inst, def) => {
  $ZodType.init(inst, def);
  Object.assign(inst["~standard"], {
    jsonSchema: {
      input: createStandardJSONSchemaMethod(inst, "input"),
      output: createStandardJSONSchemaMethod(inst, "output")
    }
  });
  inst.toJSONSchema = createToJSONSchemaMethod(inst, {});
  inst.def = def;
  inst.type = def.type;
  Object.defineProperty(inst, "_def", { value: def });
  inst.check = (...checks) => {
    return inst.clone(mergeDefs(def, {
      checks: [
        ...def.checks ?? [],
        ...checks.map((ch) => typeof ch === "function" ? { _zod: { check: ch, def: { check: "custom" }, onattach: [] } } : ch)
      ]
    }), {
      parent: true
    });
  };
  inst.with = inst.check;
  inst.clone = (def, params) => clone(inst, def, params);
  inst.brand = () => inst;
  inst.register = (reg, meta) => {
    reg.add(inst, meta);
    return inst;
  };
  inst.parse = (data, params) => parse3(inst, data, params, { callee: inst.parse });
  inst.safeParse = (data, params) => safeParse2(inst, data, params);
  inst.parseAsync = async (data, params) => parseAsync2(inst, data, params, { callee: inst.parseAsync });
  inst.safeParseAsync = async (data, params) => safeParseAsync2(inst, data, params);
  inst.spa = inst.safeParseAsync;
  inst.encode = (data, params) => encode(inst, data, params);
  inst.decode = (data, params) => decode(inst, data, params);
  inst.encodeAsync = async (data, params) => encodeAsync(inst, data, params);
  inst.decodeAsync = async (data, params) => decodeAsync(inst, data, params);
  inst.safeEncode = (data, params) => safeEncode(inst, data, params);
  inst.safeDecode = (data, params) => safeDecode(inst, data, params);
  inst.safeEncodeAsync = async (data, params) => safeEncodeAsync(inst, data, params);
  inst.safeDecodeAsync = async (data, params) => safeDecodeAsync(inst, data, params);
  inst.refine = (check, params) => inst.check(refine(check, params));
  inst.superRefine = (refinement) => inst.check(superRefine(refinement));
  inst.overwrite = (fn) => inst.check(_overwrite(fn));
  inst.optional = () => optional(inst);
  inst.exactOptional = () => exactOptional(inst);
  inst.nullable = () => nullable(inst);
  inst.nullish = () => optional(nullable(inst));
  inst.nonoptional = (params) => nonoptional(inst, params);
  inst.array = () => array(inst);
  inst.or = (arg) => union2([inst, arg]);
  inst.and = (arg) => intersection(inst, arg);
  inst.transform = (tx) => pipe(inst, transform(tx));
  inst.default = (def) => _default(inst, def);
  inst.prefault = (def) => prefault(inst, def);
  inst.catch = (params) => _catch(inst, params);
  inst.pipe = (target) => pipe(inst, target);
  inst.readonly = () => readonly(inst);
  inst.describe = (description) => {
    const cl = inst.clone();
    globalRegistry.add(cl, { description });
    return cl;
  };
  Object.defineProperty(inst, "description", {
    get() {
      return globalRegistry.get(inst)?.description;
    },
    configurable: true
  });
  inst.meta = (...args) => {
    if (args.length === 0) {
      return globalRegistry.get(inst);
    }
    const cl = inst.clone();
    globalRegistry.add(cl, args[0]);
    return cl;
  };
  inst.isOptional = () => inst.safeParse(undefined).success;
  inst.isNullable = () => inst.safeParse(null).success;
  inst.apply = (fn) => fn(inst);
  return inst;
});
var _ZodString = /* @__PURE__ */ $constructor("_ZodString", (inst, def) => {
  $ZodString.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => stringProcessor(inst, ctx, json, params);
  const bag = inst._zod.bag;
  inst.format = bag.format ?? null;
  inst.minLength = bag.minimum ?? null;
  inst.maxLength = bag.maximum ?? null;
  inst.regex = (...args) => inst.check(_regex(...args));
  inst.includes = (...args) => inst.check(_includes(...args));
  inst.startsWith = (...args) => inst.check(_startsWith(...args));
  inst.endsWith = (...args) => inst.check(_endsWith(...args));
  inst.min = (...args) => inst.check(_minLength(...args));
  inst.max = (...args) => inst.check(_maxLength(...args));
  inst.length = (...args) => inst.check(_length(...args));
  inst.nonempty = (...args) => inst.check(_minLength(1, ...args));
  inst.lowercase = (params) => inst.check(_lowercase(params));
  inst.uppercase = (params) => inst.check(_uppercase(params));
  inst.trim = () => inst.check(_trim());
  inst.normalize = (...args) => inst.check(_normalize(...args));
  inst.toLowerCase = () => inst.check(_toLowerCase());
  inst.toUpperCase = () => inst.check(_toUpperCase());
  inst.slugify = () => inst.check(_slugify());
});
var ZodString = /* @__PURE__ */ $constructor("ZodString", (inst, def) => {
  $ZodString.init(inst, def);
  _ZodString.init(inst, def);
  inst.email = (params) => inst.check(_email(ZodEmail, params));
  inst.url = (params) => inst.check(_url(ZodURL, params));
  inst.jwt = (params) => inst.check(_jwt(ZodJWT, params));
  inst.emoji = (params) => inst.check(_emoji2(ZodEmoji, params));
  inst.guid = (params) => inst.check(_guid(ZodGUID, params));
  inst.uuid = (params) => inst.check(_uuid(ZodUUID, params));
  inst.uuidv4 = (params) => inst.check(_uuidv4(ZodUUID, params));
  inst.uuidv6 = (params) => inst.check(_uuidv6(ZodUUID, params));
  inst.uuidv7 = (params) => inst.check(_uuidv7(ZodUUID, params));
  inst.nanoid = (params) => inst.check(_nanoid(ZodNanoID, params));
  inst.guid = (params) => inst.check(_guid(ZodGUID, params));
  inst.cuid = (params) => inst.check(_cuid(ZodCUID, params));
  inst.cuid2 = (params) => inst.check(_cuid2(ZodCUID2, params));
  inst.ulid = (params) => inst.check(_ulid(ZodULID, params));
  inst.base64 = (params) => inst.check(_base64(ZodBase64, params));
  inst.base64url = (params) => inst.check(_base64url(ZodBase64URL, params));
  inst.xid = (params) => inst.check(_xid(ZodXID, params));
  inst.ksuid = (params) => inst.check(_ksuid(ZodKSUID, params));
  inst.ipv4 = (params) => inst.check(_ipv4(ZodIPv4, params));
  inst.ipv6 = (params) => inst.check(_ipv6(ZodIPv6, params));
  inst.cidrv4 = (params) => inst.check(_cidrv4(ZodCIDRv4, params));
  inst.cidrv6 = (params) => inst.check(_cidrv6(ZodCIDRv6, params));
  inst.e164 = (params) => inst.check(_e164(ZodE164, params));
  inst.datetime = (params) => inst.check(datetime2(params));
  inst.date = (params) => inst.check(date2(params));
  inst.time = (params) => inst.check(time2(params));
  inst.duration = (params) => inst.check(duration2(params));
});
function string2(params) {
  return _string(ZodString, params);
}
var ZodStringFormat = /* @__PURE__ */ $constructor("ZodStringFormat", (inst, def) => {
  $ZodStringFormat.init(inst, def);
  _ZodString.init(inst, def);
});
var ZodEmail = /* @__PURE__ */ $constructor("ZodEmail", (inst, def) => {
  $ZodEmail.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodGUID = /* @__PURE__ */ $constructor("ZodGUID", (inst, def) => {
  $ZodGUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodUUID = /* @__PURE__ */ $constructor("ZodUUID", (inst, def) => {
  $ZodUUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodURL = /* @__PURE__ */ $constructor("ZodURL", (inst, def) => {
  $ZodURL.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodEmoji = /* @__PURE__ */ $constructor("ZodEmoji", (inst, def) => {
  $ZodEmoji.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodNanoID = /* @__PURE__ */ $constructor("ZodNanoID", (inst, def) => {
  $ZodNanoID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCUID = /* @__PURE__ */ $constructor("ZodCUID", (inst, def) => {
  $ZodCUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCUID2 = /* @__PURE__ */ $constructor("ZodCUID2", (inst, def) => {
  $ZodCUID2.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodULID = /* @__PURE__ */ $constructor("ZodULID", (inst, def) => {
  $ZodULID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodXID = /* @__PURE__ */ $constructor("ZodXID", (inst, def) => {
  $ZodXID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodKSUID = /* @__PURE__ */ $constructor("ZodKSUID", (inst, def) => {
  $ZodKSUID.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodIPv4 = /* @__PURE__ */ $constructor("ZodIPv4", (inst, def) => {
  $ZodIPv4.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodIPv6 = /* @__PURE__ */ $constructor("ZodIPv6", (inst, def) => {
  $ZodIPv6.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCIDRv4 = /* @__PURE__ */ $constructor("ZodCIDRv4", (inst, def) => {
  $ZodCIDRv4.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodCIDRv6 = /* @__PURE__ */ $constructor("ZodCIDRv6", (inst, def) => {
  $ZodCIDRv6.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodBase64 = /* @__PURE__ */ $constructor("ZodBase64", (inst, def) => {
  $ZodBase64.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodBase64URL = /* @__PURE__ */ $constructor("ZodBase64URL", (inst, def) => {
  $ZodBase64URL.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodE164 = /* @__PURE__ */ $constructor("ZodE164", (inst, def) => {
  $ZodE164.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodJWT = /* @__PURE__ */ $constructor("ZodJWT", (inst, def) => {
  $ZodJWT.init(inst, def);
  ZodStringFormat.init(inst, def);
});
var ZodNumber = /* @__PURE__ */ $constructor("ZodNumber", (inst, def) => {
  $ZodNumber.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => numberProcessor(inst, ctx, json, params);
  inst.gt = (value, params) => inst.check(_gt(value, params));
  inst.gte = (value, params) => inst.check(_gte(value, params));
  inst.min = (value, params) => inst.check(_gte(value, params));
  inst.lt = (value, params) => inst.check(_lt(value, params));
  inst.lte = (value, params) => inst.check(_lte(value, params));
  inst.max = (value, params) => inst.check(_lte(value, params));
  inst.int = (params) => inst.check(int(params));
  inst.safe = (params) => inst.check(int(params));
  inst.positive = (params) => inst.check(_gt(0, params));
  inst.nonnegative = (params) => inst.check(_gte(0, params));
  inst.negative = (params) => inst.check(_lt(0, params));
  inst.nonpositive = (params) => inst.check(_lte(0, params));
  inst.multipleOf = (value, params) => inst.check(_multipleOf(value, params));
  inst.step = (value, params) => inst.check(_multipleOf(value, params));
  inst.finite = () => inst;
  const bag = inst._zod.bag;
  inst.minValue = Math.max(bag.minimum ?? Number.NEGATIVE_INFINITY, bag.exclusiveMinimum ?? Number.NEGATIVE_INFINITY) ?? null;
  inst.maxValue = Math.min(bag.maximum ?? Number.POSITIVE_INFINITY, bag.exclusiveMaximum ?? Number.POSITIVE_INFINITY) ?? null;
  inst.isInt = (bag.format ?? "").includes("int") || Number.isSafeInteger(bag.multipleOf ?? 0.5);
  inst.isFinite = true;
  inst.format = bag.format ?? null;
});
function number2(params) {
  return _number(ZodNumber, params);
}
var ZodNumberFormat = /* @__PURE__ */ $constructor("ZodNumberFormat", (inst, def) => {
  $ZodNumberFormat.init(inst, def);
  ZodNumber.init(inst, def);
});
function int(params) {
  return _int(ZodNumberFormat, params);
}
var ZodBoolean = /* @__PURE__ */ $constructor("ZodBoolean", (inst, def) => {
  $ZodBoolean.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => booleanProcessor(inst, ctx, json, params);
});
function boolean2(params) {
  return _boolean(ZodBoolean, params);
}
var ZodUnknown = /* @__PURE__ */ $constructor("ZodUnknown", (inst, def) => {
  $ZodUnknown.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => unknownProcessor(inst, ctx, json, params);
});
function unknown() {
  return _unknown(ZodUnknown);
}
var ZodNever = /* @__PURE__ */ $constructor("ZodNever", (inst, def) => {
  $ZodNever.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => neverProcessor(inst, ctx, json, params);
});
function never(params) {
  return _never(ZodNever, params);
}
var ZodArray = /* @__PURE__ */ $constructor("ZodArray", (inst, def) => {
  $ZodArray.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => arrayProcessor(inst, ctx, json, params);
  inst.element = def.element;
  inst.min = (minLength, params) => inst.check(_minLength(minLength, params));
  inst.nonempty = (params) => inst.check(_minLength(1, params));
  inst.max = (maxLength, params) => inst.check(_maxLength(maxLength, params));
  inst.length = (len, params) => inst.check(_length(len, params));
  inst.unwrap = () => inst.element;
});
function array(element, params) {
  return _array(ZodArray, element, params);
}
var ZodObject = /* @__PURE__ */ $constructor("ZodObject", (inst, def) => {
  $ZodObjectJIT.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => objectProcessor(inst, ctx, json, params);
  defineLazy(inst, "shape", () => {
    return def.shape;
  });
  inst.keyof = () => _enum(Object.keys(inst._zod.def.shape));
  inst.catchall = (catchall) => inst.clone({ ...inst._zod.def, catchall });
  inst.passthrough = () => inst.clone({ ...inst._zod.def, catchall: unknown() });
  inst.loose = () => inst.clone({ ...inst._zod.def, catchall: unknown() });
  inst.strict = () => inst.clone({ ...inst._zod.def, catchall: never() });
  inst.strip = () => inst.clone({ ...inst._zod.def, catchall: undefined });
  inst.extend = (incoming) => {
    return extend(inst, incoming);
  };
  inst.safeExtend = (incoming) => {
    return safeExtend(inst, incoming);
  };
  inst.merge = (other) => merge(inst, other);
  inst.pick = (mask) => pick(inst, mask);
  inst.omit = (mask) => omit(inst, mask);
  inst.partial = (...args) => partial(ZodOptional, inst, args[0]);
  inst.required = (...args) => required(ZodNonOptional, inst, args[0]);
});
function object(shape, params) {
  const def = {
    type: "object",
    shape: shape ?? {},
    ...normalizeParams(params)
  };
  return new ZodObject(def);
}
var ZodUnion = /* @__PURE__ */ $constructor("ZodUnion", (inst, def) => {
  $ZodUnion.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => unionProcessor(inst, ctx, json, params);
  inst.options = def.options;
});
function union2(options, params) {
  return new ZodUnion({
    type: "union",
    options,
    ...normalizeParams(params)
  });
}
var ZodIntersection = /* @__PURE__ */ $constructor("ZodIntersection", (inst, def) => {
  $ZodIntersection.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => intersectionProcessor(inst, ctx, json, params);
});
function intersection(left, right) {
  return new ZodIntersection({
    type: "intersection",
    left,
    right
  });
}
var ZodEnum = /* @__PURE__ */ $constructor("ZodEnum", (inst, def) => {
  $ZodEnum.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => enumProcessor(inst, ctx, json, params);
  inst.enum = def.entries;
  inst.options = Object.values(def.entries);
  const keys = new Set(Object.keys(def.entries));
  inst.extract = (values, params) => {
    const newEntries = {};
    for (const value of values) {
      if (keys.has(value)) {
        newEntries[value] = def.entries[value];
      } else
        throw new Error(`Key ${value} not found in enum`);
    }
    return new ZodEnum({
      ...def,
      checks: [],
      ...normalizeParams(params),
      entries: newEntries
    });
  };
  inst.exclude = (values, params) => {
    const newEntries = { ...def.entries };
    for (const value of values) {
      if (keys.has(value)) {
        delete newEntries[value];
      } else
        throw new Error(`Key ${value} not found in enum`);
    }
    return new ZodEnum({
      ...def,
      checks: [],
      ...normalizeParams(params),
      entries: newEntries
    });
  };
});
function _enum(values, params) {
  const entries = Array.isArray(values) ? Object.fromEntries(values.map((v) => [v, v])) : values;
  return new ZodEnum({
    type: "enum",
    entries,
    ...normalizeParams(params)
  });
}
var ZodTransform = /* @__PURE__ */ $constructor("ZodTransform", (inst, def) => {
  $ZodTransform.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => transformProcessor(inst, ctx, json, params);
  inst._zod.parse = (payload, _ctx) => {
    if (_ctx.direction === "backward") {
      throw new $ZodEncodeError(inst.constructor.name);
    }
    payload.addIssue = (issue2) => {
      if (typeof issue2 === "string") {
        payload.issues.push(issue(issue2, payload.value, def));
      } else {
        const _issue = issue2;
        if (_issue.fatal)
          _issue.continue = false;
        _issue.code ?? (_issue.code = "custom");
        _issue.input ?? (_issue.input = payload.value);
        _issue.inst ?? (_issue.inst = inst);
        payload.issues.push(issue(_issue));
      }
    };
    const output = def.transform(payload.value, payload);
    if (output instanceof Promise) {
      return output.then((output) => {
        payload.value = output;
        return payload;
      });
    }
    payload.value = output;
    return payload;
  };
});
function transform(fn) {
  return new ZodTransform({
    type: "transform",
    transform: fn
  });
}
var ZodOptional = /* @__PURE__ */ $constructor("ZodOptional", (inst, def) => {
  $ZodOptional.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function optional(innerType) {
  return new ZodOptional({
    type: "optional",
    innerType
  });
}
var ZodExactOptional = /* @__PURE__ */ $constructor("ZodExactOptional", (inst, def) => {
  $ZodExactOptional.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => optionalProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function exactOptional(innerType) {
  return new ZodExactOptional({
    type: "optional",
    innerType
  });
}
var ZodNullable = /* @__PURE__ */ $constructor("ZodNullable", (inst, def) => {
  $ZodNullable.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => nullableProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function nullable(innerType) {
  return new ZodNullable({
    type: "nullable",
    innerType
  });
}
var ZodDefault = /* @__PURE__ */ $constructor("ZodDefault", (inst, def) => {
  $ZodDefault.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => defaultProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
  inst.removeDefault = inst.unwrap;
});
function _default(innerType, defaultValue) {
  return new ZodDefault({
    type: "default",
    innerType,
    get defaultValue() {
      return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
    }
  });
}
var ZodPrefault = /* @__PURE__ */ $constructor("ZodPrefault", (inst, def) => {
  $ZodPrefault.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => prefaultProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function prefault(innerType, defaultValue) {
  return new ZodPrefault({
    type: "prefault",
    innerType,
    get defaultValue() {
      return typeof defaultValue === "function" ? defaultValue() : shallowClone(defaultValue);
    }
  });
}
var ZodNonOptional = /* @__PURE__ */ $constructor("ZodNonOptional", (inst, def) => {
  $ZodNonOptional.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => nonoptionalProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function nonoptional(innerType, params) {
  return new ZodNonOptional({
    type: "nonoptional",
    innerType,
    ...normalizeParams(params)
  });
}
var ZodCatch = /* @__PURE__ */ $constructor("ZodCatch", (inst, def) => {
  $ZodCatch.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => catchProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
  inst.removeCatch = inst.unwrap;
});
function _catch(innerType, catchValue) {
  return new ZodCatch({
    type: "catch",
    innerType,
    catchValue: typeof catchValue === "function" ? catchValue : () => catchValue
  });
}
var ZodPipe = /* @__PURE__ */ $constructor("ZodPipe", (inst, def) => {
  $ZodPipe.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => pipeProcessor(inst, ctx, json, params);
  inst.in = def.in;
  inst.out = def.out;
});
function pipe(in_, out) {
  return new ZodPipe({
    type: "pipe",
    in: in_,
    out
  });
}
var ZodReadonly = /* @__PURE__ */ $constructor("ZodReadonly", (inst, def) => {
  $ZodReadonly.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => readonlyProcessor(inst, ctx, json, params);
  inst.unwrap = () => inst._zod.def.innerType;
});
function readonly(innerType) {
  return new ZodReadonly({
    type: "readonly",
    innerType
  });
}
var ZodCustom = /* @__PURE__ */ $constructor("ZodCustom", (inst, def) => {
  $ZodCustom.init(inst, def);
  ZodType.init(inst, def);
  inst._zod.processJSONSchema = (ctx, json, params) => customProcessor(inst, ctx, json, params);
});
function refine(fn, _params = {}) {
  return _refine(ZodCustom, fn, _params);
}
function superRefine(fn) {
  return _superRefine(fn);
}
// packages/web/src/api/routes/config.ts
init_database();
init_schema();
init_store();
await __promiseAll([
  init_telegram(),
  init_po_feed()
]);
var patch = object({
  minConfidence: number2().min(60).max(95).optional(),
  scanIntervalSec: number2().min(30).max(900).optional(),
  minPayout: number2().min(50).max(100).optional(),
  maxPayout: number2().min(50).max(100).optional(),
  cooldownMinutes: number2().min(0).max(240).optional(),
  telegramEnabled: boolean2().optional(),
  scannerEnabled: boolean2().optional(),
  fallbackPairs: boolean2().optional(),
  excludedSymbols: string2().max(2000).optional()
});
var config2 = {
  get: base.handler(async () => {
    const settings = await getSettings();
    const subscribers2 = await db2.select().from(subscribers).orderBy(desc(subscribers.createdAt));
    return {
      settings,
      subscribers: subscribers2,
      telegramConfigured: botConfigured(),
      otcUnlocked: ssidLooksLikeCookie(),
      poFeed: feedState(),
      otcNote: "OTC-пары включатся, когда будет добавлен рабочий cookie ssid Pocket Option — у публичного фида OTC-котировок нет."
    };
  }),
  update: base.input(patch).handler(({ input }) => updateSettings(input))
};

// packages/web/src/api/routes/pairs.ts
init_drizzle_orm();
init_database();
init_schema();
init_store();
init_analyze();
await __promiseAll([
  init_candles(),
  init_pocket_option(),
  init_scanner()
]);
var pairs = {
  list: base.handler(async () => {
    const settings = await getSettings();
    const rows = await db2.select().from(assets).orderBy(desc(assets.payout));
    const excluded = parseExcluded(settings.excludedSymbols);
    return rows.map((a) => ({
      ...a,
      inRange: a.payout >= settings.minPayout && a.payout <= settings.maxPayout,
      excluded: isExcluded(a.symbol, excluded)
    }));
  }),
  sync: base.handler(async () => {
    const result = await syncAssets();
    const snap = cachedSnapshot();
    return { ...result, fetchedAt: snap?.fetchedAt ?? null };
  }),
  toggle: base.input(object({ symbol: string2(), isActive: boolean2() })).handler(async ({ input }) => {
    const [row] = await db2.update(assets).set({ isActive: input.isActive, updatedAt: new Date }).where(eq(assets.symbol, input.symbol)).returning();
    return row ?? null;
  }),
  analyze: base.input(object({ symbol: string2() })).handler(async ({ input }) => {
    try {
      const set = await getCandleSet(input.symbol);
      const result = analyze(set);
      return {
        ok: true,
        symbol: input.symbol,
        source: set.source,
        lastCandleAt: set.lastCandleAt,
        candles: set.m5.slice(-60),
        analysis: result
      };
    } catch (error) {
      return { ok: false, symbol: input.symbol, error: error.message };
    }
  })
};

// packages/web/src/api/routes/ping.ts
var ping = base.handler(() => ({ message: `Pong! ${Date.now()}` }));

// packages/web/src/api/routes/signals.ts
init_drizzle_orm();
init_database();
init_schema();
init_store();
await __promiseAll([
  init_env(),
  init_scanner(),
  init_telegram()
]);
var listInput = object({
  limit: number2().min(1).max(100).default(30),
  direction: _enum(["call", "put"]).optional(),
  symbol: string2().optional()
});
var signals2 = {
  list: base.input(listInput).handler(async ({ input }) => {
    const filters = [
      input.direction ? eq(signals.direction, input.direction) : undefined,
      input.symbol ? eq(signals.symbol, input.symbol) : undefined
    ].filter(Boolean);
    const rows = await db2.select().from(signals).where(filters.length ? and(...filters) : undefined).orderBy(desc(signals.createdAt)).limit(input.limit);
    return rows;
  }),
  get: base.input(object({ id: number2() })).handler(async ({ input }) => {
    const [row] = await db2.select().from(signals).where(eq(signals.id, input.id));
    if (!row)
      throw new ORPCError("NOT_FOUND", { message: "Сигнал не найден" });
    return row;
  }),
  overview: base.handler(async () => {
    const settings = await getSettings();
    const dayAgo = new Date(Date.now() - 24 * 3600000);
    const [total] = await db2.select({ value: count() }).from(signals);
    const [today] = await db2.select({ value: count() }).from(signals).where(gte(signals.createdAt, dayAgo));
    const [calls] = await db2.select({ value: count() }).from(signals).where(and(gte(signals.createdAt, dayAgo), eq(signals.direction, "call")));
    const [lastRun] = await db2.select().from(scanRuns).orderBy(desc(scanRuns.startedAt)).limit(1);
    const assetRows = await db2.select().from(assets);
    const inRange = assetRows.filter((a) => a.payout >= settings.minPayout && a.payout <= settings.maxPayout);
    const [subs] = await db2.select({ value: count() }).from(subscribers).where(eq(subscribers.isActive, true));
    return {
      totalSignals: total?.value ?? 0,
      signalsToday: today?.value ?? 0,
      callsToday: calls?.value ?? 0,
      putsToday: (today?.value ?? 0) - (calls?.value ?? 0),
      scannerRunning: scannerRunning(),
      subscribers: subs?.value ?? 0,
      settings,
      lastRun: lastRun ?? null,
      pairs: {
        total: assetRows.length,
        inRange: inRange.length,
        ready: inRange.filter((a) => a.feedStatus === "ok").length,
        waiting: inRange.filter((a) => a.feedStatus !== "ok").length
      }
    };
  }),
  runs: base.input(object({ limit: number2().min(1).max(50).default(12) })).handler(({ input }) => db2.select().from(scanRuns).orderBy(desc(scanRuns.startedAt)).limit(input.limit)),
  scanNow: base.handler(() => runScan({ publish: engineEnabled() })),
  resend: base.input(object({ id: number2() })).handler(async ({ input }) => {
    const [row] = await db2.select().from(signals).where(eq(signals.id, input.id));
    if (!row)
      throw new ORPCError("NOT_FOUND", { message: "Сигнал не найден" });
    const sent = await publishSignal(row);
    return { sent, preview: formatSignal(row) };
  })
};

// packages/web/src/api/routes/stats.ts
init_day();
var dayInput = object({
  day: string2().regex(/^\d{4}-\d{2}-\d{2}$/, "День в формате YYYY-MM-DD").optional()
});
var stats = {
  days: base.input(object({ limit: number2().min(1).max(120).default(45) })).handler(({ input }) => availableDays(input.limit)),
  day: base.input(dayInput).handler(({ input }) => dayStats(input.day ?? todayKey())),
  summary: base.handler(async () => {
    const today = kyivDay();
    const yesterday = shiftDay(today, -1);
    const week = Array.from({ length: 7 }, (_, i) => shiftDay(today, -i));
    const [todayTally, yesterdayTally, weekTally] = await Promise.all([
      rangeTally([today]),
      rangeTally([yesterday]),
      rangeTally(week)
    ]);
    return {
      today,
      yesterday,
      todayTally,
      yesterdayTally,
      weekTally,
      target: TARGET_WINRATE,
      reporterRunning: dailyReporterRunning()
    };
  }),
  report: base.input(dayInput).handler(({ input }) => storedReport(input.day ?? todayKey())),
  rebuildReport: base.input(dayInput).handler(async ({ input }) => {
    const day = input.day ?? todayKey();
    const report = await generateDailyReport(day);
    return { day, summary: report.summary, analysis: report.analysis };
  })
};

// packages/web/src/api/index.ts
var router = {
  ping,
  signals: signals2,
  pairs,
  config: config2,
  stats
};
var app = createApp(router);
registerOps(app);
boot();
var api_default = app;

// packages/web/src/server-node.ts
var here = dirname(fileURLToPath(import.meta.url));
var distDir = existsSync(join(here, "dist/index.html")) ? resolve(join(here, "dist")) : resolve(join(here, "../dist"));
var indexPath = join(distDir, "index.html");
var MIME = {
  ".html": "text/html; charset=utf-8",
  ".js": "text/javascript; charset=utf-8",
  ".mjs": "text/javascript; charset=utf-8",
  ".css": "text/css; charset=utf-8",
  ".json": "application/json; charset=utf-8",
  ".svg": "image/svg+xml",
  ".png": "image/png",
  ".jpg": "image/jpeg",
  ".jpeg": "image/jpeg",
  ".gif": "image/gif",
  ".webp": "image/webp",
  ".ico": "image/x-icon",
  ".woff": "font/woff",
  ".woff2": "font/woff2",
  ".ttf": "font/ttf",
  ".map": "application/json; charset=utf-8",
  ".txt": "text/plain; charset=utf-8",
  ".webmanifest": "application/manifest+json"
};
function mimeOf(path) {
  const dot = path.lastIndexOf(".");
  if (dot < 0)
    return "application/octet-stream";
  return MIME[path.slice(dot).toLowerCase()] ?? "application/octet-stream";
}
function staticPath(pathname) {
  let clean;
  try {
    clean = decodeURIComponent(pathname);
  } catch {
    return null;
  }
  clean = normalize2(clean).replace(/^([/\\]|\.\.)+/, "");
  if (!clean)
    return null;
  const full = resolve(join(distDir, clean));
  if (full !== distDir && !full.startsWith(distDir + "/"))
    return null;
  return full;
}
function fileResponse(path) {
  const body = readFileSync(path);
  const immutable = path.includes("/assets/");
  return new Response(new Uint8Array(body), {
    headers: {
      "Content-Type": mimeOf(path),
      "Cache-Control": immutable ? "public, max-age=31536000, immutable" : "no-cache"
    }
  });
}
var port = Number(process.env.PORT ?? 3000);
var host = process.env.HOST ?? "0.0.0.0";
serve({
  port,
  hostname: host,
  fetch: async (request) => {
    const url = new URL(request.url);
    if (url.pathname.startsWith("/api"))
      return api_default.fetch(request);
    const filePath = staticPath(url.pathname);
    if (filePath && existsSync(filePath) && statSync(filePath).isFile()) {
      return fileResponse(filePath);
    }
    if (existsSync(indexPath)) {
      return new Response(readFileSync(indexPath), {
        headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-cache" }
      });
    }
    return new Response("Сборка не найдена: нет dist/index.html", {
      status: 500,
      headers: { "Content-Type": "text/plain; charset=utf-8" }
    });
  }
}, (info) => {
  console.log(`[server] Node ${process.version} слушает http://${host}:${info.port}`);
  console.log(`[server] статика: ${distDir}`);
});
process.on("unhandledRejection", (reason) => {
  console.error("[server] unhandledRejection:", reason);
});
process.on("uncaughtException", (error) => {
  console.error("[server] uncaughtException:", error);
});
